<?php
/* MetStat r97 — حساب کاربری: ثبت‌نام، ورود، ورود با گوگل، نشست، علاقه‌مندی‌ها و پنل مدیر
 * همهٔ پاسخ‌ها JSON. ذخیره‌سازی: SQLite (فایل خارج از public_html اگر ممکن باشد، وگرنه پوشهٔ auth_data با ممنوعیت دسترسی).
 * امنیت: رمز با Argon2id/bcrypt (هرگز ذخیره یا برگردانده نمی‌شود)، توکن نشست تصادفی ۲۵۶ بیتی (فقط هش آن در پایگاه)،
 *        کوکی HttpOnly+Secure+SameSite، CSRF (هدر سفارشی + توکن)، محدودیت نرخ، پیام خطای عمومی در ورود، پرس‌وجوی آماده (PDO).
 * اکشن‌ها:  GET me | check&u=…   POST register | login | google | logout | fav_get | fav_set | delete_me | admin_init | admin_users | admin_delete | update_me | change_password */
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store, max-age=0'); header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff'); header('Referrer-Policy: same-origin'); header('X-Frame-Options: DENY');

function out(array $v, int $c = 200): void { http_response_code($c); echo json_encode($v, JSON_UNESCAPED_UNICODE); exit; }
function fail(string $code, int $http = 400, array $x = []): void { out(['ok' => false, 'error' => $code] + $x, $http); }

/* ---------- پیکربندی (فایل auth_config.php؛ بهتر است در پوشهٔ metstat_private بالاتر از public_html باشد) ---------- */
$DIR = __DIR__; $CFG = [];
$cands = [];
if (!empty($_SERVER['DOCUMENT_ROOT'])) { $cands[] = dirname(rtrim((string)$_SERVER['DOCUMENT_ROOT'], '/')) . '/metstat_private/auth_config.php'; }
$cands[] = "$DIR/auth_config.php";
foreach ($cands as $cf) { if (is_file($cf)) { $r = include $cf; if (is_array($r)) { $CFG = $r; break; } } }
$CFG += ['google_client_id' => '', 'setup_key' => '', 'mail_from' => 'noreply@' . preg_replace('/^www\./', '', (string)($_SERVER['HTTP_HOST'] ?? 'localhost')), 'site_name' => 'MetStat',
         'allowed_hosts' => [], 'salt' => '', 'db_dir' => '', 'session_days' => 90];
$HOST = strtolower(preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? '')));
$HTTPS = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');

/* ---------- پایگاه داده ---------- */
function db_path(array $CFG, string $DIR): string {
  $dirs = [];
  if ($CFG['db_dir'] !== '') $dirs[] = $CFG['db_dir'];
  if (!empty($_SERVER['DOCUMENT_ROOT'])) $dirs[] = dirname(rtrim((string)$_SERVER['DOCUMENT_ROOT'], '/')) . '/metstat_private';
  foreach ($dirs as $d) { if ((is_dir($d) || @mkdir($d, 0700, true)) && is_writable($d)) return $d . '/users.sqlite'; }
  $d = "$DIR/auth_data"; @mkdir($d, 0700, true);
  @file_put_contents("$d/.htaccess", "Require all denied\nDeny from all\n"); @file_put_contents("$d/index.html", '');
  return $d . '/users_' . substr(hash('sha256', $DIR . ($CFG['salt'] ?: 'x')), 0, 12) . '.sqlite';
}
try {
  $new = !is_file($p = db_path($CFG, $DIR));
  $DB = new PDO('sqlite:' . $p, null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
  if ($new) @chmod($p, 0600);
  $DB->exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=10000;');
  $DB->exec("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE COLLATE NOCASE, email TEXT NOT NULL UNIQUE COLLATE NOCASE,
    first TEXT NOT NULL, last TEXT NOT NULL, pw_hash TEXT, google_sub TEXT UNIQUE, role TEXT NOT NULL DEFAULT 'user', plan TEXT NOT NULL DEFAULT 'free', created_at INTEGER NOT NULL, last_login INTEGER);
    CREATE TABLE IF NOT EXISTS sessions(id INTEGER PRIMARY KEY AUTOINCREMENT, token_hash TEXT NOT NULL UNIQUE, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, csrf TEXT NOT NULL, created INTEGER NOT NULL, expires INTEGER NOT NULL, remember INTEGER NOT NULL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS attempts(k TEXT NOT NULL, ts INTEGER NOT NULL); CREATE INDEX IF NOT EXISTS att_k ON attempts(k, ts);
    CREATE TABLE IF NOT EXISTS favs(user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, data TEXT NOT NULL, updated INTEGER NOT NULL);");
} catch (Throwable $e) { fail('server_db', 500); }

/* ---------- ابزارها ---------- */
function now(): int { return time(); }
function ip_hash(array $CFG): string { return substr(hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . '|' . $CFG['salt']), 0, 24); }
function body(): array {
  $ct = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? '')); if (strpos($ct, 'application/json') !== 0) fail('bad_request');
  $raw = (string)file_get_contents('php://input', false, null, 0, 40000); $j = json_decode($raw, true); if (!is_array($j)) fail('bad_request'); return $j;
}
function guard_post(string $HOST): void {   // درخواست‌های تغییردهنده فقط از خود سایت (هدر سفارشی ⇒ preflight ⇒ بدون CORS مسدود)
  if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') fail('method', 405);
  if (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'MetStat') fail('csrf', 403);
  $o = (string)($_SERVER['HTTP_ORIGIN'] ?? ''); if ($o !== '') { $oh = strtolower((string)parse_url($o, PHP_URL_HOST)); if ($oh !== $HOST) fail('csrf', 403); }
}
function rate(PDO $DB, string $k, int $win, int $max, bool $count = true): void {
  $t = now(); $DB->prepare('DELETE FROM attempts WHERE ts<?')->execute([$t - 86400]);
  $q = $DB->prepare('SELECT COUNT(*) c FROM attempts WHERE k=? AND ts>?'); $q->execute([$k, $t - $win]); if ((int)$q->fetch()['c'] >= $max) fail('rate_limited', 429, ['retry' => $win]);
  if ($count) $DB->prepare('INSERT INTO attempts(k,ts) VALUES(?,?)')->execute([$k, $t]);
}
function rate_hit(PDO $DB, string $k): void { $DB->prepare('INSERT INTO attempts(k,ts) VALUES(?,?)')->execute([$k, now()]); }
function rate_clear(PDO $DB, string $k): void { $DB->prepare('DELETE FROM attempts WHERE k=?')->execute([$k]); }

/* ---------- اعتبارسنجی ---------- */
const RESERVED = ['admin', 'administrator', 'root', 'support', 'system', 'metstat', 'wtafkik', 'moderator', 'staff', 'info', 'webmaster', 'postmaster', 'null', 'undefined', 'api', 'auth', 'login', 'register'];
function v_username(string $u): bool { return (bool)preg_match('/^[A-Za-z][A-Za-z0-9_]{2,19}$/', $u); }
function v_name(string $n): bool { return (bool)preg_match("/^[A-Za-z][A-Za-z '\\-]{0,39}$/", $n); }
function v_email(string $e): bool { return strlen($e) <= 120 && (bool)preg_match('/^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$/', $e) && filter_var($e, FILTER_VALIDATE_EMAIL) !== false; }
function v_pass(string $p, string $u): ?string {
  if (!preg_match('/^[\x21-\x7E]{8,128}$/', $p)) return 'pw_weak';
  if (!preg_match('/[a-z]/', $p) || !preg_match('/[A-Z]/', $p) || !preg_match('/[^A-Za-z]/', $p)) return 'pw_weak';
  if ($u !== '' && stripos($p, $u) !== false) return 'pw_weak';
  if (in_array(strtolower($p), ['password1!', 'qwerty123!', 'password123', 'p@ssw0rd', 'p@ssword1', 'admin1234!', '12345678aA!'], true)) return 'pw_weak';
  return null;
}
function ph_hash(string $p): string { return password_hash($p, defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT, defined('PASSWORD_ARGON2ID') ? [] : ['cost' => 12]); }
const DUMMY_B = '$2y$12$6yX4DDXKPfL4nvyPw12r0OEqIO/yE/sy9U8hCmml6DN5vRs/paxre';
const DUMMY_A = '$argon2id$v=19$m=65536,t=4,p=1$c0svV1BtRUJLUkRKMHVTdw$am+EHuX84eQ2uw2U2Lxhhyl6OHSVFvJ8xqoi+L7AKF8'; // هش ساختگی برای هم‌زمان‌سازی زمان پاسخ وقتی کاربر وجود ندارد

/* ---------- نشست ---------- */
function cookie_set(string $v, int $exp, bool $https): void { setcookie('ms_sess', $v, ['expires' => $exp, 'path' => '/', 'secure' => $https, 'httponly' => true, 'samesite' => 'Lax']); }
function session_new(PDO $DB, int $uid, bool $remember, array $CFG, bool $https): string {
  $tok = bin2hex(random_bytes(32)); $csrf = bin2hex(random_bytes(24)); $t = now(); $exp = $t + ($remember ? 86400 * (int)$CFG['session_days'] : 86400);
  $DB->prepare('INSERT INTO sessions(token_hash,user_id,csrf,created,expires,remember) VALUES(?,?,?,?,?,?)')->execute([hash('sha256', $tok), $uid, $csrf, $t, $exp, $remember ? 1 : 0]);
  $DB->prepare('UPDATE users SET last_login=? WHERE id=?')->execute([$t, $uid]);
  cookie_set($tok, $remember ? $exp : 0, $https); return $csrf;
}
function cur_user(PDO $DB, array $CFG, bool $https): ?array {
  $tok = (string)($_COOKIE['ms_sess'] ?? ''); if (!preg_match('/^[a-f0-9]{64}$/', $tok)) return null;
  $q = $DB->prepare('SELECT s.id sid, s.csrf, s.expires, s.remember, u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires>?'); $q->execute([hash('sha256', $tok), now()]); $r = $q->fetch();
  if (!$r) return null;
  if ((int)$r['remember'] === 1 && $r['expires'] - now() < 86400 * ((int)$CFG['session_days'] - 1)) { try { $e = now() + 86400 * (int)$CFG['session_days']; $DB->prepare('UPDATE sessions SET expires=? WHERE id=?')->execute([$e, $r['sid']]); cookie_set($tok, $e, $https); } catch (Throwable $ex) { /* تمدید نشست اختیاری است؛ قفل موقت SQLite نباید خطای 500 بدهد */ } }
  return $r;
}
function pub(array $u): array { return ['username' => $u['username'], 'first' => $u['first'], 'last' => $u['last'], 'role' => $u['role'], 'plan' => $u['plan'], 'email' => $u['email'], 'google' => $u['google_sub'] !== null && $u['google_sub'] !== '']; }
function need_user(PDO $DB, array $CFG, bool $https, bool $csrf = true): array {
  $u = cur_user($DB, $CFG, $https); if (!$u) fail('auth', 401);
  if ($csrf && !hash_equals((string)$u['csrf'], (string)($_SERVER['HTTP_X_CSRF'] ?? ''))) fail('csrf', 403);
  return $u;
}

/* ---------- ایمیل خوش‌آمد ---------- */
function mail_welcome(array $CFG, string $to, string $first, string $user): void {
  $site = $CFG['site_name']; $subj = '=?UTF-8?B?' . base64_encode("ثبت‌نام شما در $site موفقیت‌آمیز بود") . '?=';
  $txt = "سلام $first عزیز،\n\nثبت‌نام شما در سایت $site (نقشه‌های آماری هواشناسی) با موفقیت انجام شد.\nنام کاربری: $user\n\nاگر شما این ثبت‌نام را انجام نداده‌اید، به این ایمیل پاسخ دهید.\n\n— Hello $first, your registration was successful. Username: $user.\n";
  $h = "From: $site <{$CFG['mail_from']}>\r\nMIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\nX-Mailer: MetStat";
  @mail($to, $subj, chunk_split(base64_encode($txt)), $h);
}

/* ---------- ایجاد کاربر (مشترک) ---------- */
function user_create(PDO $DB, array $f, ?string $hash, ?string $gsub, string $role = 'user'): int {
  try {
    $DB->prepare('INSERT INTO users(username,email,first,last,pw_hash,google_sub,role,plan,created_at) VALUES(?,?,?,?,?,?,?,?,?)')->execute([$f['username'], strtolower($f['email']), $f['first'], $f['last'], $hash, $gsub, $role, 'free', now()]);
    return (int)$DB->lastInsertId();
  } catch (PDOException $e) {
    $m = $e->getMessage(); if (stripos($m, 'users.username') !== false) fail('username_taken', 409); if (stripos($m, 'users.email') !== false) fail('email_taken', 409); if (stripos($m, 'google_sub') !== false) fail('email_taken', 409); throw $e;
  }
}
function name_ascii(string $s, string $fb): string {
  $t = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s); $t = preg_replace("/[^A-Za-z '\\-]/", '', (string)$t); $t = trim(substr((string)$t, 0, 40));
  return v_name($t) ? $t : $fb;
}

/* =========================== مسیریابی =========================== */
$a = (string)($_GET['a'] ?? ''); $ipk = ip_hash($CFG);

if ($a === 'me') {
  $u = cur_user($DB, $CFG, $HTTPS); $adm = (int)$DB->query("SELECT COUNT(*) c FROM users WHERE role='admin'")->fetch()['c'];
  out(['ok' => true, 'user' => $u ? pub($u) : null, 'csrf' => $u ? $u['csrf'] : null, 'google' => $CFG['google_client_id'], 'need_admin_setup' => $adm === 0 && strlen($CFG['setup_key']) >= 16]);
}
if ($a === 'check') {
  rate($DB, 'chk:' . $ipk, 600, 60);
  $u = (string)($_GET['u'] ?? ''); if (!v_username($u)) out(['ok' => true, 'valid' => false, 'available' => false]);
  $res = in_array(strtolower($u), RESERVED, true); $q = $DB->prepare('SELECT 1 FROM users WHERE username=?'); $q->execute([$u]);
  out(['ok' => true, 'valid' => true, 'available' => !$res && !$q->fetch()]);
}

guard_post($HOST); $b = body();
$S = fn($k) => is_string($b[$k] ?? null) ? trim((string)$b[$k]) : '';

if ($a === 'register') {
  rate($DB, 'reg:' . $ipk, 3600, 12);
  $f = ['first' => $S('first'), 'last' => $S('last'), 'username' => $S('username'), 'email' => $S('email')]; $p = is_string($b['password'] ?? null) ? $b['password'] : ''; $p2 = is_string($b['password2'] ?? null) ? $b['password2'] : '';
  if (!v_name($f['first']) || !v_name($f['last'])) fail('name_invalid', 422);
  if (!v_username($f['username']) || in_array(strtolower($f['username']), RESERVED, true)) fail('username_invalid', 422);
  if (!v_email($f['email'])) fail('email_invalid', 422);
  if (($e = v_pass($p, $f['username'])) !== null) fail($e, 422);
  if (!hash_equals($p, $p2)) fail('pw_mismatch', 422);
  $uid = user_create($DB, $f, ph_hash($p), null);
  $csrf = session_new($DB, $uid, true, $CFG, $HTTPS); mail_welcome($CFG, $f['email'], $f['first'], $f['username']);
  $u = $DB->query('SELECT * FROM users WHERE id=' . (int)$uid)->fetch(); out(['ok' => true, 'user' => pub($u), 'csrf' => $csrf, 'first_login' => true]);
}
if ($a === 'login') {
  $un = $S('username'); $p = is_string($b['password'] ?? null) ? $b['password'] : '';
  if (!v_username($un) || strlen($p) < 1 || strlen($p) > 128) { rate_hit($DB, 'ip:' . $ipk); fail('bad_credentials', 401); }
  $lk = 'lu:' . strtolower($un) . '|' . $ipk; rate($DB, $lk, 900, 5, false); rate($DB, 'ug:' . strtolower($un), 900, 40, false); rate($DB, 'ip:' . $ipk, 900, 30, false);   // کاربر+IP: ۵ بار؛ کل جهان برای یک کاربر: ۴۰؛ هر IP: ۳۰
  $q = $DB->prepare('SELECT * FROM users WHERE username=?'); $q->execute([$un]); $u = $q->fetch();
  $ok = password_verify($p, ($u && $u['pw_hash']) ? $u['pw_hash'] : (defined('PASSWORD_ARGON2ID') && DUMMY_A !== '' ? DUMMY_A : DUMMY_B)) && $u && $u['pw_hash'];
  if (!$ok) { rate_hit($DB, $lk); rate_hit($DB, 'ug:' . strtolower($un)); rate_hit($DB, 'ip:' . $ipk); fail('bad_credentials', 401); }
  rate_clear($DB, $lk);
  if (password_needs_rehash($u['pw_hash'], defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT)) $DB->prepare('UPDATE users SET pw_hash=? WHERE id=?')->execute([ph_hash($p), $u['id']]);
  $csrf = session_new($DB, (int)$u['id'], !empty($b['remember']), $CFG, $HTTPS); out(['ok' => true, 'user' => pub($u), 'csrf' => $csrf]);
}
if ($a === 'google') {
  rate($DB, 'gg:' . $ipk, 900, 30); if ($CFG['google_client_id'] === '') fail('google_off', 503);
  $cred = $S('credential'); $mode = $S('mode') === 'register' ? 'register' : 'login'; if (!preg_match('/^[A-Za-z0-9_\-.]{50,4000}$/', $cred)) fail('bad_request');
  $url = 'https://oauth2.googleapis.com/tokeninfo?id_token=' . rawurlencode($cred); $raw = false;
  if (function_exists('curl_init')) { $c = curl_init($url); curl_setopt_array($c, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10, CURLOPT_SSL_VERIFYPEER => true]); $raw = curl_exec($c); curl_close($c); }
  else { $raw = @file_get_contents($url, false, stream_context_create(['http' => ['timeout' => 10]])); }
  $t = is_string($raw) ? json_decode($raw, true) : null;
  if (!is_array($t) || ($t['aud'] ?? '') !== $CFG['google_client_id'] || !in_array($t['iss'] ?? '', ['accounts.google.com', 'https://accounts.google.com'], true) || (int)($t['exp'] ?? 0) < now() || ($t['email_verified'] ?? '') !== 'true' || empty($t['email']) || empty($t['sub'])) fail('google_invalid', 401);
  $email = strtolower((string)$t['email']); $sub = (string)$t['sub'];
  $q = $DB->prepare('SELECT * FROM users WHERE google_sub=? OR email=?'); $q->execute([$sub, $email]); $u = $q->fetch();
  if ($mode === 'login') {
    if (!$u) fail('not_registered', 404);
    if (!$u['google_sub']) $DB->prepare('UPDATE users SET google_sub=? WHERE id=?')->execute([$sub, $u['id']]);   // ایمیل تأییدشدهٔ گوگل = همان صاحب حساب
    $csrf = session_new($DB, (int)$u['id'], true, $CFG, $HTTPS); out(['ok' => true, 'user' => pub($u), 'csrf' => $csrf]);
  }
  if ($u) fail('email_taken', 409);
  if (!v_email($email)) fail('email_invalid', 422);
  $base = preg_replace('/[^A-Za-z0-9_]/', '', explode('@', $email)[0]); if (!preg_match('/^[A-Za-z]/', $base)) $base = 'user' . $base; $base = substr($base, 0, 14); if (strlen($base) < 3) $base = 'user';
  $un = $base; for ($i = 0; $i < 30; $i++) { $q = $DB->prepare('SELECT 1 FROM users WHERE username=?'); $q->execute([$un]); if (!$q->fetch() && !in_array(strtolower($un), RESERVED, true)) break; $un = $base . random_int(10, 99999); $un = substr($un, 0, 20); }
  $f = ['username' => $un, 'email' => $email, 'first' => name_ascii((string)($t['given_name'] ?? ''), 'User'), 'last' => name_ascii((string)($t['family_name'] ?? ''), 'Google')];
  $uid = user_create($DB, $f, null, $sub); $csrf = session_new($DB, $uid, true, $CFG, $HTTPS); mail_welcome($CFG, $email, $f['first'], $un);
  $u = $DB->query('SELECT * FROM users WHERE id=' . (int)$uid)->fetch(); out(['ok' => true, 'user' => pub($u), 'csrf' => $csrf, 'first_login' => true]);
}
if ($a === 'logout') {
  $u = cur_user($DB, $CFG, $HTTPS); if ($u) { $DB->prepare('DELETE FROM sessions WHERE id=?')->execute([$u['sid']]); } cookie_set('', now() - 3600, $HTTPS); out(['ok' => true]);
}
if ($a === 'fav_get') { $u = need_user($DB, $CFG, $HTTPS, false); $q = $DB->prepare('SELECT data FROM favs WHERE user_id=?'); $q->execute([$u['id']]); $r = $q->fetch(); out(['ok' => true, 'items' => $r ? (json_decode($r['data'], true) ?: []) : []]); }
if ($a === 'fav_set') {
  $u = need_user($DB, $CFG, $HTTPS); $it = $b['items'] ?? null; if (!is_array($it) || count($it) > 100) fail('bad_request'); $clean = [];
  foreach ($it as $x) { if (!is_array($x)) continue; $t = is_string($x['t'] ?? null) ? mb_substr($x['t'], 0, 80) : ''; $h = is_string($x['h'] ?? null) ? $x['h'] : '';
    if ($t === '' || !preg_match('~^#?[A-Za-z0-9/_\-.?=&%:]{0,160}$~', $h)) continue; $clean[] = ['t' => $t, 'h' => $h]; }
  $DB->prepare('INSERT INTO favs(user_id,data,updated) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET data=excluded.data, updated=excluded.updated')->execute([$u['id'], json_encode($clean, JSON_UNESCAPED_UNICODE), now()]); out(['ok' => true, 'items' => $clean]);
}
/* ===================== r192: تأیید ماهانهٔ ورود آمار روزانهٔ ایستگاه‌ها به پایگاه اطلس اقلیمی =====================
 * ds_notice  (سرور↔سرور، کلید ds_key در auth_config.php، هدر X-Ds-Key): GitHub اول هر ماه آمار ماه قبل را اعلام می‌کند؛ رکورد «در انتظار» + پیام به مدیر.
 * ds_list / ds_decide (فقط مدیر، CSRF): مشاهده و تأیید/رد. ds_approved / ds_ack (کلید): workflow ماه‌های تأییدشده را می‌گیرد، به پایگاه اطلس می‌افزاید و ثبت می‌کند. */
if (strpos($a, 'ds_') === 0) {
  $DB->exec("CREATE TABLE IF NOT EXISTS ds_months(month TEXT PRIMARY KEY, status TEXT NOT NULL DEFAULT 'pending', info TEXT, created INTEGER NOT NULL, decided INTEGER, decided_by INTEGER, merged INTEGER NOT NULL DEFAULT 0)");
  $dsKey = function () use ($CFG) { $k = (string)($CFG['ds_key'] ?? ''); if (strlen($k) < 16) fail('ds_off', 503); if (!hash_equals($k, (string)($_SERVER['HTTP_X_DS_KEY'] ?? ''))) fail('forbidden', 403); };
  if ($a === 'ds_notice') {
    $dsKey(); rate($DB, 'dsn:' . $ipk, 3600, 30); $m = $S('month'); if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $m)) fail('bad_request', 422);
    $info = json_encode(['rows' => (int)($b['rows'] ?? 0), 'stations' => (int)($b['stations'] ?? 0), 'file' => mb_substr($S('file'), 0, 120), 'days' => (int)($b['days'] ?? 0)], JSON_UNESCAPED_UNICODE);
    $q = $DB->prepare('SELECT status FROM ds_months WHERE month=?'); $q->execute([$m]); $ex = $q->fetch();
    if ($ex) out(['ok' => true, 'exists' => true, 'status' => $ex['status']]);
    $DB->prepare('INSERT INTO ds_months(month,status,info,created) VALUES(?,?,?,?)')->execute([$m, 'pending', $info, now()]);
    try {   // پیام درون‌سامانه‌ای به مدیر (اگر جدول پیام‌ها ساخته شده باشد)
      $adm = $DB->query("SELECT id FROM users WHERE role='admin' ORDER BY id LIMIT 1")->fetch(); $has = $DB->query("SELECT name FROM sqlite_master WHERE type='table' AND name='msgs'")->fetch();
      if ($adm && $has) { $aid = (int)$adm['id']; $K = msg_key($CFG, $DIR); $j = json_decode($info, true);
        $DB->prepare('INSERT INTO msgs(thread,from_id,to_id,payload,created) VALUES(0,?,?,?,?)')->execute([$aid, $aid, msg_enc($K, ['s' => "تأیید آمار روزانهٔ ایستگاه‌ها برای ماه $m", 'b' => "آمار ۲۴ساعتهٔ ماه $m (" . $j['stations'] . " ایستگاه، " . $j['rows'] . " ردیف) آمادهٔ افزودن به پایگاه اطلس اقلیمی است. از منوی حساب ← «تأیید آمار ماهانه» تأیید یا رد کنید."]), now()]);
        $id = (int)$DB->lastInsertId(); $DB->prepare('UPDATE msgs SET thread=? WHERE id=?')->execute([$id, $id]); }
    } catch (Throwable $e) {}
    out(['ok' => true, 'status' => 'pending']);
  }
  if ($a === 'ds_approved') { $dsKey(); $L = $DB->query("SELECT month, info FROM ds_months WHERE status='approved' AND merged=0 ORDER BY month")->fetchAll(PDO::FETCH_ASSOC); out(['ok' => true, 'months' => array_column($L, 'month')]); }
  if ($a === 'ds_ack') { $dsKey(); $m = $S('month'); if (!preg_match('/^\d{4}-\d{2}$/', $m)) fail('bad_request', 422); $DB->prepare('UPDATE ds_months SET merged=1 WHERE month=? AND status=?')->execute([$m, 'approved']); out(['ok' => true]); }
  $u = need_user($DB, $CFG, $HTTPS); if ($u['role'] !== 'admin') fail('forbidden', 403);
  if ($a === 'ds_list') { $L = $DB->query('SELECT month,status,info,created,decided,merged FROM ds_months ORDER BY month DESC LIMIT 36')->fetchAll(PDO::FETCH_ASSOC); foreach ($L as &$r) $r['info'] = json_decode((string)$r['info'], true); out(['ok' => true, 'list' => $L]); }
  if ($a === 'ds_decide') {
    $m = $S('month'); $dec = $S('decision'); if (!preg_match('/^\d{4}-\d{2}$/', $m) || !in_array($dec, ['approve', 'reject'], true)) fail('bad_request', 422);
    $st = $DB->prepare('UPDATE ds_months SET status=?, decided=?, decided_by=? WHERE month=? AND merged=0'); $st->execute([$dec === 'approve' ? 'approved' : 'rejected', now(), (int)$u['id'], $m]); if (!$st->rowCount()) fail('not_found', 404);
    out(['ok' => true, 'status' => $dec === 'approve' ? 'approved' : 'rejected']);
  }
  fail('unknown_action', 404);
}
if ($a === 'update_me') {   // r191: ویرایش مشخصات توسط خود کاربر (نام، نام‌خانوادگی، ایمیل، نام کاربری). تغییر ایمیل/نام‌کاربری نیازمند رمز فعلی است (حساب فقط‌گوگل: بدون رمز)
  $u = need_user($DB, $CFG, $HTTPS); rate($DB, 'upd:' . $u['id'], 3600, 20);
  $f = ['first' => $S('first') ?: $u['first'], 'last' => $S('last') ?: $u['last'], 'username' => $S('username') ?: $u['username'], 'email' => strtolower($S('email') ?: $u['email'])];
  if (!v_name($f['first']) || !v_name($f['last'])) fail('name_invalid', 422);
  if (!v_email($f['email'])) fail('email_invalid', 422);
  $uchg = strcasecmp($f['username'], $u['username']) !== 0; $echg = strcasecmp($f['email'], $u['email']) !== 0;
  if ($uchg) { if ($u['role'] === 'admin') fail('forbidden', 403); if (!v_username($f['username']) || in_array(strtolower($f['username']), RESERVED, true)) fail('username_invalid', 422); }
  if (($uchg || $echg) && $u['pw_hash']) { $p = is_string($b['password'] ?? null) ? $b['password'] : ''; rate($DB, 'updpw:' . $u['id'], 900, 6); if (!password_verify($p, $u['pw_hash'])) fail('bad_credentials', 401); }
  try { $DB->prepare('UPDATE users SET first=?, last=?, username=?, email=? WHERE id=?')->execute([$f['first'], $f['last'], $f['username'], $f['email'], $u['id']]); }
  catch (PDOException $e) { $m = $e->getMessage(); if (stripos($m, 'users.username') !== false) fail('username_taken', 409); if (stripos($m, 'users.email') !== false) fail('email_taken', 409); throw $e; }
  $n = $DB->query('SELECT * FROM users WHERE id=' . (int)$u['id'])->fetch(); out(['ok' => true, 'user' => pub($n)]);
}
if ($a === 'change_password') {   // r191: تغییر رمز: رمز فعلی (اگر حساب رمز دارد) + رمز جدید با همان قواعد ثبت‌نام؛ سایر نشست‌های کاربر باطل می‌شود
  $u = need_user($DB, $CFG, $HTTPS); rate($DB, 'cpw:' . $u['id'], 900, 6);
  $cur = is_string($b['current'] ?? null) ? $b['current'] : ''; $p = is_string($b['password'] ?? null) ? $b['password'] : ''; $p2 = is_string($b['password2'] ?? null) ? $b['password2'] : '';
  if ($u['pw_hash'] && !password_verify($cur, $u['pw_hash'])) fail('bad_credentials', 401);
  if (($e = v_pass($p, (string)$u['username'])) !== null) fail($e, 422);
  if (!hash_equals($p, $p2)) fail('pw_mismatch', 422);
  if ($u['pw_hash'] && password_verify($p, $u['pw_hash'])) fail('pw_same', 422);
  $DB->prepare('UPDATE users SET pw_hash=? WHERE id=?')->execute([ph_hash($p), $u['id']]);
  $DB->prepare('DELETE FROM sessions WHERE user_id=? AND id<>?')->execute([$u['id'], $u['sid']]); out(['ok' => true]);
}
if ($a === 'delete_me') {   // حذف حساب توسط خود کاربر (با رمز)
  $u = need_user($DB, $CFG, $HTTPS); $p = is_string($b['password'] ?? null) ? $b['password'] : ''; if ($u['role'] === 'admin') fail('forbidden', 403);
  if ($u['pw_hash']) { rate($DB, 'del:' . $u['id'], 900, 5); if (!password_verify($p, $u['pw_hash'])) fail('bad_credentials', 401); }
  $DB->prepare('DELETE FROM users WHERE id=?')->execute([$u['id']]); cookie_set('', now() - 3600, $HTTPS); out(['ok' => true]);
}
if ($a === 'admin_init') {   // یک‌بار: ساخت حساب مدیر با کلید راه‌اندازی در auth_config.php
  rate($DB, 'adm:' . $ipk, 3600, 8); $sk = $CFG['setup_key']; if (strlen($sk) < 16) fail('forbidden', 403);
  if ((int)$DB->query("SELECT COUNT(*) c FROM users WHERE role='admin'")->fetch()['c'] > 0) fail('forbidden', 403);
  if (!hash_equals($sk, $S('setup_key'))) fail('forbidden', 403);
  $f = ['first' => $S('first') ?: 'Admin', 'last' => $S('last') ?: 'Site', 'username' => $S('username'), 'email' => $S('email')]; $p = is_string($b['password'] ?? null) ? $b['password'] : '';
  if (!v_username($f['username']) || !v_email($f['email']) || !v_name($f['first']) || !v_name($f['last'])) fail('bad_request', 422);
  if (($e = v_pass($p, $f['username'])) !== null) fail($e, 422);
  $uid = user_create($DB, $f, ph_hash($p), null, 'admin'); $csrf = session_new($DB, $uid, true, $CFG, $HTTPS); $u = $DB->query('SELECT * FROM users WHERE id=' . (int)$uid)->fetch(); out(['ok' => true, 'user' => pub($u), 'csrf' => $csrf]);
}
if ($a === 'admin_users') {
  $u = need_user($DB, $CFG, $HTTPS); if ($u['role'] !== 'admin') fail('forbidden', 403);
  $tot = (int)$DB->query('SELECT COUNT(*) c FROM users')->fetch()['c']; $gg = (int)$DB->query("SELECT COUNT(*) c FROM users WHERE google_sub IS NOT NULL AND pw_hash IS NULL")->fetch()['c'];
  $on = (int)$DB->query('SELECT COUNT(DISTINCT user_id) c FROM sessions WHERE expires>' . now())->fetch()['c'];
  $rows = $DB->query("SELECT username, first, last, email, role, plan, created_at, last_login, CASE WHEN pw_hash IS NULL THEN 'google' WHEN google_sub IS NOT NULL THEN 'both' ELSE 'password' END AS method FROM users ORDER BY id DESC LIMIT 1000")->fetchAll();
  out(['ok' => true, 'total' => $tot, 'google_only' => $gg, 'active_sessions' => $on, 'users' => $rows]);   // پسورد/هش هرگز انتخاب یا برگردانده نمی‌شود
}
if ($a === 'admin_delete') {
  $u = need_user($DB, $CFG, $HTTPS); if ($u['role'] !== 'admin') fail('forbidden', 403); $un = $S('username'); if (!v_username($un)) fail('bad_request');
  $q = $DB->prepare('SELECT id, role FROM users WHERE username=?'); $q->execute([$un]); $t = $q->fetch(); if (!$t) fail('not_found', 404); if ($t['role'] === 'admin') fail('forbidden', 403);
  $DB->prepare('DELETE FROM users WHERE id=?')->execute([$t['id']]); out(['ok' => true]);
}
/* ===================== r120: پیام‌رسان داخلی (کاربر ⇄ مدیر) =====================
 * فقط عضو واردشده می‌فرستد؛ گیرندهٔ پیام کاربر همیشه مدیر است؛ مدیر فقط «پاسخ» می‌دهد.
 * متن و موضوع با AES-256-GCM رمز می‌شود (کلید: msg_key در auth_config.php یا فایل msg.key کنار پایگاه داده با دسترسی ۰۶۰۰).
 * هر کاربر فقط پیام‌های خودش (فرستاده/دریافتی) را می‌بیند؛ بررسی مالکیت روی هر درخواست سمت سرور انجام می‌شود. */
function msg_key(array $CFG, string $DIR): string {
  if (!empty($CFG['msg_key'])) return hash('sha256', (string)$CFG['msg_key'], true);
  $p = dirname(db_path($CFG, $DIR)) . '/msg.key';
  if (!is_file($p)) { @file_put_contents($p, bin2hex(random_bytes(32))); @chmod($p, 0600); }
  return hash('sha256', (string)@file_get_contents($p), true);
}
function msg_enc(string $k, array $pl): string { $iv = random_bytes(12); $tag = ''; $c = openssl_encrypt(json_encode($pl, JSON_UNESCAPED_UNICODE), 'aes-256-gcm', $k, OPENSSL_RAW_DATA, $iv, $tag); return base64_encode($iv . $tag . $c); }
function msg_dec(string $k, string $s): array {
  $r = base64_decode($s, true); if ($r === false || strlen($r) < 29) return ['s' => '', 'b' => ''];
  $p = openssl_decrypt(substr($r, 28), 'aes-256-gcm', $k, OPENSSL_RAW_DATA, substr($r, 0, 12), substr($r, 12, 16)); $j = $p === false ? null : json_decode($p, true); return is_array($j) ? $j + ['s' => '', 'b' => ''] : ['s' => '', 'b' => ''];
}
if (strpos($a, 'msg_') === 0) {
  $DB->exec("CREATE TABLE IF NOT EXISTS msgs(id INTEGER PRIMARY KEY AUTOINCREMENT, thread INTEGER NOT NULL, from_id INTEGER NOT NULL, to_id INTEGER NOT NULL, payload TEXT NOT NULL, created INTEGER NOT NULL, is_read INTEGER NOT NULL DEFAULT 0, del_from INTEGER NOT NULL DEFAULT 0, del_to INTEGER NOT NULL DEFAULT 0);
    CREATE INDEX IF NOT EXISTS msg_to ON msgs(to_id, del_to, is_read); CREATE INDEX IF NOT EXISTS msg_from ON msgs(from_id, del_from);");
  $u = need_user($DB, $CFG, $HTTPS); $uid = (int)$u['id']; $K = msg_key($CFG, $DIR);
  $adm = $DB->query("SELECT id FROM users WHERE role='admin' ORDER BY id LIMIT 1")->fetch(); $admId = $adm ? (int)$adm['id'] : 0;
  $uname = function (int $i) use ($DB) { $q = $DB->prepare('SELECT username, first, last, role FROM users WHERE id=?'); $q->execute([$i]); $r = $q->fetch(); return $r ? ['username' => $r['username'], 'name' => trim($r['first'] . ' ' . $r['last']), 'admin' => $r['role'] === 'admin'] : ['username' => '—', 'name' => '', 'admin' => false]; };
  $cnt = function () use ($DB, $uid) { $q = $DB->prepare('SELECT COUNT(*) c FROM msgs WHERE to_id=? AND del_to=0 AND is_read=0'); $q->execute([$uid]); return (int)$q->fetch()['c']; };
  if ($a === 'msg_count') out(['ok' => true, 'unread' => $cnt()]);
  if ($a === 'msg_send') {
    rate($DB, 'msg:' . $uid, 3600, 20); $sub = mb_substr($S('subject'), 0, 120); $bd = mb_substr(is_string($b['body'] ?? null) ? trim($b['body']) : '', 0, 4000); if (mb_strlen($bd) < 2) fail('bad_request', 422);
    $thread = 0; $to = $admId;
    if ($u['role'] === 'admin') {   // مدیر فقط به پیام دریافتی پاسخ می‌دهد
      $rid = (int)($b['reply_to'] ?? 0); $q = $DB->prepare('SELECT * FROM msgs WHERE id=? AND to_id=?'); $q->execute([$rid, $uid]); $m = $q->fetch(); if (!$m) fail('not_found', 404);
      $to = (int)$m['from_id']; $thread = (int)$m['thread']; if ($sub === '') $sub = 'Re: ' . mb_substr(msg_dec($K, $m['payload'])['s'], 0, 110);
    } else {
      if (!$admId) fail('no_admin', 503); $rid = (int)($b['reply_to'] ?? 0);
      if ($rid) { $q = $DB->prepare('SELECT thread FROM msgs WHERE id=? AND (to_id=? OR from_id=?)'); $q->execute([$rid, $uid, $uid]); $m = $q->fetch(); if ($m) $thread = (int)$m['thread']; }
    }
    $DB->prepare('INSERT INTO msgs(thread,from_id,to_id,payload,created) VALUES(?,?,?,?,?)')->execute([$thread, $uid, $to, msg_enc($K, ['s' => $sub, 'b' => $bd]), now()]);
    $id = (int)$DB->lastInsertId(); if (!$thread) $DB->prepare('UPDATE msgs SET thread=? WHERE id=?')->execute([$id, $id]);
    out(['ok' => true, 'id' => $id]);
  }
  if ($a === 'msg_list') {
    $box = $S('box') === 'sent' ? 'sent' : 'inbox';
    $q = $DB->prepare($box === 'sent' ? 'SELECT * FROM msgs WHERE from_id=? AND del_from=0 ORDER BY id DESC LIMIT 200' : 'SELECT * FROM msgs WHERE to_id=? AND del_to=0 ORDER BY id DESC LIMIT 200'); $q->execute([$uid]); $L = [];
    foreach ($q->fetchAll() as $m) { $d = msg_dec($K, $m['payload']); $o = $uname((int)($box === 'sent' ? $m['to_id'] : $m['from_id'])); $L[] = ['id' => (int)$m['id'], 'thread' => (int)$m['thread'], 'who' => $o['admin'] ? 'admin' : $o['username'], 'name' => $o['name'], 'subject' => $d['s'], 'snippet' => mb_substr($d['b'], 0, 90), 'ts' => (int)$m['created'], 'read' => (int)$m['is_read'] === 1 || $box === 'sent']; }
    out(['ok' => true, 'box' => $box, 'list' => $L, 'unread' => $cnt()]);
  }
  if ($a === 'msg_get') {   // خواندن = ثبت «خوانده‌شده» (فقط برای گیرنده) و کم‌شدن از شمارنده
    $id = (int)($b['id'] ?? 0); $q = $DB->prepare('SELECT * FROM msgs WHERE id=? AND ((to_id=? AND del_to=0) OR (from_id=? AND del_from=0))'); $q->execute([$id, $uid, $uid]); $m = $q->fetch(); if (!$m) fail('not_found', 404);
    if ((int)$m['to_id'] === $uid && (int)$m['is_read'] === 0) $DB->prepare('UPDATE msgs SET is_read=1 WHERE id=?')->execute([$id]);
    $d = msg_dec($K, $m['payload']); $fr = $uname((int)$m['from_id']); $to = $uname((int)$m['to_id']);
    out(['ok' => true, 'msg' => ['id' => $id, 'thread' => (int)$m['thread'], 'from' => $fr['admin'] ? 'admin' : $fr['username'], 'from_name' => $fr['name'], 'to' => $to['admin'] ? 'admin' : $to['username'], 'subject' => $d['s'], 'body' => $d['b'], 'ts' => (int)$m['created'], 'mine' => (int)$m['from_id'] === $uid], 'unread' => $cnt()]);
  }
  if ($a === 'msg_del') {
    $id = (int)($b['id'] ?? 0); $q = $DB->prepare('SELECT from_id,to_id FROM msgs WHERE id=?'); $q->execute([$id]); $m = $q->fetch(); if (!$m) fail('not_found', 404);
    if ((int)$m['to_id'] === $uid) $DB->prepare('UPDATE msgs SET del_to=1 WHERE id=?')->execute([$id]); elseif ((int)$m['from_id'] === $uid) $DB->prepare('UPDATE msgs SET del_from=1 WHERE id=?')->execute([$id]); else fail('not_found', 404);
    $DB->prepare('DELETE FROM msgs WHERE id=? AND del_from=1 AND del_to=1')->execute([$id]); out(['ok' => true, 'unread' => $cnt()]);
  }
  fail('unknown_action', 404);
}
fail('unknown_action', 404);
