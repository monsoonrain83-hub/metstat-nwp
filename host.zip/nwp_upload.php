<?php
/* =====================================================================
 * MetStat — دریافت نقشه‌های مدل‌های عددی از nwp_maps.py (GitHub Actions)
 *   POST nwp_upload.php?a=begin&key=…  (JSON: model, run, name, label, params)  → شروع اجرای جدید یک مدل؛
 *        دو اجرای آخر هر مدل نگه داشته می‌شود (اجرای جاری + اجرای قبلی)؛ اجراهای قدیمی‌تر همین حالا پاک می‌شوند. فهرست فایل‌های موجود برگردانده می‌شود.
 *   POST nwp_upload.php?a=put&key=…    (multipart: model, run, file, meta, png)   → ذخیرهٔ یک نقشه
 *   POST nwp_upload.php?a=sync&key=…   (JSON: model, run)                          → بازسازی فهرست کلی
 *   POST nwp_upload.php?a=end&key=…    (JSON: model, run)                          → پایان اجرا
 *   r58 (ادغام همهٔ شاخه‌ها): eu + grid + geo + cmip + gpccput + sfput + rrput + فهرست فشردهٔ webp
 *   POST nwp_upload.php?a=cmipput / gridput / gridend  (r65: CMIP6 JSON؛ بستهٔ شبکهٔ ECMWF)
 *   POST nwp_upload.php?a=clim&key=…                                               → فایل اقلیم (فقط برای اسکریپت، با کلید)
 *   r102o: کلید ترجیحاً در بدنهٔ POST (key) یا هدر X-Upload-Key؛ ?key= فقط برای سازگاری با اسکریپت‌های قدیمی (در لاگ سرور ثبت می‌شود). قفل index.json افزوده شد.
 *   r102j: POST nwp_upload.php?a=onsetput&key=… (multipart: name, f) → data/onset/ (آغاز/پایان فصل CHIRPS)
 *   POST nwp_upload.php?a=idxput&key=… (multipart: id, per, meta, png[, ser])      → نمودار شاخص اقلیمی (تصویر + سری عددی کوچک اختیاری <id>.json)
 *   POST nwp_upload.php?a=idxend&key=…                                             → پایان به‌روزرسانی شاخص‌ها
 * کلید: همان "upload_key" در mx_config.json.
 * پوشه‌ها: data/nwp/<model>/<run>/<region>/<param>_<valid>.png ؛ فهرست کلی: data/manifest.json
 * ===================================================================== */
declare(strict_types=1);
/* r119: خطای مرگبار PHP (حافظه/زمان/…) دیگر «HTTP 500 بی‌پاسخ» نمی‌شود: در data/fetch.log و data/nwp_lasterr.json ثبت می‌شود و بدنهٔ JSON برمی‌گردد */
@ini_set('memory_limit', '512M'); @ini_set('display_errors', '0'); @set_time_limit(110);
register_shutdown_function(function () {
    $e = error_get_last(); if (!$e || !in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR], true)) return;
    $d = __DIR__ . '/data'; $m = substr(str_replace(__DIR__, '', (string)$e['message']), 0, 300) . ' @' . basename((string)$e['file']) . ':' . $e['line'];
    @file_put_contents("$d/nwp_lasterr.json", json_encode(['t' => gmdate('c'), 'a' => $_GET['a'] ?? '', 'm' => $m, 'mem' => memory_get_peak_usage(true)], JSON_UNESCAPED_UNICODE));
    @file_put_contents("$d/fetch.log", gmdate('Y-m-d H:i:s') . " [nwp] FATAL a=" . ($_GET['a'] ?? '') . " $m\n", FILE_APPEND);
    if (!headers_sent()) { http_response_code(500); header('Content-Type: application/json; charset=utf-8'); echo json_encode(['error' => 'fatal', 'msg' => $m], JSON_UNESCAPED_UNICODE); }
});
date_default_timezone_set('UTC');
header('Cache-Control: no-store');
$DIR = __DIR__; $DATA = "$DIR/data"; $NWP = "$DATA/nwp"; @mkdir($NWP, 0755, true);
function jout($v, int $c = 200): void { http_response_code($c); header('Content-Type: application/json; charset=utf-8'); echo json_encode($v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit; }
function jload(string $f, $d) { return is_file($f) ? (json_decode((string)file_get_contents($f), true) ?? $d) : $d; }
/* r119b: نوشتن امن — اگر دیسک/سهمیه پر باشد فایل نیمه‌کاره جایگزین فایل سالم نمی‌شود و پاسخ 507 می‌رود (آپلودر پایتون دوباره تلاش می‌کند) */
function wsafe(string $dst, string $data): bool { $t = "$dst.tmp" . getmypid(); $n = @file_put_contents($t, $data); if ($n === false || $n !== strlen($data)) { @unlink($t); return false; } if (!@rename($t, $dst)) { @unlink($t); return false; } return true; }
function jsave(string $f, $v): void { if (!wsafe($f, (string)json_encode($v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES))) { @file_put_contents(__DIR__ . '/data/fetch.log', gmdate('Y-m-d H:i:s') . " [nwp] ✗ نوشتن ناموفق (دیسک/سهمیه؟) " . basename($f) . "\n", FILE_APPEND); jout(['error' => 'disk', 'file' => basename($f)], 507); } }
function rrmdir(string $d): void { if (!is_dir($d)) return; foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($d, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST) as $f) { $f->isDir() ? @rmdir($f->getPathname()) : @unlink($f->getPathname()); } @rmdir($d); }
function logl(string $s): void { global $DATA; @file_put_contents("$DATA/fetch.log", gmdate('Y-m-d H:i:s') . " [nwp] $s\n", FILE_APPEND); }

$C = jload("$DIR/mx_config.json", null); if (!$C) jout(['error' => 'config'], 500);
$KEY = (string)($C['upload_key'] ?? '');
if ($KEY === '' || $KEY === 'CHANGE-ME' || !hash_equals($KEY, (string)($_SERVER['HTTP_X_UPLOAD_KEY'] ?? $_POST['key'] ?? $_GET['key'] ?? ''))) jout(['error' => 'forbidden'], 403);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') jout(['error' => 'POST only'], 405);
$a = (string)($_GET['a'] ?? '');
/* r114: توان و محدودیت‌های هاست برای آپلود دسته‌ای (چند نقشه در یک درخواست؛ بدون نیاز به افزونهٔ zip) */
function ini_bytes(string $k): int { $v = trim((string)ini_get($k)); if ($v === '') return 0; $n = (int)$v; $u = strtolower(substr($v, -1)); return $u === 'g' ? $n << 30 : ($u === 'm' ? $n << 20 : ($u === 'k' ? $n << 10 : $n)); }
function caps(): array { return ['caps' => ['putm'], 'lim' => ['files' => (int)ini_get('max_file_uploads'), 'post' => ini_bytes('post_max_size'), 'up' => ini_bytes('upload_max_filesize'), 'time' => (int)ini_get('max_execution_time')]]; }
if ($a === 'ping') jout(['ok' => true, 'v' => 'r119'] + caps());
if ($a === 'diag') {                       // r119: تشخیص هاست (با کلید): حافظه، فضای دیسک، آخرین خطای مرگبار، ۱۵ خط آخر لاگ
    $tail = []; $lf = "$DATA/fetch.log"; if (is_file($lf)) { $fh = fopen($lf, 'r'); fseek($fh, max(0, filesize($lf) - 4000)); $tail = array_slice(explode("\n", trim((string)stream_get_contents($fh))), -15); fclose($fh); }
    jout(['ok' => true, 'v' => 'r119', 'php' => PHP_VERSION, 'mem' => ini_get('memory_limit'), 'free_mb' => (int)(@disk_free_space($DIR) / 1048576), 'last_err' => jload("$DATA/nwp_lasterr.json", null), 'tail' => $tail] + caps());
}

if ($a === 'clim') {                       // اقلیم ایستگاهی شبکه‌بندی‌شده (برای انومالی دما)؛ در پوشهٔ عمومی نیست
    $f = "$DIR/clim_tmean.npz"; if (!is_file($f)) jout(['error' => 'no clim'], 404);
    header('Content-Type: application/octet-stream'); readfile($f); exit;
}
if ($a === 'cmipput') {                    // r55: دادهٔ پیش‌نگری CMIP6 (JSON فشرده ≤ ۱۲ مگابایت) ← data/cmip6/<name>.json
    $CD = "$DATA/cmip6"; @mkdir($CD, 0755, true); $nm = (string)($_POST['name'] ?? '');
    if (!preg_match('~^cmip6_[a-z0-9_]{2,24}\.json$~', $nm)) jout(['error' => 'name'], 400);
    if (empty($_FILES['f']['tmp_name']) || !is_uploaded_file($_FILES['f']['tmp_name'])) jout(['error' => 'no file'], 400);
    if (filesize($_FILES['f']['tmp_name']) > 12 * 1024 * 1024) jout(['error' => 'too big'], 400);
    $b = (string)file_get_contents($_FILES['f']['tmp_name']); $j = json_decode($b, true);
    if (!is_array($j) || ($j['v'] ?? 0) !== 1 || !isset($j['models'], $j['tas'], $j['pr'])) jout(['error' => 'not cmip6 json'], 400);
    file_put_contents("$CD/$nm.tmp", $b); rename("$CD/$nm.tmp", "$CD/$nm"); jout(['ok' => true, 'bytes' => strlen($b)]);
}
if ($a === 'sndput') {                     // r130: سونداژهای مشاهده‌ایِ وایومینگ (JSON واحد از wyoming_fetch.py) ← data/soundings/{index.json,<id>_<YYYYMMDDHH>.txt}
    $j = json_decode((string)file_get_contents('php://input'), true);
    if (!is_array($j) || !isset($j['stations']) || !is_array($j['stations']) || count($j['stations']) > 60) jout(['error' => 'bad json'], 400);
    $SD = "$DATA/soundings"; @mkdir($SD, 0755, true); $keep = []; $idx = ['v' => 1, 'generated' => mb_substr((string)($j['generated'] ?? gmdate('Y-m-d H:i')), 0, 32), 'stations' => []];
    foreach ($j['stations'] as $st) {
        if (!is_array($st) || !preg_match('~^\d{5}$~', (string)($st['id'] ?? '')) || !is_array($st['runs'] ?? null)) continue;
        $e = ['id' => (string)$st['id'], 'fa' => mb_substr((string)($st['fa'] ?? $st['id']), 0, 40), 'en' => mb_substr((string)($st['en'] ?? $st['id']), 0, 40), 'runs' => []];
        foreach (array_slice($st['runs'], 0, 8) as $r) {
            $f = (string)($r['f'] ?? ''); $tx = (string)($r['txt'] ?? '');
            if (!preg_match('~^\d{5}_20\d{8}\.txt$~', $f) || strlen($tx) < 200 || strlen($tx) > 40000) continue;
            file_put_contents("$SD/$f.tmp", $tx); rename("$SD/$f.tmp", "$SD/$f"); $keep[$f] = 1; $e['runs'][] = ['t' => mb_substr((string)($r['t'] ?? ''), 0, 20), 'f' => $f];
        }
        if ($e['runs']) $idx['stations'][] = $e;
    }
    foreach (glob("$SD/*.txt") ?: [] as $f) if (!isset($keep[basename($f)])) @unlink($f);
    jsave("$SD/index.json", $idx); jout(['ok' => true, 'stations' => count($idx['stations'])]);
}
if ($a === 'geoput') {                     // r65: لایهٔ جغرافیایی (geo.json از geo_layers.py) ← data/geo.json
    if (empty($_FILES['f']['tmp_name']) || !is_uploaded_file($_FILES['f']['tmp_name'])) jout(['error' => 'no file'], 400);
    if (filesize($_FILES['f']['tmp_name']) > 40 * 1024 * 1024) jout(['error' => 'too big'], 400);
    $b = (string)file_get_contents($_FILES['f']['tmp_name']); $j = json_decode($b, true);
    if (!is_array($j) || ($j['v'] ?? 0) !== 1 || !isset($j['places'])) jout(['error' => 'not geo json'], 400);
    @mkdir($DATA, 0755, true); file_put_contents("$DATA/geo.json.tmp", $b); rename("$DATA/geo.json.tmp", "$DATA/geo.json"); jout(['ok' => true, 'bytes' => strlen($b)]);
}
if ($a === 'gpccput') {                    // r101: بارش شبکه‌ای GPCC (برش منطقه‌ای) ← data/gpcc/gpcc_<region>.(json|bin)؛ سقف ۴۰ مگابایت هر فایل و ۶۰ مگابایت کل
    $GD = "$DATA/gpcc"; @mkdir($GD, 0755, true); $nm = (string)($_POST['name'] ?? '');
    if (!preg_match('~^gpcc_[a-z0-9_]{2,16}\.(json|bin)$~', $nm)) jout(['error' => 'name'], 400);
    if (empty($_FILES['f']['tmp_name']) || !is_uploaded_file($_FILES['f']['tmp_name'])) jout(['error' => 'no file'], 400);
    $sz = filesize($_FILES['f']['tmp_name']); if ($sz > 40 * 1024 * 1024) jout(['error' => 'too big'], 400);
    $tot = 0; foreach (glob("$GD/gpcc_*") ?: [] as $q) { if (basename($q) !== $nm) $tot += filesize($q); } if ($tot + $sz > 60 * 1024 * 1024) jout(['error' => 'quota 60MB'], 400);
    $b = (string)file_get_contents($_FILES['f']['tmp_name']);
    if (substr($nm, -5) === '.json') { $j = json_decode($b, true); if (!is_array($j) || ($j['v'] ?? 0) !== 1 || !isset($j['nlat'], $j['nlon'], $j['nt'], $j['t0'])) jout(['error' => 'not gpcc json'], 400); }
    else { if (substr($b, 0, 2) !== "\x1f\x8b") jout(['error' => 'not gzip'], 400); }
    file_put_contents("$GD/$nm.tmp", $b); rename("$GD/$nm.tmp", "$GD/$nm"); jout(['ok' => true, 'bytes' => strlen($b)]);
}
if ($a === 'onsetput') {                   // r102j: آغاز/پایان فصل بارش از CHIRPS روزانه ← data/onset/onset_<region>.(json|bin)؛ سقف ۲۰ مگابایت هر فایل و ۴۰ مگابایت کل
    $OD = "$DATA/onset"; @mkdir($OD, 0755, true); $nm = (string)($_POST['name'] ?? '');
    if (!preg_match('~^onset_[a-z0-9_]{2,16}\.(json|bin)$~', $nm)) jout(['error' => 'name'], 400);
    if (empty($_FILES['f']['tmp_name']) || !is_uploaded_file($_FILES['f']['tmp_name'])) jout(['error' => 'no file'], 400);
    $sz = filesize($_FILES['f']['tmp_name']); if ($sz > 20 * 1024 * 1024) jout(['error' => 'too big'], 400);
    $tot = 0; foreach (glob("$OD/onset_*") ?: [] as $q) { if (basename($q) !== $nm) $tot += filesize($q); } if ($tot + $sz > 40 * 1024 * 1024) jout(['error' => 'quota 40MB'], 400);
    $b = (string)file_get_contents($_FILES['f']['tmp_name']);
    if (substr($nm, -5) === '.json') { $j = json_decode($b, true); if (!is_array($j) || ($j['v'] ?? 0) !== 1 || !isset($j['nlat'], $j['nlon'], $j['y0'], $j['ny'], $j['methods'])) jout(['error' => 'not onset json'], 400); }
    else { if (substr($b, 0, 2) !== "\x1f\x8b") jout(['error' => 'not gzip'], 400); }
    file_put_contents("$OD/$nm.tmp", $b); rename("$OD/$nm.tmp", "$OD/$nm"); jout(['ok' => true, 'bytes' => strlen($b)]);
}
if ($a === 'idxput' || $a === 'idxend') {      // نمودار شاخص‌های اقلیمی (تصویر)؛ بدون وابستگی به مدل/اجرا
    $ID = "$DATA/idx"; @mkdir($ID, 0755, true); $F = "$ID/index.json";
    $ilk = fopen("$ID/.lock", 'c'); flock($ilk, LOCK_EX);        // r102o: خواندن→تغییر→نوشتن index.json هم‌زمان با اجرای چند workflow امن شود
    $X = jload($F, ['items' => [], 'updated' => null]);
    if ($a === 'idxend') { $X['updated'] = gmdate('c'); jsave($F, $X); jout(['ok' => true]); }
    $iid = (string)($_POST['id'] ?? ''); $per = (string)($_POST['per'] ?? '');
    if (!preg_match('~^[a-z0-9_]{2,24}$~', $iid) || !preg_match('~^[a-z0-9]{2,8}$~', $per)) jout(['error' => 'id'], 400);
    if (empty($_FILES['png']['tmp_name']) || !is_uploaded_file($_FILES['png']['tmp_name'])) jout(['error' => 'no file'], 400);
    $b = (string)file_get_contents($_FILES['png']['tmp_name']);
    if (strlen($b) < 1000 || substr($b, 0, 8) !== "\x89PNG\r\n\x1a\n") jout(['error' => 'not png'], 400);
    file_put_contents("$ID/{$iid}_{$per}.png.tmp", $b); rename("$ID/{$iid}_{$per}.png.tmp", "$ID/{$iid}_{$per}.png");
    $m = json_decode((string)($_POST['meta'] ?? '{}'), true) ?: [];
    $e = $X['items'][$iid] ?? ['per' => []];
    foreach (['fa', 'en', 'grp', 'src', 'last', 'upd', 'unit', 'kind', 'note', 'mdl', 'since'] as $k) if (isset($m[$k])) $e[$k] = mb_substr((string)$m[$k], 0, 300);
    foreach (['val', 'prev'] as $k) if (isset($m[$k]) && is_numeric($m[$k])) $e[$k] = round((float)$m[$k], 3);
    if (isset($m['fc']) && is_array($m['fc'])) {                // چند نقطهٔ پیش‌بینی (خلاصه)؛ فقط کلیدهای مجاز
        $fc = []; foreach (array_slice($m['fc'], 0, 12) as $f) { if (!is_array($f)) continue; $o = ['l' => mb_substr((string)($f['l'] ?? ''), 0, 40)];
            foreach (['v', 'lo', 'hi', 'pp', 'pn'] as $q) if (isset($f[$q]) && is_numeric($f[$q])) $o[$q] = round((float)$f[$q], 3); $fc[] = $o; }
        $e['fc'] = $fc;
    }
    /* r54: سری عددی کوچک برای نمودار تعاملی سایت (<id>.json) */
    if (!empty($_FILES['ser']['tmp_name']) && is_uploaded_file($_FILES['ser']['tmp_name']) && filesize($_FILES['ser']['tmp_name']) < 400000) {
        $sj = (string)file_get_contents($_FILES['ser']['tmp_name']); $sd = json_decode($sj, true);
        if (is_array($sd) && isset($sd['kind'])) { file_put_contents("$ID/{$iid}.json.tmp", $sj); rename("$ID/{$iid}.json.tmp", "$ID/{$iid}.json"); $e['ser'] = 1; }
    }
    $e['per'][$per] = (string)($m['perfa'] ?? $per); $X['items'][$iid] = $e; jsave($F, $X); jout(['ok' => true]);
}
if ($a === 'gridput' || $a === 'gridend') {   // بستهٔ شبکه‌ای (باینری int16+zlib) برای سینرژی/جبهه؛ data/grid/<model>/<run>/ — فقط دو اجرای آخر نگه داشته می‌شود
    $GD = "$DATA/grid"; @mkdir($GD, 0755, true);
    if ($a === 'gridput') {
        $gm = (string)($_POST['model'] ?? ''); $gr = (string)($_POST['run'] ?? ''); $gf = (string)($_POST['file'] ?? '');
        if (!preg_match('~^[a-z]{2,10}$~', $gm) || !preg_match('~^20\d{8}$~', $gr) || !preg_match('~^[a-z]{2,10}_\d{10}_\d{3}\.bin$~', $gf)) jout(['error' => 'name'], 400);
        if (empty($_FILES['bin']['tmp_name']) || !is_uploaded_file($_FILES['bin']['tmp_name'])) jout(['error' => 'no file'], 400);
        $b = (string)file_get_contents($_FILES['bin']['tmp_name']); if (strlen($b) < 1000 || substr($b, 0, 4) !== 'MSG1') jout(['error' => 'not grid'], 400);
        $dd = "$GD/$gm/$gr"; @mkdir($dd, 0755, true); file_put_contents("$dd/$gf.tmp", $b); rename("$dd/$gf.tmp", "$dd/$gf"); jout(['ok' => true]);
    }
    $j = json_decode((string)file_get_contents('php://input'), true) ?: []; $gm = (string)($j['model'] ?? ''); $gr = (string)($j['run'] ?? '');
    if (!preg_match('~^[a-z]{2,10}$~', $gm) || !preg_match('~^20\d{8}$~', $gr)) jout(['error' => 'run'], 400);
    jsave("$GD/$gm/$gr/manifest.json", $j); jsave("$GD/$gm/latest.json", ['run' => $gr, 'updated' => gmdate('c')]);
    $runs = array_filter(glob("$GD/$gm/20*", GLOB_ONLYDIR) ?: []); sort($runs); while (count($runs) > 2) rrmdir(array_shift($runs));
    jout(['ok' => true]);
}
if ($a === 'sfput') {                       // r86: فایل‌های JSON سطحی/ERA5 (sfc.yml) → data/sfc/ ؛ بدنهٔ خام (محدودیت upload_max_filesize ندارد)
    $n = (string)($_GET['name'] ?? '');
    if (!preg_match('~^[a-z0-9_]{1,40}\.json$~', $n)) jout(['error' => 'name'], 400);
    $b = (string)file_get_contents('php://input');
    if (strlen($b) < 10 || json_decode($b, true) === null) jout(['error' => 'not json'], 400);
    $SD = "$DATA/sfc"; @mkdir($SD, 0755, true); file_put_contents("$SD/$n.tmp", $b); rename("$SD/$n.tmp", "$SD/$n"); jout(['ok' => true, 'bytes' => strlen($b)]);
}
if ($a === 'rrput' || $a === 'rrend') {        // r85: بارش ماهواره‌ای NOAA RRQPE (فریم‌های PNG و manifest.json) → data/rrqpe/
    $RD = "$DATA/rrqpe"; @mkdir($RD, 0755, true);
    if ($a === 'rrend') {      // JSON: manifest ؛ فریم‌های خارج از manifest پاک می‌شوند
        $m = json_decode((string)file_get_contents('php://input'), true);
        if (!is_array($m) || empty($m['frames'])) jout(['error' => 'manifest'], 400);
        $keep = []; foreach ($m['frames'] as $f) { $n = (string)($f['file'] ?? ''); if (preg_match('~^(rr|nc)_\d{12}\.png$~', $n)) $keep[$n] = 1; }
        foreach (glob("$RD/*.png") ?: [] as $f) if (empty($keep[basename($f)]) || filemtime($f) < time() - 86400) @unlink($f);   // r92: هیچ فریمی بیش از ۲۴ ساعت نمی‌ماند
        jsave("$RD/manifest.json", $m); jout(['ok' => true, 'n' => count($keep)]);
    }
    $n = (string)($_POST['file'] ?? '');
    if (!preg_match('~^(rr|nc)_\d{12}\.png$~', $n)) jout(['error' => 'name'], 400);
    if (empty($_FILES['png']['tmp_name']) || !is_uploaded_file($_FILES['png']['tmp_name'])) jout(['error' => 'no file'], 400);
    $b = (string)file_get_contents($_FILES['png']['tmp_name']);
    if (strlen($b) < 100 || substr($b, 0, 8) !== "\x89PNG\r\n\x1a\n") jout(['error' => 'not png'], 400);
    file_put_contents("$RD/$n.tmp", $b); rename("$RD/$n.tmp", "$RD/$n"); jout(['ok' => true]);
}
$body = ($a === 'put' || $a === 'putm') ? $_POST : (json_decode((string)file_get_contents('php://input'), true) ?: []);
$model = (string)($body['model'] ?? ''); $run = (string)($body['run'] ?? '');
if (!preg_match('~^[a-z][a-z0-9]{1,9}$~', $model)) jout(['error' => 'model'], 400);
if (!preg_match('~^20\d{8}$~', $run)) jout(['error' => 'run'], 400);
$MD = "$NWP/$model"; @mkdir($MD, 0755, true);
$lock = fopen("$MD/.lock", 'c'); for ($w = 0; !flock($lock, LOCK_EX | LOCK_NB); $w++) { if ($w >= 40) jout(['error' => 'busy', 'retry' => 1], 503); usleep(500000); }     /* r119: انتظار حداکثر ۲۰ ثانیه ← 503 سریع و قابل‌تکرار (به‌جای صف‌شدن کارگرهای PHP تا سقف منابع هاست) */        // r103: قفل «برای هر مدل» (قبلاً یک قفل سراسری؛ ۴ مدل/۴ رشته همه را در صف می‌گذاشت → HTTP 502)
$SF = "$MD/state.json"; $S = jload($SF, ['run' => null, 'items' => []]);

function NWP_DROP(): array { global $C; $d = $C['drop_models'] ?? ['arpege', 'access', 'navgem', 'ccsm4', 'ccsmfour']; return is_array($d) ? array_values(array_filter(array_map('strval', $d))) : []; }
function nwp_purge(): int {      // r113: پوشهٔ مدل‌های حذف‌شده را از هاست پاک می‌کند (فضا و تعداد فایل؛ سرعت بازسازی فهرست)
    global $NWP; $n = 0; foreach (NWP_DROP() as $m) { if (!preg_match('~^[a-z][a-z0-9]{1,9}$~', $m)) continue; $d = "$NWP/$m"; if (is_dir($d)) { rrmdir($d); $n++; logl("purge $m"); } } return $n;
}
function manifest(bool $force = false): void {
    global $NWP, $DATA;
    // r103: بازسازی فهرست کل (ده‌ها هزار آیتم) فقط یک نفر در هر لحظه و حداکثر هر ۶۰ ثانیه؛ بقیه رد می‌شوند (put را منتظر نگه نمی‌دارد)
    $ml = fopen("$NWP/.mlock", 'c');
    if (!flock($ml, $force ? LOCK_EX : (LOCK_EX | LOCK_NB))) return;
    if (!$force && is_file("$DATA/manifest.json") && time() - filemtime("$DATA/manifest.json") < 60) return;
    $P = jload("$NWP/params.json", []);
    $man = ['source' => 'nwp', 'updated' => gmdate('c'), 'status' => 'complete', 'run' => null, 'models' => [], 'regions' => ['iran' => ['fa' => 'ایران'], 'fars' => ['fa' => 'فارس'], 'me' => ['fa' => 'خاورمیانه'], 'eu' => ['fa' => 'اروپا']],
            'params' => [], 'items' => [], 'items_prev' => [], 'done' => 0, 'expected' => 0, 'cats' => jload("$NWP/cats.json", []), 'scales' => jload("$NWP/scales.json", (object)[])];
    $DROP = NWP_DROP();   // r113: مدل‌های حذف‌شده (arpege، access، navgem، ccsm4…) در فهرست و بازسازی‌ها نیایند
    foreach (glob("$NWP/*/state.json") ?: [] as $f) {
        $S = jload($f, null); if (!$S || !$S['run']) continue; $m = basename(dirname($f)); if (in_array($m, $DROP, true)) continue;
        $man['models'][$m] = ['fa' => $S['label'] ?? $m, 'name' => $S['name'] ?? $m, 'run' => $S['run'], 'status' => $S['status'] ?? 'downloading', 'done' => count($S['items']), 'info' => $S['info'] ?? (object)[]];
        if ($man['run'] === null || $S['run'] > $man['run']) $man['run'] = $S['run'];
        if (($S['status'] ?? '') !== 'complete') $man['status'] = 'downloading';
        foreach ($S['items'] as $file => $i) { $it = ['r' => $i['r'], 'm' => $m, 'p' => $i['p'], 's' => (int)$i['s'], 'v' => $i['v']]; if (substr($file, -5) === '.webp') $it['x'] = 'webp'; if (isset($i['w'])) $it['w'] = $i['w']; $man['items'][] = $it; }  /* فشرده: مسیر f و run را صفحه از models بازسازی می‌کند */
        // اجرای قبلی همین مدل (دومین اجرای نگه‌داشته‌شده): جدا از items تا صفحه‌های دیگر دوبار نقشه نبینند
        $best = null; foreach (glob(dirname($f) . '/20*/state.json') ?: [] as $pf) { $q = jload($pf, null); if ($q && !empty($q['run']) && $q['run'] !== $S['run'] && $q['run'] < $S['run'] && ($best === null || $q['run'] > $best['run'])) $best = $q; }
        if ($best) {
            $man['models'][$m]['prev'] = ['run' => $best['run'], 'status' => $best['status'] ?? 'complete', 'done' => count($best['items'])];
            foreach ($best['items'] as $file => $i) { $it = ['r' => $i['r'], 'm' => $m, 'p' => $i['p'], 's' => (int)$i['s'], 'v' => $i['v']]; if (substr($file, -5) === '.webp') $it['x'] = 'webp'; if (isset($i['w'])) $it['w'] = $i['w']; $man['items_prev'][] = $it; }
        }
    }
    foreach ($P as $id => $p) $man['params'][] = ['id' => $id, 'fa' => $p['fa'] ?? $id, 'unit' => $p['unit'] ?? '', 'cat' => $p['cat'] ?? '', 'o' => $p['o'] ?? 0, 'sc' => $p['sc'] ?? '', 'mu' => $p['mu'] ?? '', 'alt' => $p['alt'] ?? '', 'me' => $p['me'] ?? 0, 'ln' => $p['ln'] ?? 0];
    $man['done'] = count($man['items']); $man['expected'] = $man['done'];
    jsave("$DATA/manifest.json", $man);
}

if ($a === 'begin') {
    $gl = fopen("$NWP/.lock", 'c'); for ($w = 0; !flock($gl, LOCK_EX | LOCK_NB); $w++) { if ($w >= 40) jout(['error' => 'busy', 'retry' => 1], 503); usleep(500000); }        // r103: begin روی فایل‌های مشترک (params/cats/scales) می‌نویسد؛ فقط همین‌جا قفل سراسری
    if ($S['run'] !== $run) {
        if ($S['run'] && $run < $S['run']) jout(['error' => 'older run', 'run' => $S['run']], 409);
        $prev = ($S['run'] && is_dir("$MD/{$S['run']}")) ? (string)$S['run'] : null;          // اجرای جاری فعلی ← «اجرای قبلی»
        if ($prev !== null) { $S['status'] = $S['status'] ?? 'downloading'; jsave("$MD/$prev/state.json", $S); }
        foreach (glob("$MD/20*", GLOB_ONLYDIR) ?: [] as $d) { $b = basename($d); if ($b === $run || $b === $prev) continue; rrmdir($d); logl("حذف $model/$b"); }
        $S = ['run' => $run, 'name' => (string)($body['name'] ?? $model), 'label' => (string)($body['label'] ?? $model), 'started' => gmdate('c'), 'status' => 'downloading', 'items' => []];
        $inf = is_array($body['info'] ?? null) ? $body['info'] : []; $S['info'] = ['tclass' => preg_match('~^(daily|weekly|monthly|seasonal|ens)$~', (string)($inf['tclass'] ?? '')) ? $inf['tclass'] : 'daily',
            'res' => mb_substr((string)($inf['res'] ?? ''), 0, 60), 'cyc' => mb_substr((string)($inf['cyc'] ?? ''), 0, 30), 'prov' => mb_substr((string)($inf['prov'] ?? ''), 0, 60)];
        jsave($SF, $S); logl("شروع $model $run");
        if (!empty($body['params']) && is_array($body['params'])) { $P = jload("$NWP/params.json", []); foreach ($body['params'] as $id => $p) if (preg_match('~^[a-z0-9]{1,10}$~', (string)$id)) $P[$id] = ['fa' => (string)($p['fa'] ?? $id), 'unit' => (string)($p['unit'] ?? ''),
            'cat' => preg_replace('~[^a-z]~', '', (string)($p['cat'] ?? '')), 'o' => (int)($p['o'] ?? 0), 'sc' => preg_replace('~[^a-z0-9_]~', '', (string)($p['sc'] ?? '')), 'mu' => (string)($p['mu'] ?? ($p['unit'] ?? '')),
            'alt' => preg_replace('~[^a-z0-9]~', '', (string)($p['alt'] ?? '')), 'me' => (int)($p['me'] ?? 0), 'ln' => (int)($p['ln'] ?? 0)]; jsave("$NWP/params.json", $P); }
        if (!empty($body['cats']) && is_array($body['cats'])) { $Cc = []; foreach ($body['cats'] as $c) if (isset($c['id'])) $Cc[] = ['id' => preg_replace('~[^a-z]~', '', (string)$c['id']), 'fa' => mb_substr((string)($c['fa'] ?? ''), 0, 60), 'o' => (int)($c['o'] ?? 0)]; jsave("$NWP/cats.json", $Cc); }
        if (!empty($body['scales']) && is_array($body['scales'])) { $Sc = jload("$NWP/scales.json", []); foreach ($body['scales'] as $k => $v) if (preg_match('~^[a-z0-9_]{2,16}$~', (string)$k) && is_array($v['c'] ?? null) && is_array($v['e'] ?? null)) $Sc[$k] = $v; jsave("$NWP/scales.json", $Sc); }
        manifest(true);
    }
    jout(['run' => $S['run'], 'have' => array_keys($S['items'])] + caps());
}
if ($a === 'putm') {      // r114: چند نقشه در یک درخواست؛ state.json فقط یک بار نوشته می‌شود
    if ($run !== $S['run']) jout(['error' => 'run mismatch', 'run' => $S['run']], 409);
    $L = json_decode((string)($_POST['list'] ?? '[]'), true); $F = $_FILES['png'] ?? null;
    if (!is_array($L) || !$L || !$F || !is_array($F['tmp_name'] ?? null)) jout(['error' => 'no files'], 400);
    $ok = 0; $bad = [];
    foreach ($L as $i => $it) {
        $file = (string)($it['file'] ?? ''); $tmp = $F['tmp_name'][$i] ?? '';
        if (!preg_match('~^(iran|fars|me|eu)/[a-zA-Z0-9]{1,11}_20\d{8}\.(png|webp)$~', $file) || $tmp === '' || !is_uploaded_file($tmp)) { $bad[] = $file; continue; }
        $b = (string)file_get_contents($tmp); $isw = substr($file, -5) === '.webp';
        if ($isw ? (strlen($b) < 30 || substr($b, 0, 4) !== 'RIFF' || substr($b, 8, 4) !== 'WEBP') : (strlen($b) < 5000 || substr($b, 0, 8) !== "\x89PNG\r\n\x1a\n")) { $bad[] = $file; continue; }
        [$reg, $nm] = explode('/', $file); [$p, $v] = explode('_', preg_replace('~\.(png|webp)$~', '', $nm));
        $dst = "$MD/$run/$file"; @mkdir(dirname($dst), 0755, true); if (!wsafe($dst, $b)) { jsave($SF, $S); jout(['error' => 'disk', 'n' => $ok], 507); } $ok++;
        if (in_array(substr($p, -1), ['L', 'V', 'W', 'H'], true)) continue;
        $meta = is_array($it['meta'] ?? null) ? $it['meta'] : [];
        $S['items'][$file] = ['r' => $reg, 'p' => $p, 'v' => $v, 's' => (int)($meta['s'] ?? 0)];
        if (isset($meta['w']) && preg_match('~^[a-z0-9:,]{1,90}$~', (string)$meta['w'])) $S['items'][$file]['w'] = (string)$meta['w'];
    }
    jsave($SF, $S); flock($lock, LOCK_UN); manifest();
    jout(['ok' => true, 'n' => $ok, 'bad' => $bad, 'done' => count($S['items'])]);
}
if ($a === 'put') {
    if ($run !== $S['run']) jout(['error' => 'run mismatch', 'run' => $S['run']], 409);
    $file = (string)($body['file'] ?? '');
    if (!preg_match('~^(iran|fars|me|eu)/[a-zA-Z0-9]{1,11}_20\d{8}\.(png|webp)$~', $file)) jout(['error' => 'file'], 400);
    if (empty($_FILES['png']['tmp_name']) || !is_uploaded_file($_FILES['png']['tmp_name'])) jout(['error' => 'no file'], 400);
    $b = (string)file_get_contents($_FILES['png']['tmp_name']);
    $isw = substr($file, -5) === '.webp';
    if ($isw ? (strlen($b) < 30 || substr($b, 0, 4) !== 'RIFF' || substr($b, 8, 4) !== 'WEBP') : (strlen($b) < 5000 || substr($b, 0, 8) !== "\x89PNG\r\n\x1a\n")) jout(['error' => 'bad image'], 400);
    $meta = json_decode((string)($body['meta'] ?? '{}'), true) ?: [];
    [$reg, $nm] = explode('/', $file); [$p, $v] = explode('_', preg_replace('~\.(png|webp)$~', '', $nm));
    $dst = "$MD/$run/$file"; @mkdir(dirname($dst), 0755, true); if (!wsafe($dst, $b)) jout(['error' => 'disk'], 507);
    if (in_array(substr($p, -1), ['L', 'V', 'W', 'H'], true)) jout(['ok' => true, 'line' => true]);          // لایهٔ خطوطِ کاشی؛ در فهرست جدا نمی‌آید
    $S['items'][$file] = ['r' => $reg, 'p' => $p, 'v' => $v, 's' => (int)($meta['s'] ?? 0)];
    if (isset($meta['w']) && preg_match('~^[a-z0-9:,]{1,90}$~', (string)$meta['w'])) $S['items'][$file]['w'] = (string)$meta['w'];          // مالتی‌مدل: مدل‌های به‌کاررفته و وزن‌ها
    jsave($SF, $S);
    // فهرست کلی هر ۲۰ نقشه (و در پایان) بازسازی می‌شود تا هاست کند نشود
    flock($lock, LOCK_UN); if (count($S['items']) % 20 === 1) manifest();
    jout(['ok' => true, 'done' => count($S['items'])]);
}
if ($a === 'sync') { $pg = nwp_purge(); manifest(true); jout(['ok' => true, 'purged' => $pg]); }
if ($a === 'end') {
    if ($run === $S['run']) { $S['status'] = 'complete'; $S['ended'] = gmdate('c'); jsave($SF, $S); logl("پایان $model $run — " . count($S['items']) . ' نقشه'); }
    flock($lock, LOCK_UN); manifest(true); jout(['ok' => true]);
}
jout(['error' => 'bad action'], 400);
