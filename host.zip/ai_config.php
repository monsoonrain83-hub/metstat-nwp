<?php
return [
  'relay_url'    => 'https://metstat-ai.azarakhsh362.workers.dev',
  'relay_secret' => 'X8InOpuV7EW4pCOIdjzmS2wukGub3jfkZyTkR1ka',
  'origins'      => ['wtafkik.ir', 'www.wtafkik.ir'],
  'per_hour'     => ['guide' => 5, 'report' => 3],
  'day_cap'      => 300,
];
