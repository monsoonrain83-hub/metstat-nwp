// MetStat relay — Cloudflare Worker (رایگان؛ بیرون از ایران)
// هاست ایران → این Worker → meteologix / weather.us ؛ فقط همین دامنه‌ها مجازند و بدون کلید درست کار نمی‌کند.
// نصب: dash.cloudflare.com → Workers & Pages → Create → Worker → این کد را جای کد پیش‌فرض بگذارید → Deploy
//       Settings → Variables and Secrets → Add → نام RELAY_KEY ، نوع Secret ، مقدار: یک رمز طولانی دلخواه
// سپس آدرس Worker و همان رمز را در online/mx_config.json بخش "relay" بنویسید.
const ALLOW = /^https:\/\/((www\.)?meteologix\.com|(www\.)?weather\.us|img\d*\.meteologix\.com|osm\.meteologix\.com|img\d*\.weather\.us)\//i;

export default {
  async fetch(req, env) {
    const u = new URL(req.url);
    const target = u.searchParams.get("u") || "";
    if (!env.RELAY_KEY || u.searchParams.get("k") !== env.RELAY_KEY) return new Response("bad key", { status: 401 });
    if (!ALLOW.test(target)) return new Response("host not allowed", { status: 400 });
    const isImg = /\.(png|jpe?g|gif|webp)(\?|$)/i.test(target);
    const r = await fetch(target, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0 Safari/537.36",
        "Accept": isImg ? "image/avif,image/webp,image/png,image/*;q=0.8,*/*;q=0.5" : "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": target.includes("weather.us") ? "https://weather.us/" : "https://meteologix.com/",
      },
      redirect: "follow",
      cf: { cacheTtl: isImg ? 600 : 120, cacheEverything: true },
    });
    const h = new Headers();
    h.set("Content-Type", r.headers.get("Content-Type") || (isImg ? "image/png" : "text/html; charset=utf-8"));
    h.set("Cache-Control", isImg ? "public, max-age=600" : "no-store");
    h.set("X-Relay-Status", String(r.status));
    return new Response(r.body, { status: r.status, headers: h });
  },
};
