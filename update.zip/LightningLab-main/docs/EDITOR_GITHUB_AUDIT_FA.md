# ممیزی تطبیقی ادیتورهای عکس و ویدئوی LightningLab

تاریخ بررسی: ۹ نوامبر ۲۰۲۶  
مبنای ممیزی: سورس بستهٔ r10.37، فایل‌های `Screens.kt`، `MainVM.kt`، `PhotoEdit.kt`، `PhotoLayers.kt`، `VideoFx.kt`، `ProjectCodec.kt` و `PhotoProjectCodec.kt`؛ به‌علاوه README و قابلیت‌های اعلام‌شده در مخازن عمومی GitHub. این بررسی ممیزی کد و قابلیت‌های اعلام‌شده است، نه تأیید عملکرد همهٔ پروژه‌های مرجع روی دستگاه.

## ۱. مخازن مرجع بررسی‌شده

| مخزن | حوزه و ارزش الگوبرداری | مجوز/ملاحظه |
|---|---|---|
| [CapCraft for Android](https://github.com/artcraft-android/capcraft-android) | نزدیک‌ترین مرجع ویدئوی موبایل: تایم‌لاین چندمسیره، انتخاب چندکلیپی، pinch zoom، snapping، ripple edit، trim، speed curve، freeze/reverse، mask و chroma key، blend mode، ۸۰+ فیلتر، افکت و transitionهای قابل پیش‌نمایش، متن/فونت/قالب/انیمیشن، کپشن، صدا و preset خروجی تا 4K/60fps | AGPL-3.0-or-later و موتور Rust؛ ایده‌ها قابل الگوبرداری‌اند، ولی انتقال کد/موتور بدون بررسی تعهدات مجوز انجام نمی‌شود. پروژه Beta است. |
| [LightCraft for Android](https://github.com/artcraft-android/lightcraft-android) | مرجع عکس غیرمخرب: RAW، white balance، RGB point curves، color grading wheels، ۸-band color mixer، ماسک‌های brush/linear/radial، preset preview، crop/straighten، قبل/بعد، مدیریت کتابخانه و متادیتا | مخزن MIT OR Apache-2.0 اعلام می‌کند؛ موتور Rust و وابستگی‌های native دارد. قبل از ادغام هر قطعه، مجوز همان فایل/وابستگی بررسی شود. پروژه Beta است. |
| [CheapShot / ClearCut](https://github.com/johncreson/CheapShot-Editor) | مرجع بلوغ workflow: تایم‌لاین چندلایه، snap، گروه‌کردن کلیپ‌ها، multi-select، speed ramp، keyframe با easing، markers، haptic feedback، waveform cache، track collapse/height، shortcut، project migration، recovery، export preflight و گزارش خطای قابل کپی | این مخزن fork از ClearCut است؛ وضعیت و مجوز هر نسخه باید از همان revision بررسی شود. README بسیار گسترده است و برخی امکانات ممکن است وابسته به نسخه باشند. |
| [ActionCut](https://github.com/naveenneog/ActionCut) | الگوی Compose/Media3: playhead ثابت وسط صفحه و حرکت محتوا زیر آن، موتور pure Kotlin و تست‌شده برای split/trim/ripple/move، undo/redo، ابزارهای LUT، خروجی پس‌زمینه با WorkManager و طراحی تیرهٔ مینیمال | مخزن کوچک‌تر و تعداد ستاره‌ها محدود است؛ از معماری/ایده‌ها استفاده شود، نه فرض بلوغ محصول. |
| [Allay Photo Editor](https://github.com/Allay054/Photo-Editor) | مرجع سبک‌تر Kotlin: ابزار annotation، contextual toolbar، انتخاب/جابجایی اشیا، duplicate/delete، gesture history و تاریخچهٔ مرکزی برای crop/filter/transform/layers | مناسب الگوهای UI و تاریخچه؛ جایگزین موتور حرفه‌ای RAW یا compositing نیست. |

## ۲. وضعیت فعلی LightningLab و فاصله‌ها

علامت‌ها: **داریم** = در سورس فعلی دیده شد؛ **نیمه‌کاره** = بخشی از منطق وجود دارد اما workflow کامل نیست؛ **نداریم** = در سورس فعلی پیدا نشد؛ **نیازمند راستی‌آزمایی** = باید روی دستگاه/خروجی واقعی تست شود.

### ادیتور عکس

| قابلیت | وضعیت فعلی | فاصله و کار لازم |
|---|---|---|
| تنظیم نور، کنتراست، هایلایت، سایه، vibrance، warmth، HSL و S-curve | داریم | کنترل‌ها باید histogram و بازخورد عددی/قبل‌بعد داشته باشند؛ S-curve فعلی جای RGB point-curve قابل‌ویرایش را نمی‌گیرد. |
| متن/شکل/تصویر با z-order مشترک، opacity، rotation و undo/redo | داریم | duplicate در این فاز اضافه شد؛ drag مستقیم روی بوم، pinch، handles، lock، group، blend modes و clipping masks باقی است. |
| ماسک قلمی و inversion | داریم | radial/linear gradient، feather handle، mask overlay قابل‌مشاهده، چند ماسک نام‌دار و local adjustment layer نداریم. |
| Healing / inpaint | داریم | clone stamp، patch tool، object selection و content-aware fill حرفه‌ای نداریم؛ کیفیت ترمیم باید روی عکس‌های متنوع benchmark شود. |
| crop و aspect ratio | محدود | crop handles، straighten، grid overlays، perspective correction و نسبت‌های سفارشی کامل نیستند. |
| RAW / DNG، lens profile، highlight recovery | نداریم | نیازمند pipeline مستقل و موتور decode/develop؛ قابلیت ساده‌ای برای افزودن به `Bitmap` نیست. |
| RGB point curves، color wheels، split toning، ۸-band color mixer | نداریم | از LightCraft به‌عنوان مرجع طراحی/ریاضی استفاده شود؛ پیاده‌سازی GPU یا LUT لازم است. |
| preset قابل‌ذخیره و پروژهٔ غیرمخرب | داریم | preview thumbnail، دسته‌بندی، favorite، import/export preset و recovery خودکار پروژه باقی است. |
| مدیریت کتابخانه، جست‌وجو، آلبوم، rating/flag و metadata | نداریم | صفحهٔ Library مستقل نیاز دارد؛ از scope خود ادیتور جدا شود. |
| خروجی با کیفیت/ابعاد/فرمت قابل انتخاب | محدود | JPEG quality، WebP، رزولوشن/resize، metadata policy و تخمین حجم باید اضافه شود. |
| gesture و دسترسی ابزارها | ضعیف‌تر از مرجع | انتخاب لایه با tap روی بوم، drag handles، pinch zoom، pan، ابزار contextual نزدیک انتخاب و landscape workspace نداریم. |

### ادیتور ویدئو

| قابلیت | وضعیت فعلی | فاصله و کار لازم |
|---|---|---|
| چند قطعهٔ ویدئو، trim و reorder ساده، موسیقی و voice track | داریم | track model مستقل با start/end/offset/volume/fades و gapهای قابل‌مشاهده لازم است. |
| waveform موسیقی و voice | داریم | waveform decode فعلی باید cache، downsample چندسطحی و invalidation داشته باشد؛ waveform به‌صورت track قابل‌جابجایی/برش نیست. |
| تایم‌لاین متن/استیکر/تصویر و افکت زمان‌دار | داریم | ردیف‌ها هنوز عمدتاً نمایشگرند؛ drag-to-move/trim، multi-select، grouping و snapping کامل ندارند. |
| keyframe شفافیت و موقعیت عمودی | محدود | position X/Y، scale، rotation، volume، speed و easing curves ندارند. |
| پیش‌نمایش | **شکاف بحرانی** | `VideoView` فقط منبع خام را پخش می‌کند؛ فیلتر، crop، flip، rotation، overlay و تایم‌لاین در preview هم‌ارز خروجی نیستند. باید preview/export از قرارداد رندر مشترک استفاده کنند. |
| scrub/playhead | محدود | کنترل پخش/مکث و RangeSlider هست؛ playhead مرکزی، frame-step، seek دقیق و دنبال‌کردن playhead در تایم‌لاین نداریم. |
| timeline zoom / snapping / markers | نداریم | zoom pinch، fit-to-project، snap به clip edge/playhead/marker و marker list لازم است. snap پایه در این فاز اضافه شد. |
| split، ripple delete، slip/roll trim، freeze، reverse، speed ramp | محدود/نداریم | موتور pure Kotlin و تست‌شده برای عملیات timeline لازم است؛ speed فعلی یک ضریب کلی است. |
| transitions | نداریم | crossfade، wipe، zoom، blur و transition preview بین دو clip لازم است. |
| effects و LUT | محدود | چند filter پایه و effect clip داریم؛ LUT `.cube`، intensity، preset shelves، افکت‌های زمان‌دار متنوع و preview thumbnail نداریم. |
| audio editing | محدود | clip gain و چند volume کلی داریم؛ per-clip fade, pan, ducking, EQ, noise reduction, voice isolation و audio-only/stem export نداریم. |
| captions/subtitles | نداریم | واردکردن SRT، caption clips، و transcription آفلاین با مدل اختیاری لازم است. |
| export | محدود | H.264/AAC هست؛ resolution، fps، bitrate، quality preset، estimated size، preflight، output verification، queue و background worker نداریم. |
| project lifecycle | داریم، دستی | autosave، crash recovery، rename/duplicate/archive، import/export project و نسخه‌بندی مهاجرتی مقاوم‌تر لازم است. |
| history | ناقص | undo/redo قطعات اصلی هست، اما تمام عملیات overlay/effect/audio/clip در یک تاریخچهٔ واحد و پایدار نیستند. |

## ۳. جزئیات UX که باید از مراجع اقتباس شوند

1. **Playhead ثابت در مرکز** و حرکت تایم‌لاین زیر آن؛ لمس و کشیدن برای scrub با frame-step و timecode.
2. **Pinch-to-zoom** به‌همراه دکمه‌های `− / + / Fit` و حفظ نقطهٔ زمانی زیر انگشت هنگام zoom.
3. **Snap مغناطیسی** با نشانگر عمودی هنگام نزدیک‌شدن به ابتدا/انتهای کلیپ، playhead و marker؛ امکان خاموش‌کردن.
4. **Clip handles واقعی** برای trim دوطرفه، drag برای جابه‌جایی، long-press برای multi-select، group/ungroup و ripple delete.
5. **Track header ثابت** با mute/solo/lock/hide، collapse، تغییر ارتفاع و رنگ/نام اختصاصی.
6. **Contextual tool dock**: ابزارهای متناسب با انتخاب جاری ظاهر شوند؛ کاربر برای هر تغییر مجبور به پیمایش پنل طولانی نباشد.
7. **Preview قابل لمس**: انتخاب overlay با tap، انتقال با drag، resize با pinch/handles، rotate با دو انگشت؛ پنل عددی دقیق هم در دسترس بماند.
8. **Thumbnail strip و waveform cache**: پیش‌نمایش فریم‌های واقعی clip، cache چندوضوحی و تولید در background.
9. **Before/After واقعی** با نگه‌داشتن یا split slider؛ reset مستقل هر گروه تنظیمات.
10. **Export preflight**: هشدار برای فایل گم‌شده، رزولوشن نامعتبر، صدای بدون منبع، فضای ناکافی و افکتی که backend آن را پشتیبانی نمی‌کند.
11. **Recovery شفاف**: autosave، نسخهٔ پشتیبان، تشخیص پروژهٔ ناقص و گزارش اینکه چه چیزی بازیابی نشده؛ هرگز پروژهٔ ناقص بی‌صدا روی نسخهٔ سالم نوشته نشود.
12. **Haptics و دسترسی‌پذیری** برای گرفتن handle، snap، split و انتخاب؛ هدف لمسی حداقل 48dp، برچسب TalkBack و کنترل‌های با فاصلهٔ مناسب.
13. **Adaptive workspace**: در حالت افقی/تبلت preview و timeline کنار هم؛ در گوشی عمودی preview بالا و timeline/tool dock پایین.

## ۴. تغییرات انجام‌شده در این بسته

- موتور ریاضی تایم‌لاین از پیاده‌سازی پارک‌شده به سورس فعال بازگردانده شد؛ توابع zoom interpolation، clamp، locate، outPosition و split اکنون در مسیر اصلی unit-testable هستند.
- snap پایه به مرز ابتدا/انتها و مرز کلیپ‌های overlay/effect اضافه شد؛ کلید روشن/خاموش «چسبندگی» در هدر تایم‌لاین قرار گرفت.
- duplicate برای لایه‌های متن، شکل و تصویر در ادیتور عکس اضافه شد؛ تصویر duplicate bitmap مستقل می‌گیرد تا تغییر/حذف یک لایه روی دیگری اثر نگذارد.
- تست‌های TimelineMath که به کلاس‌های غایب ارجاع می‌دادند اکنون پیاده‌سازی متناظر دارند و دو تست snapping اضافه شد.

## ۵. نقشهٔ اجرای باقی‌مانده (ترتیب پیشنهادی)

### P0 — صحت و ایمنی تدوین
- ساخت preview مشترک با export برای video (Media3 ExoPlayer + effects/overlay composition یا preview renderer اختصاصی).
- unified video command history با snapshot/command و undo/redo برای تمام editها.
- autosave، recovery، atomic project store، migration و گزارش خرابی/دارایی گمشده.
- export preflight، کنترل کیفیت/رزولوشن/fps/bitrate، verification و خطای مرحله‌ای.

### P1 — تایم‌لاین حرفه‌ای
- playhead ثابت، scrubbing و frame stepping؛ timeline zoom و fit.
- drag/move/trim/split/ripple، snap indicators، markers، multi-select و group.
- video thumbnails و waveform cache؛ track mute/solo/lock/collapse/height.
- clip-level audio gain/fade/pan و keyframeهای کامل با easing.

### P2 — ابزارهای خلاقانه ویدئو
- transitions، speed ramp، reverse، freeze frame، mask/chroma key، LUT `.cube` و effect shelves.
- captions/SRT، text templates/fonts/animations، sound FX browser، audio-only/stem export.

### P3 — عکاسی حرفه‌ای
- canvas gesture editing و contextual handles؛ layer lock/group/duplicate و blend modes.
- local adjustment layers، radial/linear masks، RGB point curves، color wheels، 8-band mixer.
- crop/straighten/perspective، clone/patch/object removal، RAW/DNG و lens correction.
- preset library، before/after slider، histogram، metadata و export presets.

### P4 — تجربه و کیفیت محصول
- landscape/tablet workspace، accessibility/haptics، onboarding کوتاه و قابل replay.
- benchmark زمان preview/export، memory budget، cache policy و تست روی دستگاه‌های ضعیف/قوی.
- UI screenshot tests، instrumentation tests و تست round-trip پروژه/خروجی.

## ۶. سیاست ادغام

- در این مرحله کد پروژه‌های دیگر کپی یا dependency سنگین Rust/FFmpeg اضافه نشده است؛ فقط الگوها و قابلیت‌ها ممیزی شده‌اند.
- CapCraft با AGPL-3.0-or-later منتشر شده است؛ انتقال کد آن می‌تواند تعهدات انتشار متناظر ایجاد کند. LightCraft مجوز MIT/Apache اعلام می‌کند، اما مجوز فایل‌ها و وابستگی‌های native باید جداگانه بررسی شود.
- هر قابلیت باید هم در preview و هم در export کار کند، در پروژه ذخیره/بازیابی شود و تست pure/unit یا device داشته باشد؛ اضافه‌کردن کنترل UI بدون اتصال به موتور، قابلیت محسوب نمی‌شود.
