package com.lightninglab

import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App(vm: MainVM = viewModel()) {
    LightningTheme {
        Surface(Modifier.fillMaxSize(), color = androidx.compose.ui.graphics.Color.Transparent) {
            Box(Modifier.fillMaxSize()) {
                GlassAtmosphereBackground()
                Column(Modifier.systemBarsPadding()) {
                    BackHandler(enabled = vm.screen != Screen.HOME) { vm.screen = Screen.HOME }
                    Box(Modifier.weight(1f)) {
                        Crossfade(targetState = vm.screen, animationSpec = tween(200), label = "screen") { sc ->
                            when (sc) {
                                Screen.HOME -> Home(vm)
                                Screen.RESULTS -> Results(vm)
                                Screen.ABOUT -> About(vm)
                                Screen.PHOTO -> PhotoEditor(vm)
                                Screen.VIDEO -> VideoEditor(vm)
                                Screen.WEATHER -> WeatherScreen(vm)
                                Screen.PREPARE -> PrepareScreen(vm)
                                Screen.CLOUD_ATLAS -> CloudAtlasScreen(vm)
                            }
                        }
                    }
                    if (vm.screen != Screen.RESULTS && vm.screen != Screen.ABOUT && vm.screen != Screen.PREPARE && vm.screen != Screen.CLOUD_ATLAS) NavBar(vm)
                }
            }
        }
    }
}
