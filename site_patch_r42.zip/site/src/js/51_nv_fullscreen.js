/* ===== حالت تمام‌صفحهٔ نمایشگر نقشه‌های مدل =====
   دکمهٔ مربع گوشهٔ پایین-چپ نقشه → نقشه و نوار رنگ به یک لایهٔ تمام‌صفحه منتقل می‌شوند (همان canvas و همان وضعیت NV)،
   و ابزارها فقط در همین حالت می‌آیند: ردیف مدل‌ها، منوی منطقه/پارامتر اصلی/ثانویه/لایه‌ها، نوار زمان (پخش، روز، بازهٔ GIF)،
   نوار ابزار عمودی (زوم، جابه‌جایی، فونت و ضخامت خط، خط‌کش، مداد) و نوار نقاشی.
   نقاشی‌ها و خط‌کش به مختصات جغرافیایی (lon/lat) ذخیره می‌شوند؛ پس با زوم/جابه‌جایی/عوض‌شدن فریم همان‌جا می‌مانند و در PNG و GIF می‌آیند.
   خروج: دکمهٔ مربع، یا Esc. با خروج، صفحه دقیقاً مثل قبل است. */
var NVF={sync:()=>nvfSync(), redraw:()=>nvfRedraw(), on:false, tool:"pan", pen:false, T:"solid", col:"#d62828", w:3, op:0.3, ff:"body", fs:20, straight:false, flip:false, er:18,
  items:[], undo:[], redo:[], rul:[], cur:null, drag:null, mouse:null, day:"", from:null, to:null, spd:750, gq:2400, gd:70, key:"", dd:"", raf:0, nat:false, home:null};
const NVF_FF={body:'"Ketab","Lalezar",sans-serif', titr:'"Titr","Ketab",sans-serif', lal:'"Lalezar","Ketab",sans-serif', nas:'"Nastaliq","Ketab",serif'};
const NVF_FFN=[["body","کتاب"],["titr","تیتر"],["lal","لاله‌زار"],["nas","نستعلیق"]];
const NVF_COLS=["#111111","#d62828","#f77f00","#fcbf49","#2a9d8f","#2f6bf0","#7b2cbf","#e5398b","#ffffff","#6b7280"];
const NVF_LW=[1,1.35,1.7,2.1,2.6];
const NVF_I={
  sq:'<svg viewBox="0 0 24 24"><rect x="4.5" y="4.5" width="15" height="15" rx="2"/></svg>',
  zi:'<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>',
  zo:'<svg viewBox="0 0 24 24"><path d="M5 12h14"/></svg>',
  fx:'<svg viewBox="0 0 24 24"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>',
  pan:'<svg viewBox="0 0 24 24"><path d="M12 3v18M3 12h18M12 3l-3 3M12 3l3 3M12 21l-3-3M12 21l3-3M3 12l3-3M3 12l3 3M21 12l-3-3M21 12l-3 3"/></svg>',
  lwp:'<svg viewBox="0 0 24 24"><path d="M3 6h12" stroke-width="1"/><path d="M3 12h12" stroke-width="2.6"/><path d="M3 19h12" stroke-width="4.4"/><path d="M19 5v6M16 8h6" stroke-width="1.8"/></svg>',
  lwm:'<svg viewBox="0 0 24 24"><path d="M3 6h12" stroke-width="1"/><path d="M3 12h12" stroke-width="2.6"/><path d="M3 19h12" stroke-width="4.4"/><path d="M16 8h6" stroke-width="1.8"/></svg>',
  rul:'<svg viewBox="0 0 24 24"><path d="M3.5 16.5l13-13 4 4-13 13z"/><path d="M7 13l2 2M10 10l1.5 1.5M13 7l2 2"/></svg>',
  pen:'<svg viewBox="0 0 24 24"><path d="M4 20l1-4L16.5 4.5a2 2 0 0 1 3 3L8 19z"/><path d="M14 7l3 3"/></svg>',
  er:'<svg viewBox="0 0 24 24"><path d="M4 15l8-9a2 2 0 0 1 3 0l5 5a2 2 0 0 1 0 3l-4 4H8z"/><path d="M9 11l5 5M9 20h11"/></svg>',
  tr:'<svg viewBox="0 0 24 24"><path d="M5 7h14M9 7V4h6v3M7 7l1 13h8l1-13"/></svg>',
  rect:'<svg viewBox="0 0 24 24"><rect x="4" y="6" width="16" height="12" rx="1"/></svg>',
  circ:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/></svg>',
  free:'<svg viewBox="0 0 24 24"><path d="M5 15c-2-6 3-10 8-9s7 5 5 9-9 5-13 0z"/></svg>',
  dot:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="4.5" fill="currentColor"/></svg>',
  txt:'<svg viewBox="0 0 24 24"><path d="M5 6V4h14v2M12 4v16M9 20h6"/></svg>',
  play:'<svg viewBox="0 0 24 24"><path d="M7 5l12 7-12 7z" fill="currentColor"/></svg>',
  pause:'<svg viewBox="0 0 24 24"><path d="M7 5v14M17 5v14" stroke-width="3.4"/></svg>',
  prev:'<svg viewBox="0 0 24 24"><path d="M15 5l-8 7 8 7M18 5v14"/></svg>',
  next:'<svg viewBox="0 0 24 24"><path d="M9 5l8 7-8 7M6 5v14"/></svg>',
  png:'<svg viewBox="0 0 24 24"><path d="M12 4v11M7 11l5 5 5-5M5 20h14"/></svg>',
  gif:'<svg viewBox="0 0 24 24"><rect x="3.5" y="5" width="17" height="14" rx="2"/><path d="M10 9.5l5 2.5-5 2.5z" fill="currentColor"/></svg>',
  ch:'<svg viewBox="0 0 24 24"><path d="M6 9l6 6 6-6"/></svg>'
};
const NVF_LINES=[["solid","خط ساده",'<svg viewBox="0 0 48 20"><path d="M4 10h40" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>'],
  ["dash","خط‌چین",'<svg viewBox="0 0 48 20"><path d="M4 10h40" stroke="currentColor" stroke-width="3" stroke-dasharray="7 5"/></svg>'],
  ["arrow","خط با پیکان",'<svg viewBox="0 0 48 20"><path d="M4 10h38M34 4l9 6-9 6" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>'],
  ["cold","جبههٔ سرد",'<svg viewBox="0 0 48 20"><path d="M4 15h40" stroke="#1d4ed8" stroke-width="2.6"/><path d="M9 15l4-8 4 8zM27 15l4-8 4 8z" fill="#1d4ed8" stroke="none"/></svg>'],
  ["warm","جبههٔ گرم",'<svg viewBox="0 0 48 20"><path d="M4 15h40" stroke="#dc2626" stroke-width="2.6"/><path d="M9 15a4 4 0 0 1 8 0zM27 15a4 4 0 0 1 8 0z" fill="#dc2626" stroke="none"/></svg>'],
  ["occl","جبههٔ مخلوط",'<svg viewBox="0 0 48 20"><path d="M4 15h40" stroke="#7e22ce" stroke-width="2.6"/><path d="M9 15l4-8 4 8zM33 15a4 4 0 0 1 8 0z" fill="#7e22ce" stroke="none"/><path d="M21 15a4 4 0 0 1 8 0z" fill="#7e22ce" stroke="none" transform="translate(-1 0)"/></svg>'],
  ["stat","جبههٔ بندآمده",'<svg viewBox="0 0 48 20"><path d="M4 11h40" stroke="#1d4ed8" stroke-width="2.6"/><path d="M12 11h9M31 11h9" stroke="#dc2626" stroke-width="2.6"/><path d="M8 11l4-8 4 8zM28 11l4-8 4 8z" fill="#1d4ed8" stroke="none"/><path d="M17 11a4 4 0 0 0 8 0zM37 11a4 4 0 0 0 8 0z" fill="#dc2626" stroke="none"/></svg>'],
  ["L","مرکز کم‌فشار (L)",'<b style="color:#d62828;font:800 20px/1 Arial">L</b>'],
  ["H","مرکز پرفشار (H)",'<b style="color:#1d4ed8;font:800 20px/1 Arial">H</b>']];
const NVF_DAYF=new Intl.DateTimeFormat("fa-IR-u-ca-persian",{weekday:"long",day:"numeric",month:"long",timeZone:"UTC"});
const NVF_HMF=new Intl.DateTimeFormat("fa-IR",{hour:"2-digit",minute:"2-digit",hour12:false,timeZone:"UTC"});
const nvfLoc=v=>new Date(+onDate(v)+210*6e4);                       // به وقت ایران
const nvfDayKey=v=>nvfLoc(v).toISOString().slice(0,10);
const nvfFrame=i=>nvIsLong()?nvMonthLab(i.v):`${NVF_DAYF.format(nvfLoc(i.v))} · ${NVF_HMF.format(nvfLoc(i.v))}`;
const nvfLead=i=>(!nvIsLong()&&i.s>=0)?FA(i.s)+" ساعت پس از شروع اجرا":"";
const nvfEsc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));

/* ---------- ساخت و باز/بسته‌کردن ---------- */
function nvfBuild(){
  if(NVF.el) return NVF.el;
  const d=document.createElement("div"); d.id="nvFs"; d.hidden=true; d.dir="rtl";
  d.innerHTML=`
   <div class="fsRow fsA"><select id="fsTc" class="fsSel" data-tip="نوع مدل (بازهٔ زمانی)"></select><div class="fsChips" id="fsMods"></div></div>
   <button type="button" class="fsB fsPng" id="fsPng" data-tip="ذخیرهٔ PNG از همین نما (با هر زوم)">${NVF_I.png}<span>PNG</span></button>
   <div class="fsRow fsM" id="fsMenus">
     <div class="fsDd" data-dd="reg"><button type="button" class="fsB fsDdB"><span class="fsL"></span>${NVF_I.ch}</button><div class="fsPanel"></div></div>
     <div class="fsDd" data-dd="par"><button type="button" class="fsB fsDdB"><span class="fsL"></span>${NVF_I.ch}</button><div class="fsPanel"></div></div>
     <div class="fsDd" data-dd="sec"><button type="button" class="fsB fsDdB"><span class="fsL"></span>${NVF_I.ch}</button><div class="fsPanel"></div></div>
     <div class="fsDd" data-dd="lay"><button type="button" class="fsB fsDdB"><span class="fsL">لایه‌ها و گزینه‌ها</span>${NVF_I.ch}</button><div class="fsPanel"></div></div>
     <select id="fsRun" class="fsSel" data-tip="اجرای مدل (Run)"></select>
     <span class="fsStat" id="fsStat" hidden><span class="spn"></span><span id="fsStT"></span></span>
   </div>
   <div class="fsMain" id="fsMain">
     <div class="fsVT" id="fsVT"></div>
     <div class="fsDraw" id="fsDraw" hidden></div>
   </div>
   <div class="fsLg" id="fsLg"></div>
   <div class="fsTime" id="fsTime"></div>`;
  document.body.append(d); NVF.el=d; nvfBind(d); return d;
}
function nvfEnter(){
  const st=$("nvStage"); if(!st||!ON.man||NVF.on) return; nvfBuild();
  NVF.home={st:st.parentNode, stN:st.nextSibling, lg:$("nvLg")&&$("nvLg").parentNode, lgN:$("nvLg")&&$("nvLg").nextSibling};
  $("fsMain").prepend(st); if($("nvLg")) $("fsLg").append($("nvLg"));
  NVF.el.hidden=false; NVF.on=true; document.documentElement.classList.add("nvfOn"); document.body.classList.add("nvfOn");
  nvfAnn(); nvfVT(); nvfSetTool("pan");
  try{ if(NVF.el.requestFullscreen){ NVF.nat=true; const p=NVF.el.requestFullscreen(); if(p&&p.catch) p.catch(()=>{ NVF.nat=false; }); } }catch(e){ NVF.nat=false; }
  NV.view=null; nvResize(); nvDraw(); nvLegend(); nvfSync(); setTimeout(()=>{ if(NVF.on){ NV.view=null; nvResize(); nvDraw(); nvLegend(); } },250);
}
function nvfExit(){
  if(!NVF.on) return; nvfCloseDd(); nvfTextCancel(); NVF.drag=null; NVF.cur=null; NVF.on=false;
  const h=NVF.home, st=$("nvStage"); if(h&&st){ h.st.insertBefore(st,h.stN&&h.stN.parentNode===h.st?h.stN:null); if($("nvLg")&&h.lg) h.lg.insertBefore($("nvLg"),h.lgN&&h.lgN.parentNode===h.lg?h.lgN:null); }
  if(NVF.ann) NVF.ann.style.pointerEvents="none";
  NVF.el.hidden=true; document.documentElement.classList.remove("nvfOn"); document.body.classList.remove("nvfOn");
  try{ if(document.fullscreenElement===NVF.el&&document.exitFullscreen) document.exitFullscreen(); }catch(e){} NVF.nat=false;
  NV.view=null; nvResize(); nvDraw(); nvLegend();
}
const nvfToggle=()=>NVF.on?nvfExit():nvfEnter();
document.addEventListener("fullscreenchange",()=>{ if(NVF.on&&NVF.nat&&!document.fullscreenElement) nvfExit(); });

/* ---------- همگام‌سازی با وضعیت نمایشگر ---------- */
function nvfSync(){
  if(!NVF.on) return;
  try{ nvfModels(); nvfLabels(); nvfTime(); nvfPlayLbl(); nvfTitle(); if(NVF.dd) nvfFillDd(NVF.dd); }catch(e){ console.warn("nvfSync",e); }
}
function nvfModels(){
  const tc=$("fsTc"); tc.innerHTML=NV_TC.map(([k,f])=>`<option value="${k}"${nvModelsOf(k).length?"":" disabled"}>${f.split(" ")[0]}</option>`).join(""); tc.value=NV.s.tc;
  const ms=nvModelsOf(NV.s.tc), box=$("fsMods"), html=ms.map(([k,o])=>`<button type="button" class="fsChip${k===NV.s.m?" on":""}" data-m="${k}">${nvLabU(k,o,ms.map(q=>q[0]))}</button>`).join("")||'<span class="fsHint">مدلی موجود نیست</span>';
  if(box.__h!==html){ box.innerHTML=html; box.__h=html; } else box.querySelectorAll(".fsChip").forEach(b=>b.classList.toggle("on",b.dataset.m===NV.s.m));
  const on=box.querySelector(".fsChip.on"); if(on&&on.scrollIntoView) { try{ on.scrollIntoView({block:"nearest",inline:"nearest"}); }catch(e){} }
  const M=ON.man.models&&ON.man.models[NV.s.m], run=$("fsRun");
  if(M){ const opts=[[M.run,"اجرا: "+onFmtRun(M.run)+(M.status==="complete"?"":" (در حال ساخت)")]]; if(nvRunPrev(NV.s.m)) opts.push([nvRunPrev(NV.s.m).run,"اجرا: "+onFmtRun(nvRunPrev(NV.s.m).run)+" (قبلی)"]);
    run.innerHTML=opts.map(([r,t])=>`<option value="${r}">${t}</option>`).join(""); run.value=nvRunSel(NV.s.m); run.hidden=false; } else run.hidden=true;
}
function nvfLabels(){
  const reg=nvRegions().find(r=>r[0]===NV.s.reg), p=nvPar(NV.s.p), isSec=p&&p.cat==="sc";
  const L=k=>NVF.el.querySelector(`[data-dd="${k}"] .fsL`);
  L("reg").textContent="منطقه و زوم: "+(reg?reg[1]:"—");
  L("par").textContent=(!isSec&&p)?p.fa:"پارامترهای اصلی"; L("sec").textContent=(isSec&&p)?p.fa:"پارامترهای ثانویه";
  NVF.el.querySelector('[data-dd="par"] .fsB').classList.toggle("on",!!(!isSec&&p)); NVF.el.querySelector('[data-dd="sec"] .fsB').classList.toggle("on",!!isSec);
}
function nvfTitle(){
  let t=$("fsTitle"); const st=$("nvStage"); if(!st) return;
  if(!t){ t=document.createElement("div"); t.id="fsTitle"; t.className="fsUi fsTitle"; st.append(t); }
  const ov=$("nvOv"); t.innerHTML=ov?ov.innerHTML:""; t.hidden=!t.innerHTML;
}

/* ---------- منوهای کشویی ---------- */
function nvfCloseDd(){ NVF.dd=""; if(NVF.el) NVF.el.querySelectorAll(".fsDd.open").forEach(e=>e.classList.remove("open")); }
function nvfOpenDd(k){ if(NVF.dd===k){ nvfCloseDd(); return; } nvfCloseDd(); NVF.dd=k; const d=NVF.el.querySelector(`[data-dd="${k}"]`); d.classList.add("open"); nvfFillDd(k); }
function nvfChip(label,on,attr){ return `<button type="button" class="fsChip${on?" on":""}" ${attr}>${label}</button>`; }
function nvfFillDd(k){
  const pn=NVF.el.querySelector(`[data-dd="${k}"] .fsPanel`); if(!pn) return; let h="";
  const ps=NV.s.m?nvParamsOf(NV.s.m):[];
  if(k==="reg"){ const R=nvRegions(); h=`<div class="fsH">منطقه‌های اصلی</div><div class="fsGrid">${R.slice(0,2).map(r=>nvfChip(r[1],NV.s.reg===r[0],`data-reg="${r[0]}"`)).join("")}</div><div class="fsH">استان‌ها</div><div class="fsGrid">${R.slice(2).map(r=>nvfChip(r[1],NV.s.reg===r[0],`data-reg="${r[0]}"`)).join("")}</div>`; }
  else if(k==="par"){ const cats=(ON.man.cats||[]).slice().sort((a,b)=>a.o-b.o);
    h=cats.filter(c=>c.id!=="sc"&&ps.some(p=>p.cat===c.id)).map(c=>`<div class="fsH">${c.fa}</div><div class="fsGrid">${ps.filter(p=>p.cat===c.id).sort((x,y)=>x.o-y.o).map(p=>nvfChip(p.fa,NV.s.p===p.id,`data-p="${p.id}" data-c="${p.cat}"`)).join("")}</div>`).join("")||'<div class="fsHint">برای این مدل پارامتری نیست</div>'; }
  else if(k==="sec"){ const sp=ps.filter(p=>p.cat==="sc"), base=id=>id.replace(/(6|24|acc)$/,""), used=new Set();
    const sec=g=>`<div class="fsH">${g[0]}</div><div class="fsGrid">${g[1].map(p=>nvfChip(p.fa,NV.s.p===p.id,`data-p="${p.id}" data-c="${p.cat}"`)).join("")}</div>`;
    const gs=NV_SEC_GROUPS.map(([t,ids])=>{ const L=sp.filter(p=>ids.includes(base(p.id))).sort((a,b)=>a.o-b.o); L.forEach(p=>used.add(p.id)); return L.length?sec([t,L]):""; }).join(""), rest=sp.filter(p=>!used.has(p.id));
    h=(gs+(rest.length?sec(["سایر",rest]):""))||'<div class="fsHint">برای این مدل نقشهٔ ثانویه‌ای نیست (فقط ECMWF، GFS، ICON، UKMO و ARPEGE شاخص‌های همرفتی دارند).</div>'; }
  else if(k==="lay"){ const bm=nvBmGet(), alt=$("nvAlt"), p=nvPar(NV.s.p);
    h=`<div class="fsH">مرزها</div><div class="fsGrid">${[["prov","کشور و استان"],["ctry","فقط کشور"],["cnty","با شهرستان"],["none","بدون مرز"]].map(([v,t])=>nvfChip(t,bm===v,`data-bm="${v}"`)).join("")}</div>
      <div class="fsH">لایه‌ها</div><div class="fsGrid">${[["road","جاده‌ها"],["riv","رودخانه‌ها"],["lake","دریاچه‌ها"],["vill","روستاها"],["city","نام شهرها"]].map(([v,t])=>nvfChip(t,!!NV.s[v],`data-ly="${v}"`)).join("")}</div>
      ${p&&p.alt&&alt?`<div class="fsH">گزینه‌ها</div><div class="fsGrid">${nvfChip("اصلاح ارتفاعی (DEM)",!!NV.s.alt,'data-alt="1"')}</div>`:""}`; }
  pn.innerHTML=h; const on=pn.querySelector(".fsChip.on"); if(on&&on.scrollIntoView&&!pn.__sc){ pn.__sc=1; try{ on.scrollIntoView({block:"center"}); }catch(e){} }
}
function nvfDdClick(b){
  const d=b.dataset;
  if(d.reg){ wxSet("nvReg",d.reg); nvfCloseDd(); }
  else if(d.p){ NV.s.cat=d.c; NV.s.p=d.p; nvFillCat(); nvfCloseDd(); }
  else if(d.bm){ const s=$("nvBm"); if(s){ s.value=d.bm; s.onchange(); } nvfFillDd("lay"); }
  else if(d.ly){ const c=document.querySelector(`[data-nvl="${d.ly}"]`); if(c){ c.checked=!NV.s[d.ly]; c.onchange(); } nvfFillDd("lay"); }
  else if(d.alt){ const a=$("nvAlt"); if(a&&!a.disabled){ a.checked=!a.checked; a.onchange(); } nvfFillDd("lay"); }
}

/* ---------- نوار زمان ---------- */
function nvfDays(){ const m=new Map(); (NV.items||[]).forEach((it,i)=>{ const k=nvfDayKey(it.v); if(!m.has(k)) m.set(k,{k,label:NVF_DAYF.format(nvfLoc(it.v)),idx:[]}); m.get(k).idx.push(i); }); return [...m.values()]; }
function nvfScope(){ const n=(NV.items||[]).length, all=[...Array(n).keys()]; if(!NVF.day||nvIsLong()) return all; const d=nvfDays().find(x=>x.k===NVF.day); return d?d.idx:all; }
const nvfCur=()=>{ const s=$("nvFr"); return s?s.selectedIndex:0; };
function nvfGo(i){ const s=$("nvFr"); if(!s||!s.options.length) return; i=Math.max(0,Math.min(s.options.length-1,i)); s.selectedIndex=i; $("nvSl").value=i; s.onchange(); }
function nvfStep(d){ const L=nvfScope(); if(!L.length) return; const p=L.indexOf(nvfCur()); nvfGo(L[p<0?0:(p+d+L.length)%L.length]); }
function nvfPlay(){ if(NV.anim){ clearInterval(NV.anim); NV.anim=null; } else NV.anim=setInterval(()=>{ if(!NV.busy) nvfStep(1); },NVF.spd||750); nvfPlayLbl(); }
function nvfPlayLbl(){ const b=$("fsPlay"); if(b){ b.innerHTML=NV.anim?NVF_I.pause:NVF_I.play; b.dataset.tip=NV.anim?"توقف":"پخش"; } const o=$("nvPlay"); if(o) o.textContent=NV.anim?"⏸ توقف":"▶ پخش"; }
function nvfTime(){
  const box=$("fsTime"), it=NV.items||[], long=nvIsLong(), key=(NV.s.m||"")+"|"+(NV.s.p||"")+"|"+it.length+"|"+(it[0]?it[0].v:"")+"|"+(it.length?it[it.length-1].v:"");
  const days=long?[]:nvfDays();
  if(NVF.key!==key||!box.firstChild){ NVF.key=key; if(NVF.day&&!days.some(d=>d.k===NVF.day)) NVF.day="";
    const frOpts=it.map((x,i)=>`<option value="${i}">${nvfEsc(nvfFrame(x))}</option>`).join("");
    box.innerHTML=`<div class="fsT1"><button type="button" class="fsB fsIc" id="fsPrev" data-tip="ساعت قبلی">${NVF_I.prev}</button><button type="button" class="fsB fsIc fsPl" id="fsPlay" data-tip="پخش"></button><button type="button" class="fsB fsIc" id="fsNext" data-tip="ساعت بعدی">${NVF_I.next}</button>
        <input type="range" id="fsSl" min="0" max="0" value="0" class="fsSl"><span class="fsCur" id="fsCur"></span></div>
      <div class="fsT2">${long?"":`<select id="fsDay" class="fsSel" data-tip="انتخاب روز"><option value="">همهٔ روزها</option>${days.map(d=>`<option value="${d.k}">${d.label}</option>`).join("")}</select>`}
        <label class="fsLb">از <select id="fsFrom" class="fsSel" data-tip="شروع GIF">${frOpts}</select></label><label class="fsLb">تا <select id="fsTo" class="fsSel" data-tip="پایان GIF">${frOpts}</select></label>
        <select id="fsSpd" class="fsSel" data-tip="سرعت پخش و GIF"><option value="1200">سرعت: کند</option><option value="750">سرعت: معمولی</option><option value="400">سرعت: تند</option><option value="200">سرعت: خیلی تند</option></select>
        <select id="fsGq" class="fsSel" data-tip="کیفیت (عرض) GIF"><option value="1200">GIF ۱۲۰۰</option><option value="1800">GIF ۱۸۰۰</option><option value="2400">GIF ۲۴۰۰</option><option value="3000">GIF ۳۰۰۰</option></select>
        <button type="button" class="fsB fsGo" id="fsGif" data-tip="ذخیرهٔ بازهٔ انتخاب‌شده به‌صورت GIF متحرک">${NVF_I.gif}<span>Save GIF</span></button></div>`;
    NVF.from=null; NVF.to=null; }
  const L=nvfScope(), cur=nvfCur(), p=L.indexOf(cur), sl=$("fsSl");
  sl.max=Math.max(0,L.length-1); sl.value=p<0?0:p; $("fsCur").textContent=it[cur]?`${nvfFrame(it[cur])}${nvfLead(it[cur])?"  ·  "+nvfLead(it[cur]):""}`:"—";
  if($("fsDay")) $("fsDay").value=NVF.day;
  if(NVF.from==null||L.indexOf(NVF.from)<0) NVF.from=L[0]!=null?L[0]:0; if(NVF.to==null||L.indexOf(NVF.to)<0) NVF.to=L.length?L[L.length-1]:0;
  $("fsFrom").value=String(NVF.from); $("fsTo").value=String(NVF.to); $("fsSpd").value=String(NVF.spd); $("fsGq").value=String(NVF.gq);
  nvfPlayLbl();
}
async function nvfGif(){
  const a=+$("fsFrom").value, b=+$("fsTo").value; $("nvGf").value=String(Math.min(a,b)); $("nvGt").value=String(Math.max(a,b));
  const w=$("nvGw"); if(![...w.options].some(o=>o.value===String(NVF.gq))) w.add(new Option("GIF "+NVF.gq,String(NVF.gq))); w.value=String(NVF.gq);
  NV.gifDelay=NVF.spd>=1200?150:NVF.spd>=750?80:NVF.spd>=400?45:25; NV.gifHold=Math.max(250,NV.gifDelay*4);
  if(NV.anim) nvfPlay();
  try{ await nvGif(); }catch(e){ onStatus("⚠ "+e.message,0); alert("ساخت GIF انجام نشد: "+e.message); }
}

/* ---------- نوار ابزار عمودی ---------- */
function nvfVT(){
  const T=(id,ico,tip,extra)=>`<button type="button" class="fsB fsIc${extra||""}" data-vt="${id}" data-tip="${tip}">${ico}</button>`;
  $("fsVT").innerHTML=T("zi",NVF_I.zi,"بزرگ‌نمایی")+T("zo",NVF_I.zo,"کوچک‌نمایی")+T("fx",NVF_I.fx,"بازگشت به منطقهٔ انتخابی (Full extent)")+T("pan",NVF_I.pan,"جابه‌جایی (کشیدن نقشه)"," on")+'<i class="fsSep"></i>'+
    T("fp",'<b>A+</b>',"درشت‌کردن فونت لیبل‌ها")+T("fm",'<b>A−</b>',"کوچک‌کردن فونت لیبل‌ها")+T("lp",NVF_I.lwp,"کلفت‌کردن خطوط (مرزها و لایه‌ها)")+T("lm",NVF_I.lwm,"نازک‌کردن خطوط")+'<i class="fsSep"></i>'+
    T("rul",NVF_I.rul,"خط‌کش: اندازه‌گیری فاصله (کیلومتر)")+T("pen",NVF_I.pen,"مداد: نقاشی و تحلیل روی نقشه");
}
function nvfVTState(){ const q=k=>NVF.el.querySelector(`[data-vt="${k}"]`); if(!q("pan")) return;
  q("pan").classList.toggle("on",NVF.tool==="pan"); q("rul").classList.toggle("on",NVF.tool==="rul"); q("pen").classList.toggle("on",NVF.pen);
  const fi=lfIdx(); q("fp").disabled=fi>=LF_STEPS.length-1; q("fm").disabled=fi<=0;
  const li=nvfLwIdx(); q("lp").disabled=li>=NVF_LW.length-1; q("lm").disabled=li<=0; }
function nvfLwIdx(){ const v=+NV.s.lw||1; let b=0; NVF_LW.forEach((x,i)=>{ if(Math.abs(x-v)<Math.abs(NVF_LW[b]-v)) b=i; }); return b; }
function nvfLw(d){ const i=Math.max(0,Math.min(NVF_LW.length-1,nvfLwIdx()+d)); NV.s.lw=NVF_LW[i]; nvSave(); nvDraw(); nvfVTState(); }
function nvfVTClick(id){
  if(id==="zi") nvZoom(1.5); else if(id==="zo") nvZoom(1/1.5); else if(id==="fx"){ nvFitReg(); nvDraw(); }
  else if(id==="pan") nvfSetTool("pan"); else if(id==="fp"){ lfStep(1); nvfVTState(); } else if(id==="fm"){ lfStep(-1); nvfVTState(); }
  else if(id==="lp") nvfLw(1); else if(id==="lm") nvfLw(-1);
  else if(id==="rul") nvfSetTool(NVF.tool==="rul"?"pan":"rul");
  else if(id==="pen"){ if(NVF.pen) nvfSetTool("pan"); else nvfSetTool(NVF.T); }
}

/* ---------- ابزارها ---------- */
const NVF_POLY=["rect","circ","free"];
function nvfSetTool(t){
  nvfTextCancel(); NVF.cur=null; NVF.drag=null;
  if(t==="pan"){ NVF.tool="pan"; NVF.pen=false; NVF.rul=[]; }
  else if(t==="rul"){ NVF.tool="rul"; NVF.pen=false; }
  else { NVF.tool="pen"; NVF.pen=true; NVF.T=t; NVF.rul=[]; }
  const dr=$("fsDraw"); dr.hidden=!NVF.pen; if(NVF.pen) nvfDrawBar();
  if(NVF.ann) NVF.ann.style.pointerEvents=NVF.pen?"auto":"none";
  const st=$("nvStage"); if(st) st.dataset.tool=NVF.pen?NVF.T:NVF.tool;
  nvfVTState(); nvfRedraw();
}
function nvfDrawBar(){
  const T=NVF.T, isLine=NVF_LINES.some(l=>l[0]===T)&&T!=="L"&&T!=="H", isFront=["cold","warm","occl","stat"].includes(T), isPoly=NVF_POLY.includes(T), isTxt=T==="text", isEr=T==="eraser";
  const btn=(id,ico,tip)=>`<button type="button" class="fsB fsIc fsTool${T===id?" on":""}" data-tl="${id}" data-tip="${tip}">${ico}</button>`;
  const polyB=[["rect",NVF_I.rect,"پلیگون: مربع/مستطیل"],["circ",NVF_I.circ,"پلیگون: دایره"],["free",NVF_I.free,"پلیگون: دست‌آزاد"]].map(x=>btn(...x)).join("");
  let h=`<div class="fsD1">${NVF_LINES.map(l=>btn(l[0],l[2],l[1])).join("")}<i class="fsSep"></i>${polyB}<i class="fsSep"></i>${btn("dot",NVF_I.dot,"نقطه")}${btn("text",NVF_I.txt,"نوشتن متن")}<i class="fsSep"></i>${btn("eraser",NVF_I.er,"پاک‌کن")}
    <button type="button" class="fsB fsIc" data-dr="undo" data-tip="بازگردانی (Ctrl+Z)"${NVF.undo.length?"":" disabled"}>↶</button><button type="button" class="fsB fsIc" data-dr="redo" data-tip="تکرار"${NVF.redo.length?"":" disabled"}>↷</button></div><div class="fsD2">`;
  if(isEr) h+=`<span class="fsLb">اندازهٔ پاک‌کن</span>${[10,18,30].map(v=>`<button type="button" class="fsChip${NVF.er===v?" on":""}" data-er="${v}">${v===10?"کوچک":v===18?"متوسط":"بزرگ"}</button>`).join("")}<button type="button" class="fsB fsDanger" data-dr="clear" data-tip="حذف همهٔ نقاشی‌ها از نقشه">${NVF_I.tr}<span>پاک‌کردن همه</span></button>`;
  else{
    h+=`<span class="fsPal">${NVF_COLS.map(c=>`<button type="button" class="fsSw${NVF.col.toLowerCase()===c?" on":""}" data-col="${c}" style="--c:${c}" aria-label="${c}"></button>`).join("")}<input type="color" id="fsCol" value="${NVF.col}" data-tip="رنگ دلخواه"></span>`;
    if(isLine||isPoly||T==="dot") h+=`<label class="fsLb">ضخامت <input type="range" id="fsW" min="1" max="14" step="0.5" value="${NVF.w}"><b>${FA(NVF.w)}</b></label>`;
    if(isPoly) h+=`<label class="fsLb">شفافیت <input type="range" id="fsOp" min="0.05" max="0.9" step="0.05" value="${NVF.op}"><b>${FA(Math.round(NVF.op*100))}٪</b></label>`;
    if(isTxt||T==="H"||T==="L") h+=`<label class="fsLb">اندازه <select id="fsFs" class="fsSel">${[12,16,20,26,34,46].map(v=>`<option value="${v}"${NVF.fs===v?" selected":""}>${FA(v)}</option>`).join("")}</select></label>`;
    if(isTxt) h+=`<label class="fsLb">فونت <select id="fsFf" class="fsSel">${NVF_FFN.map(([k,n])=>`<option value="${k}"${NVF.ff===k?" selected":""}>${n}</option>`).join("")}</select></label>`;
    if(isLine) h+=`<button type="button" class="fsChip${NVF.straight?" on":""}" data-dr="straight" data-tip="کشیدن خط راست بین دو نقطه (به‌جای دست‌آزاد)">راست‌خط</button>`;
    if(isFront) h+=`<button type="button" class="fsChip" data-dr="flip" data-tip="جابه‌جا کردن سمت نمادهای جبهه نسبت به جهت کشیدن">${NVF.flip?"↻":"↺"} سمت نمادها</button>`;
    h+=`<span class="fsHint">${isTxt?"روی نقشه کلیک کنید و بنویسید؛ Enter = ثبت":isLine?(NVF.straight?"کشیدن از نقطهٔ شروع تا پایان":"با کشیدن انگشت/ماوس رسم کنید"):isPoly?(T==="free"?"با کشیدن، محدوده را دورِ ناحیه بکشید":T==="circ"?"از مرکز تا شعاع بکشید":"از گوشه تا گوشه بکشید"):"کلیک کنید"}</span>`; }
  $("fsDraw").innerHTML=h+"</div>";
}
function nvfDrawDo(a){
  if(a==="undo"){ if(NVF.undo.length){ NVF.redo.push(JSON.stringify(NVF.items)); NVF.items=JSON.parse(NVF.undo.pop()); } }
  else if(a==="redo"){ if(NVF.redo.length){ NVF.undo.push(JSON.stringify(NVF.items)); NVF.items=JSON.parse(NVF.redo.pop()); } }
  else if(a==="clear"){ if(NVF.items.length&&confirm("همهٔ نقاشی‌های روی نقشه حذف شود؟")){ nvfPush(); NVF.items=[]; } }
  else if(a==="straight") NVF.straight=!NVF.straight; else if(a==="flip") NVF.flip=!NVF.flip;
  nvfDrawBar(); nvfRedraw();
}
function nvfPush(){ NVF.undo.push(JSON.stringify(NVF.items)); NVF.redo.length=0; if(NVF.undo.length>80) NVF.undo.shift(); }

/* ---------- مختصات و رسم ---------- */
const nvfS2G=p=>[NV.view.x0+p[0]/NV.view.k, NV.view.y0-p[1]/NV.view.k];
const nvfG2S=q=>[(q[0]-NV.view.x0)*NV.view.k, (NV.view.y0-q[1])*NV.view.k];
function nvfPos(e){ const r=$("nvStage").getBoundingClientRect(); return [e.clientX-r.left, e.clientY-r.top]; }
function nvfAnn(){
  const st=$("nvStage"); if(!st) return; let a=$("fsAnn"); if(!a||a.parentNode!==st){ if(a) a.remove(); a=document.createElement("canvas"); a.id="fsAnn"; a.className="fsAnn"; st.append(a); NVF.ann=a; nvfBindAnn(a); }
  NVF.ann=a; return a;
}
function nvfRedraw(){ if(NVF.raf) return; NVF.raf=requestAnimationFrame(()=>{ NVF.raf=0; nvfRedrawNow(); }); }
function nvfRedrawNow(){
  const a=nvfAnn(), cv=$("nvCv"); if(!a||!cv||!NV.view) return; if(a.width!==cv.width||a.height!==cv.height){ a.width=cv.width; a.height=cv.height; }
  const x=a.getContext("2d"); x.clearRect(0,0,a.width,a.height); const v=NV.view, k=v.k*NV.d, sc=NV.d*(NV.z||1);
  nvfPaint(x,k,v.x0,v.y0,sc,NVF.cur,true);
  if(NVF.tool==="pen"||NVF.pen){ if(NVF.T==="eraser"&&NVF.mouse){ x.save(); x.strokeStyle="rgba(0,0,0,.7)"; x.fillStyle="rgba(255,255,255,.35)"; x.lineWidth=1.5*sc; x.beginPath(); x.arc(NVF.mouse[0]*NV.d,NVF.mouse[1]*NV.d,NVF.er*sc,0,6.2832); x.fill(); x.stroke(); x.restore(); } }
}
function nvfPaintExport(x,W,H,k,x0,y0,sc){ if(NVF.on&&(NVF.items.length||NVF.rul.length)) nvfPaint(x,k,x0,y0,sc,null,false); }
function nvfPaint(x,k,x0,y0,sc,cur,live){
  const P=q=>[(q[0]-x0)*k,(y0-q[1])*k];
  for(const it of NVF.items) nvfDrawItem(x,it,P,sc);
  if(cur) nvfDrawItem(x,cur,P,sc);
  nvfPaintRuler(x,P,sc,live);
}
function nvfHalo(x,sc){ x.lineWidth=3.5*sc; x.strokeStyle="rgba(255,255,255,.92)"; x.lineJoin="round"; }
function nvfDrawItem(x,it,P,sc){
  x.save(); x.lineCap="round"; x.lineJoin="round";
  if(it.t==="line"){ const S=it.pts.map(P); if(S.length>=2) nvfLine(x,it,S,sc); }
  else if(it.t==="poly"){ const S=it.pts.map(P); if(S.length>=2){ x.beginPath(); S.forEach((q,i)=>i?x.lineTo(q[0],q[1]):x.moveTo(q[0],q[1])); x.closePath(); x.globalAlpha=it.op; x.fillStyle=it.c; x.fill(); x.globalAlpha=1; x.strokeStyle=it.c; x.lineWidth=it.w*sc; x.stroke(); } }
  else if(it.t==="dot"){ const q=P(it.p); x.beginPath(); x.arc(q[0],q[1],(it.w*1.5+2)*sc,0,6.2832); x.fillStyle=it.c; x.fill(); x.lineWidth=1.5*sc; x.strokeStyle="rgba(255,255,255,.95)"; x.stroke(); }
  else if(it.t==="text"){ const q=P(it.p); x.font=`${it.fs*sc}px ${NVF_FF[it.ff]||NVF_FF.body}`; x.textAlign="center"; x.textBaseline="middle"; x.direction="rtl"; nvfHalo(x,sc); x.strokeText(it.text,q[0],q[1]); x.fillStyle=it.c; x.fillText(it.text,q[0],q[1]); }
  else if(it.t==="hl"){ const q=P(it.p), r=it.fs*1.05*sc; x.beginPath(); x.arc(q[0],q[1],r*1.05,0,6.2832); x.fillStyle="rgba(255,255,255,.82)"; x.fill(); x.lineWidth=2.2*sc; x.strokeStyle=it.k==="H"?"#1d4ed8":"#d62828"; x.stroke();
    x.font=`800 ${it.fs*1.4*sc}px Arial,sans-serif`; x.textAlign="center"; x.textBaseline="middle"; x.direction="ltr"; x.fillStyle=x.strokeStyle; x.fillText(it.k,q[0],q[1]+r*0.06); }
  x.restore();
}
function nvfLine(x,it,S,sc){
  const st=it.st, w=it.w*sc, col={cold:"#1d4ed8",warm:"#dc2626",occl:"#7e22ce",stat:"#1d4ed8"}[st]||it.c;
  const path=()=>{ x.beginPath(); S.forEach((q,i)=>i?x.lineTo(q[0],q[1]):x.moveTo(q[0],q[1])); };
  x.strokeStyle=col; x.lineWidth=w; x.fillStyle=col;
  if(st==="dash") x.setLineDash([Math.max(7,w*3.2),Math.max(5,w*2.2)]);
  path(); x.stroke(); x.setLineDash([]);
  if(st==="stat"){ const sz=(5+it.w*1.7)*sc; x.strokeStyle="#dc2626"; x.setLineDash([sz*1.7,sz*1.7]); x.lineDashOffset=-sz*1.7; path(); x.stroke(); x.setLineDash([]); }
  if(st==="arrow"){ const n=S.length, b=S[n-1]; let a=S[Math.max(0,n-2)]; for(let i=n-2;i>=0;i--){ if(Math.hypot(b[0]-S[i][0],b[1]-S[i][1])>6*sc){ a=S[i]; break; } }
    const an=Math.atan2(b[1]-a[1],b[0]-a[0]), L=(9+it.w*1.8)*sc; x.beginPath(); x.moveTo(b[0],b[1]); x.lineTo(b[0]-L*Math.cos(an-0.45),b[1]-L*Math.sin(an-0.45)); x.lineTo(b[0]-L*Math.cos(an+0.45),b[1]-L*Math.sin(an+0.45)); x.closePath(); x.fillStyle=it.c; x.fill(); }
  if(["cold","warm","occl","stat"].includes(st)){
    const sz=(5+it.w*1.7)*sc, gap=sz*3.5, cum=[0]; for(let i=1;i<S.length;i++) cum.push(cum[i-1]+Math.hypot(S[i][0]-S[i-1][0],S[i][1]-S[i-1][1]));
    const tot=cum[cum.length-1], sg=it.flip?-1:1; let j=1, n=0;
    for(let s=gap*0.55;s<tot-sz;s+=gap,n++){
      while(j<S.length-1&&cum[j]<s) j++;
      const f=(s-cum[j-1])/Math.max(1e-6,cum[j]-cum[j-1]), px=S[j-1][0]+(S[j][0]-S[j-1][0])*f, py=S[j-1][1]+(S[j][1]-S[j-1][1])*f;
      let tx=S[j][0]-S[j-1][0], ty=S[j][1]-S[j-1][1]; const tl=Math.hypot(tx,ty)||1; tx/=tl; ty/=tl;
      let kind=st==="cold"?"t":st==="warm"?"s":st==="occl"?(n%2?"s":"t"):(n%2?"s":"t"), side=sg;
      if(st==="stat"&&n%2) side=-sg;
      const nx=ty*side, ny=-tx*side; x.fillStyle=st==="stat"?(kind==="t"?"#1d4ed8":"#dc2626"):col; x.beginPath();
      if(kind==="t"){ x.moveTo(px-tx*sz*0.85,py-ty*sz*0.85); x.lineTo(px+tx*sz*0.85,py+ty*sz*0.85); x.lineTo(px+nx*sz*1.4,py+ny*sz*1.4); x.closePath(); }
      else{ const a=Math.atan2(ty,tx); x.arc(px,py,sz*0.88,a,a+Math.PI*(side>0?-1:1),side>0); x.closePath(); }
      x.fill(); }
  }
}
/* خط‌کش */
const nvfKm=(a,b)=>{ const R=6371.0088, r=Math.PI/180, dl=(b[1]-a[1])*r, dn=(b[0]-a[0])*r, h=Math.sin(dl/2)**2+Math.cos(a[1]*r)*Math.cos(b[1]*r)*Math.sin(dn/2)**2; return 2*R*Math.asin(Math.min(1,Math.sqrt(h))); };
const nvfKmT=v=>FA(v>=100?Math.round(v):v>=10?v.toFixed(1):v.toFixed(2))+" km";
function nvfPaintRuler(x,P,sc,live){
  const R=NVF.rul; if(!R.length) return; const pts=R.map(P); x.save(); x.lineCap="round"; x.lineJoin="round";
  const G=R.slice(), path=pts.slice(); if(live&&NVF.tool==="rul"&&NVF.mouse&&NV.view){ G.push(nvfS2G(NVF.mouse)); path.push([NVF.mouse[0]*NV.d,NVF.mouse[1]*NV.d]); }
  x.lineWidth=5*sc; x.strokeStyle="rgba(255,255,255,.9)"; x.beginPath(); path.forEach((q,i)=>i?x.lineTo(q[0],q[1]):x.moveTo(q[0],q[1])); x.stroke();
  x.lineWidth=2.4*sc; x.strokeStyle="#e11d48"; x.setLineDash([9*sc,5*sc]); x.stroke(); x.setLineDash([]);
  pts.forEach(q=>{ x.beginPath(); x.arc(q[0],q[1],4.2*sc,0,6.2832); x.fillStyle="#e11d48"; x.fill(); x.lineWidth=1.6*sc; x.strokeStyle="#fff"; x.stroke(); });
  x.font=`700 ${12.5*sc}px ${FT.body}`; x.textAlign="center"; x.textBaseline="bottom"; x.direction="ltr"; let tot=0;
  for(let i=1;i<G.length;i++){ const d=nvfKm(G[i-1],G[i]); tot+=d; const a=path[i-1], b=path[i]; if(Math.hypot(a[0]-b[0],a[1]-b[1])<34*sc) continue;
    const mx=(a[0]+b[0])/2, my=(a[1]+b[1])/2, t=nvfKmT(d); x.lineWidth=4*sc; x.strokeStyle="rgba(255,255,255,.95)"; x.strokeText(t,mx,my-4*sc); x.fillStyle="#9f1239"; x.fillText(t,mx,my-4*sc); }
  if(G.length>1){ const q=path[path.length-1], t="Σ "+nvfKmT(tot); x.font=`800 ${14*sc}px ${FT.body}`; x.textBaseline="top"; x.lineWidth=4.5*sc; x.strokeStyle="rgba(255,255,255,.95)"; x.strokeText(t,q[0],q[1]+8*sc); x.fillStyle="#be123c"; x.fillText(t,q[0],q[1]+8*sc); }
  x.restore();
}
function nvfRuler(){ nvfRedraw(); }

/* ---------- رویدادهای نقاشی ---------- */
function nvfSmooth(S){ let P=S.slice(); for(let r=0;r<2;r++){ if(P.length<4) break; P=P.map((q,i)=>(i===0||i===P.length-1)?q:[(P[i-1][0]+2*q[0]+P[i+1][0])/4,(P[i-1][1]+2*q[1]+P[i+1][1])/4]); }
  const out=[P[0]]; for(const q of P.slice(1)){ const l=out[out.length-1]; if(Math.hypot(q[0]-l[0],q[1]-l[1])>=1.5) out.push(q); } if(out.length<2&&P.length>1) out.push(P[P.length-1]); return out; }
function nvfDense(S,step){ const out=[S[0]]; for(let i=1;i<S.length;i++){ const a=S[i-1], b=S[i], d=Math.hypot(b[0]-a[0],b[1]-a[1]), n=Math.max(1,Math.ceil(d/step)); for(let j=1;j<=n;j++) out.push([a[0]+(b[0]-a[0])*j/n,a[1]+(b[1]-a[1])*j/n]); } return out; }
function nvfBase(){ return {c:NVF.col,w:NVF.w}; }
function nvfBuildCur(){
  const d=NVF.drag; if(!d) return null; const T=NVF.T, S=d.pts, p0=S[0], p1=S[S.length-1];
  if(NVF_LINES.some(l=>l[0]===T)&&T!=="L"&&T!=="H"){ let pp=NVF.straight?[p0,p1]:S; if(pp.length<2) return null; return Object.assign({t:"line",st:T,flip:NVF.flip,pts:pp.map(nvfS2G)},nvfBase()); }
  if(T==="rect"){ const a=[p0[0],p0[1]], b=[p1[0],p0[1]], c=[p1[0],p1[1]], e=[p0[0],p1[1]]; return Object.assign({t:"poly",sh:"rect",op:NVF.op,pts:[a,b,c,e].map(nvfS2G)},nvfBase()); }
  if(T==="circ"){ const r=Math.hypot(p1[0]-p0[0],p1[1]-p0[1]); if(r<2) return null; const pp=[]; for(let i=0;i<72;i++){ const a=i/72*6.28319; pp.push([p0[0]+r*Math.cos(a),p0[1]+r*Math.sin(a)]); } return Object.assign({t:"poly",sh:"circ",op:NVF.op,pts:pp.map(nvfS2G)},nvfBase()); }
  if(T==="free"){ if(S.length<3) return null; return Object.assign({t:"poly",sh:"free",op:NVF.op,pts:nvfSmooth(S).map(nvfS2G)},nvfBase()); }
  return null;
}
function nvfCommit(){
  const d=NVF.drag; if(!d) return; let it=nvfBuildCur(); NVF.drag=null; NVF.cur=null;
  if(it){ if(it.t==="line"){ const S=it.pts.map(nvfG2S); const s2=NVF.straight?S:nvfSmooth(S); if(s2.length<2){ nvfRedraw(); return; } it.pts=nvfDense(s2,4).map(nvfS2G); } nvfPush(); NVF.items.push(it); nvfDrawBar(); }
  nvfRedraw();
}
function nvfSegD(p,a,b){ const dx=b[0]-a[0], dy=b[1]-a[1], l=dx*dx+dy*dy; let t=l?((p[0]-a[0])*dx+(p[1]-a[1])*dy)/l:0; t=Math.max(0,Math.min(1,t)); return Math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy); }
function nvfErase(p){
  const r=NVF.er, out=[]; let ch=false;
  for(const it of NVF.items){
    if(it.t==="line"){ const S=it.pts.map(nvfG2S); let cur=[], pieces=[], hit=false;
      for(let i=0;i<S.length;i++){ if(Math.hypot(S[i][0]-p[0],S[i][1]-p[1])<r){ hit=true; if(cur.length) pieces.push(cur); cur=[]; } else cur.push(it.pts[i]); } if(cur.length) pieces.push(cur);
      if(!hit) out.push(it); else { ch=true; for(const pc of pieces) if(pc.length>=2) out.push(Object.assign({},it,{pts:pc})); } }
    else if(it.t==="poly"){ const S=it.pts.map(nvfG2S); let hit=false; for(let i=0;i<S.length&&!hit;i++) if(nvfSegD(p,S[i],S[(i+1)%S.length])<r) hit=true; if(hit) ch=true; else out.push(it); }
    else { const q=nvfG2S(it.p), rr=r+(it.t==="text"?it.fs*Math.max(1,it.text.length*0.28):it.t==="hl"?it.fs:(it.w||3)*1.5+3); if(Math.hypot(q[0]-p[0],q[1]-p[1])<rr) ch=true; else out.push(it); }
  }
  if(ch) NVF.items=out; return ch;
}
function nvfBindAnn(a){
  a.addEventListener("pointerdown",e=>{ if(!NVF.on||!NVF.pen) return; e.stopPropagation(); if(!e.isPrimary) return; nvfTextCommit(); try{ a.setPointerCapture(e.pointerId); }catch(_){}
    const p=nvfPos(e), T=NVF.T; NVF.drag={pts:[p],id:e.pointerId,moved:false};
    if(T==="eraser"){ nvfPush(); NVF.drag.ch=nvfErase(p); nvfRedraw(); return; }
    if(T==="dot"){ nvfPush(); NVF.items.push({t:"dot",c:NVF.col,w:NVF.w,p:nvfS2G(p)}); NVF.drag=null; nvfDrawBar(); nvfRedraw(); return; }
    if(T==="H"||T==="L"){ nvfPush(); NVF.items.push({t:"hl",k:T,fs:NVF.fs,p:nvfS2G(p)}); NVF.drag=null; nvfDrawBar(); nvfRedraw(); return; }
    if(T==="text") return; nvfRedraw(); });
  a.addEventListener("pointermove",e=>{ NVF.mouse=nvfPos(e); const d=NVF.drag; if(!d||e.pointerId!==d.id){ if(NVF.T==="eraser") nvfRedraw(); return; } e.stopPropagation(); const p=nvfPos(e), l=d.pts[d.pts.length-1];
    if(Math.hypot(p[0]-l[0],p[1]-l[1])>=1){ d.moved=true;
      if(NVF.T==="eraser"){ if(nvfErase(p)) d.ch=true; d.pts=[p]; } else if(NVF.straight||["rect","circ"].includes(NVF.T)){ d.pts=[d.pts[0],p]; } else d.pts.push(p);
      if(NVF.T!=="eraser") NVF.cur=nvfBuildCur(); nvfRedraw(); } });
  const up=e=>{ const d=NVF.drag; if(!d||e.pointerId!==d.id) return; e.stopPropagation(); if(NVF.T==="eraser"){ if(!d.ch) NVF.undo.pop(); NVF.drag=null; nvfDrawBar(); nvfRedraw(); return; }
    if(NVF.T==="text"){ NVF.drag=null; if(!d.moved) nvfTextOpen(d.pts[0]); return; } nvfCommit(); };
  a.addEventListener("pointerup",up); a.addEventListener("pointercancel",e=>{ NVF.drag=null; NVF.cur=null; nvfRedraw(); });
  a.addEventListener("pointerleave",()=>{ NVF.mouse=null; nvfRedraw(); });
}
function nvfTextOpen(p){
  nvfTextCancel(); const st=$("nvStage"); const i=document.createElement("input"); i.type="text"; i.className="fsUi fsTxt"; i.id="fsTxt"; i.dir="auto"; i.placeholder="متن…"; i.style.cssText=`left:${p[0]}px;top:${p[1]}px;font:${NVF.fs}px ${NVF_FF[NVF.ff]};color:${NVF.col}`;
  i.__g=nvfS2G(p); st.append(i); setTimeout(()=>i.focus(),0);
  i.addEventListener("keydown",e=>{ e.stopPropagation(); if(e.key==="Enter"){ e.preventDefault(); nvfTextCommit(); } else if(e.key==="Escape"){ e.preventDefault(); nvfTextCancel(); } });
  i.addEventListener("blur",()=>setTimeout(nvfTextCommit,0)); NVF.txt=i;
}
function nvfTextCommit(){ const i=NVF.txt; if(!i) return; NVF.txt=null; const t=i.value.trim(); const g=i.__g; i.remove(); if(t){ nvfPush(); NVF.items.push({t:"text",text:t,c:NVF.col,fs:NVF.fs,ff:NVF.ff,p:g}); nvfDrawBar(); nvfRedraw(); } }
function nvfTextCancel(){ const i=NVF.txt; if(!i) return; NVF.txt=null; i.remove(); }

/* ---------- رویدادهای کلی ---------- */
let nvfPD=null;
function nvfBind(d){
  d.addEventListener("click",e=>{ const b=e.target.closest("button"); if(!b) return;
    if(b.closest(".fsDd")&&b.classList.contains("fsDdB")){ nvfOpenDd(b.closest(".fsDd").dataset.dd); return; }
    if(b.closest(".fsPanel")){ nvfDdClick(b); return; }
    if(b.dataset.m){ NV.s.m=b.dataset.m; $("nvM").value=b.dataset.m; nvFillRun(); return; }
    if(b.dataset.vt){ nvfVTClick(b.dataset.vt); return; }
    if(b.dataset.tl){ nvfSetTool(b.dataset.tl); return; }
    if(b.dataset.dr){ nvfDrawDo(b.dataset.dr); return; }
    if(b.dataset.col){ NVF.col=b.dataset.col; nvfDrawBar(); return; }
    if(b.dataset.er){ NVF.er=+b.dataset.er; nvfDrawBar(); return; }
    if(b.id==="fsPng"){ nvExport(); return; }
    if(b.id==="fsPrev"){ nvfStep(-1); return; } if(b.id==="fsNext"){ nvfStep(1); return; } if(b.id==="fsPlay"){ nvfPlay(); return; }
    if(b.id==="fsGif"){ nvfGif(); return; } });
  d.addEventListener("change",e=>{ const t=e.target;
    if(t.id==="fsTc"){ NV.s.tc=t.value; $("nvTc").value=t.value; nvFillModels(); }
    else if(t.id==="fsRun"){ NV_RS[NV.s.m]=t.value; $("nvRun").value=t.value; nvFillCat(); try{ nvWx(); }catch(_){} }
    else if(t.id==="fsDay"){ NVF.day=t.value; NVF.from=null; NVF.to=null; const L=nvfScope(); if(L.length&&L.indexOf(nvfCur())<0) nvfGo(L[0]); nvfTime(); }
    else if(t.id==="fsFrom") NVF.from=+t.value; else if(t.id==="fsTo") NVF.to=+t.value;
    else if(t.id==="fsSpd"){ NVF.spd=+t.value; if(NV.anim){ clearInterval(NV.anim); NV.anim=setInterval(()=>{ if(!NV.busy) nvfStep(1); },NVF.spd); } }
    else if(t.id==="fsGq") NVF.gq=+t.value;
    else if(t.id==="fsFs"){ NVF.fs=+t.value; } else if(t.id==="fsFf"){ NVF.ff=t.value; }
    else if(t.id==="fsCol"){ NVF.col=t.value; nvfDrawBar(); } });
  d.addEventListener("input",e=>{ const t=e.target;
    if(t.id==="fsSl"){ const L=nvfScope(); nvfGo(L[+t.value]); }
    else if(t.id==="fsW"){ NVF.w=+t.value; t.nextElementSibling.textContent=FA(NVF.w); } else if(t.id==="fsOp"){ NVF.op=+t.value; t.nextElementSibling.textContent=FA(Math.round(NVF.op*100))+"٪"; } });
  d.addEventListener("pointerdown",e=>{ if(NVF.dd&&!e.target.closest(".fsDd")) nvfCloseDd(); });
}
document.addEventListener("click",e=>{ const b=e.target.closest&&e.target.closest("#nvFsBtn"); if(b){ e.preventDefault(); nvfToggle(); } });
document.addEventListener("keydown",e=>{
  if(!NVF.on) return; const tg=e.target, typing=tg&&(tg.tagName==="INPUT"&&tg.type!=="range"&&tg.type!=="color"||tg.tagName==="TEXTAREA");
  if(e.key==="Escape"){ if(NVF.txt){ nvfTextCancel(); return; } if(NVF.dd){ nvfCloseDd(); return; } if(NVF.tool!=="pan"||NVF.pen){ nvfSetTool("pan"); return; } nvfExit(); return; }
  if(typing) return;
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="z"){ e.preventDefault(); nvfDrawDo(e.shiftKey?"redo":"undo"); return; }
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="y"){ e.preventDefault(); nvfDrawDo("redo"); return; }
  if(tg&&(tg.tagName==="SELECT"||tg.type==="range")) return;
  if(e.key===" "){ e.preventDefault(); nvfPlay(); } else if(e.key==="ArrowLeft"){ nvfStep(1); } else if(e.key==="ArrowRight"){ nvfStep(-1); }
  else if(e.key==="+"||e.key==="="){ nvZoom(1.5); } else if(e.key==="-"){ nvZoom(1/1.5); }
  else if(e.key==="Backspace"&&NVF.tool==="rul"){ NVF.rul.pop(); nvfRedraw(); } });
/* خط‌کش: کلیک (بدون کشیدن) نقطه اضافه می‌کند؛ کشیدن همچنان نقشه را جابه‌جا می‌کند */
(function(){ let d0=null;
  document.addEventListener("pointerdown",e=>{ if(!NVF.on||NVF.tool!=="rul"||NVF.pen) return; const st=$("nvStage"); if(!st||!st.contains(e.target)||e.target.closest(".fsUi,.nvFsB,.ztools")) return; d0={x:e.clientX,y:e.clientY,t:Date.now(),id:e.pointerId}; },true);
  document.addEventListener("pointerup",e=>{ if(!d0||e.pointerId!==d0.id) return; const m=Math.hypot(e.clientX-d0.x,e.clientY-d0.y), tt=Date.now()-d0.t; d0=null; if(m>6||tt>600||!NVF.on||NVF.tool!=="rul") return; NVF.rul.push(nvfS2G(nvfPos(e))); nvfRedraw(); },true);
  document.addEventListener("pointermove",e=>{ if(!NVF.on) return; const st=$("nvStage"); if(!st||!st.contains(e.target)){ if(NVF.mouse){ NVF.mouse=null; nvfCoord(); } return; } NVF.mouse=nvfPos(e); nvfCoord(); if((NVF.tool==="rul"&&NVF.rul.length)||(NVF.pen&&NVF.T==="eraser")) nvfRedraw(); },true);
  document.addEventListener("dblclick",e=>{ if(NVF.on&&NVF.tool==="rul"){ e.stopPropagation(); e.preventDefault(); } },true);
})();
function nvfCoord(){ let c=$("fsCoord"); const st=$("nvStage"); if(!st) return; if(!c){ c=document.createElement("div"); c.id="fsCoord"; c.className="fsUi fsCoord"; st.append(c); }
  if(!NVF.mouse||!NV.view){ c.hidden=true; return; } const g=nvfS2G(NVF.mouse); c.hidden=false; c.textContent=`${Math.abs(g[1]).toFixed(3)}°${g[1]>=0?"N":"S"}  ${Math.abs(g[0]).toFixed(3)}°${g[0]>=0?"E":"W"}`; }
/* وضعیت (پیشرفت ساخت GIF و ...) در لایهٔ تمام‌صفحه هم دیده شود */
(function(){ const o=onStatus; onStatus=function(t,f){ o.apply(this,arguments); try{ const s=$("fsStat"); if(s){ s.hidden=!t; $("fsStT").textContent=t||""; } }catch(e){} }; })();
/* راهنمای شناور (tooltip): برای هر عنصر دارای data-tip هنگام رفتن ماوس روی آن؛ خارج از کادرهای اسکرول‌شونده رسم می‌شود تا بریده نشود */
(function(){ let tp=null, tm=0;
  const hide=()=>{ clearTimeout(tm); if(tp) tp.hidden=true; };
  document.addEventListener("mouseover",e=>{ const el=e.target.closest&&e.target.closest("[data-tip]"); if(!el){ hide(); return; } const t=el.dataset.tip; if(!t||el.disabled&&false){ hide(); return; }
    if(!tp){ tp=document.createElement("div"); tp.id="fsTip"; document.body.append(tp); } tp.textContent=t; tp.hidden=false; tp.style.visibility="hidden"; tp.style.left="0px"; tp.style.top="0px";
    const r=el.getBoundingClientRect(), w=tp.offsetWidth, h=tp.offsetHeight, vw=document.documentElement.clientWidth, vh=document.documentElement.clientHeight;
    let x=r.left+r.width/2-w/2, y=r.bottom+8; const inVT=el.closest&&el.closest(".fsVT");
    if(inVT){ x=r.right+8; y=r.top+r.height/2-h/2; } else if(r.bottom+h+12>vh) y=r.top-h-8;
    x=Math.max(6,Math.min(vw-w-6,x)); y=Math.max(6,Math.min(vh-h-6,y)); tp.style.left=x+"px"; tp.style.top=y+"px"; tp.style.visibility="visible"; clearTimeout(tm); tm=setTimeout(hide,3500); });
  document.addEventListener("mouseout",e=>{ const el=e.target.closest&&e.target.closest("[data-tip]"); if(el&&!el.contains(e.relatedTarget)) hide(); });
  document.addEventListener("pointerdown",hide,true); document.addEventListener("scroll",hide,true);
})();
