/* ===== نمایشگر نقشه‌های مدل (کادر وسط، منوهای آبشاری، زوم و جابه‌جایی، مرزها، نوار رنگ) =====
   کاشی‌های «خاورمیانه» را برنامهٔ nwp_maps.py می‌سازد (فقط لایهٔ رنگیِ گسسته + لایهٔ خطوط)؛ این‌جا رسم می‌شوند.
   • هیچ عدد خام یا جدولی نمایش داده یا دانلود نمی‌شود؛ فقط تصویر نقشه و نمودار.
   • بزرگ‌نمایی: کلاس‌های رنگی دقیقاً همان رنگ‌های نوار می‌مانند (بدون رنگ واسطه)؛ مرز کلاس‌ها با درون‌یابی شمارهٔ کلاس صاف می‌شود. */
const NV_BOX=[20,65,12,42], NV_TW=1440, NV_TH=960, NV_PXD=32;
const NV_TC=[["daily","روزانه (میان‌مدت، روز به روز)"],["weekly","هفتگی"],["monthly","ماهانه"],["seasonal","فصلی (بلندمدت)"],["ens","انسمبل"]];
// مدل‌های بلندمدت برنامه‌ریزی‌شده (داده‌های باز GRIB/NetCDF)؛ تا ساخته‌شدن نقشه‌هایشان به‌صورت «به‌زودی» نشان داده می‌شوند
const NV_PLANNED={
  daily:["NAVGEM (US Navy) — ۰٫۵°، حدود ۷٫۵ روز"],
  ens:["ECMWF — کنترل و میانگین اعضا (۴۶ روزه)","CFS (NOAA) — کنترل و میانگین اعضا (۴۵ روزه)","پارامترها: بارش، دما، ارتفاع ژئوپتانسیل ۵۰۰"],
  weekly:["GEFS (NOAA) — انومالی هفتگی بارش و دما، ۳۵ روزه","CFSv2 (NOAA) — میانگین هفتگی","ECMWF EC46 هفتگی (۴۶ روزه؛ از مهر ۱۴۰۴ دادهٔ باز است — در دست ساخت)"],
  monthly:["NMME — میانگین چندمدلی ماهانه","CFSv2 — ماهانه","CanSIPS (ECCC)","ECMWF EC46 ماهانه (۴۶ روزه — در دست ساخت)"],
  seasonal:["NMME — فصلی (CFSv2، CanCM4i، GEM5-NEMO، NASA، GFDL، NCAR)","CanSIPS (ECCC)","CFSv2 (۹ ماهه)","ECMWF SEAS5 / C3S (نیازمند کلید Copernicus)"] };
const NV_CAPITALS=["تهران","مشهد","اصفهان","شیراز","تبریز","اهواز","کرمان","رشت","یزد","زاهدان","بندرعباس","ارومیه","همدان","کرمانشاه","ساری","گرگان","بوشهر","ایلام","سنندج","زنجان","قزوین","قم","اراک","خرم‌آباد","شهرکرد","بیرجند","سمنان","یاسوج","اردبیل","بجنورد"];
const NV={ s:Object.assign({tc:"daily",m:"",reg:"iran",cat:"",p:"",fr:"",alt:true,brd:true,cnty:true,city:true,riv:true,road:true,lake:true,vill:true},store.get("nv.s",{})),
  view:null, entry:null, tok:0, cache:new Map(), paths:null, regs:null, cw:0, ch:0, d:1, anim:null, drag:null, raf:0, sharp:0, built:false };
const nvSave=()=>store.set("nv.s",NV.s);
const nvScale=sc=>ON.man&&ON.man.scales&&ON.man.scales[sc]||null;
const nvPar=id=>(ON.man&&ON.man.params||[]).find(p=>p.id===id)||null;

/* ---------- داده‌ها و منوها ---------- */
/* دو اجرای هر مدل: اجرای جاری در man.items و اجرای قبلی در man.items_prev (در هاست نگه‌داری می‌شود) */
const NV_RS={};
function nvRunPrev(m){ const o=ON.man&&ON.man.models&&ON.man.models[m]; return o&&o.prev&&o.prev.run?o.prev:null; }
function nvRunSel(m){ const o=ON.man&&ON.man.models&&ON.man.models[m]; if(!o) return ""; const pv=nvRunPrev(m); return pv&&NV_RS[m]===pv.run?pv.run:o.run; }
function nvRunIsPrev(m){ const pv=nvRunPrev(m); return !!(pv&&nvRunSel(m)===pv.run); }
function nvItemsSrc(m){ return nvRunIsPrev(m)?((ON.man&&ON.man.items_prev)||[]).filter(i=>i.m===m):((ON.man&&ON.man.items)||[]); }
function nvMeItems(m){ return (m?nvItemsSrc(m):(ON.man?ON.man.items:[])).filter(i=>i.r==="me" && (!m||i.m===m) && !/L$/.test(i.p)); }
function nvModelsOf(tc){ const M=ON.man&&ON.man.models||{}; const L=Object.entries(M).filter(([k,o])=>((o.info&&o.info.tclass)||"daily")===tc && nvMeItems(k).length);
  // مدل‌های هم‌نام و هم‌رزولوشن (مثلاً دو کلید قدیمی/جدید CFSv2 در فهرست هاست) یکی نشان داده می‌شوند: تازه‌ترین اجرا، و در تساوی بیشترین نقشه
  const best=new Map(); for(const e of L){ const [k,o]=e, key=nvLab(k,o)+"|"+((o.info&&o.info.res)||""), q=best.get(key);
    if(!q){ best.set(key,e); continue; } const r1=String(o.run||""), r0=String(q[1].run||""); if(r1>r0 || (r1===r0 && (o.done||0)>(q[1].done||0))) best.set(key,e); }
  return L.filter(e=>best.get(nvLab(e[0],e[1])+"|"+((e[1].info&&e[1].info.res)||""))===e); }
// نام نمایشی مدل‌ها: عدد به‌صورت رقم (CFSv2 نه CFSVTWO)، حتی اگر فهرست (manifest) نام را با حروف داده باشد
const NV_LAB={gfs:"GFS 13km",gfs25:"GFS 28km",ecmwf:"ECMWF 28km",ecmwf9:"ECMWF 9km",nmme:"NMME",nasa:"NASA",cfsvtwo:"CFSv2",cfsv2:"CFSv2",ccsmfour:"CCSM4",ccsm4:"CCSM4",cansips:"CanSIPS",cancmfour:"CanCM4i"};
function nvDigits(s){ return String(s).replace(/(one|two|three|four|five|six|seven|eight|nine)/gi,m=>({one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9})[m.toLowerCase()]); }
function nvLabU(k,o,list){ const l=nvLab(k,o); if(!list) list=nvModelsOf((((o||{}).info||{}).tclass)||"daily").map(q=>q[0]); const same=(list||Object.keys((ON.man&&ON.man.models)||{}).filter(x=>(((ON.man.models[x].info||{}).tclass)||"daily")===(((o||{}).info||{}).tclass||"daily"))).filter(x=>x!==k&&nvLab(x,ON.man.models[x])===l);
  if(!same.length) return l; const r=(o&&o.info&&o.info.res)||""; return `${l} (${r||k})`; }
/* مالتی‌مدل MetStat: توضیح «از ترکیب کدام مدل‌ها» از فیلد w قلم فهرست (مثلاً "ecmwf9:40,gfs:30,icon:10") */
const NV_MMN={ecmwf9:["اروپا (ECMWF ۹ کیلومتر)","ECMWF 9 km"],ecmwf:["اروپا (ECMWF ۲۸ کیلومتر)","ECMWF 28 km"],gfs:["آمریکا (GFS ۱۳ کیلومتر)","GFS 13 km"],gfs25:["آمریکا (GFS ۲۸ کیلومتر)","GFS 28 km"],icon:["آلمان (ICON)","ICON"],gem:["کانادا (GEM)","GEM"],ukmo:["بریتانیا (UKMO)","UKMO"],arpege:["فرانسه (ARPEGE)","ARPEGE"]};
function nvMmCap(w,pid){ if(!w) return ""; const en=(typeof LANG!=="undefined"&&LANG==="en"), mm=/mx$/.test(pid||"")?"max":/mn$/.test(pid||"")?"min":"w";
  const L=String(w).split(",").map(x=>x.split(":")).filter(x=>NV_MMN[x[0]]).map(x=>{ const n=NV_MMN[x[0]][en?1:0]; return x[1]!=null&&mm==="w"?`${n} ${en?x[1]+"%":FA(+x[1])+"٪"}`:n; });
  if(!L.length) return ""; const j=en?", ":"، ";
  return mm==="w"?(en?"Weighted blend of: ":"ترکیب وزنی مدل‌ها: ")+L.join(j):(en?(mm==="max"?"Maximum of models: ":"Minimum of models: "):(mm==="max"?"بیشینهٔ مدل‌ها از میان: ":"کمینهٔ مدل‌ها از میان: "))+L.join(j); }
function nvLab(k,o){ o=o||{}; const kk=String(k).toLowerCase(); if(kk==="mm") return (typeof LANG!=="undefined"&&LANG==="en")?"MetStat MultiModel":"مالتی مدل MetStat"; if(NV_LAB[kk]) return NV_LAB[kk];
  let nm=o.short||o.name||o.fa||k; if(/^[A-Za-z0-9_-]+$/.test(nm)) nm=nvDigits(nm); return nm; }
function nvAltSet(){ return new Set((ON.man&&ON.man.params||[]).map(p=>p.alt).filter(Boolean)); }
function nvParamsOf(m){ const have=new Set(nvMeItems(m).map(i=>i.p)), alts=nvAltSet(); return (ON.man.params||[]).filter(p=>have.has(p.id)&&!alts.has(p.id)); }
function nvRegions(){
  if(NV.regs) return NV.regs;
  const R=[["me","خاورمیانه",NV_BOX],["iran","ایران",[42.2,64.8,23.4,40.9]]];
  try{ const L=(window.CQC_LAYERS||LAYERS).ostan||[], pv=[];
    for(const f of L){ let w=1e9,e=-1e9,s=1e9,n=-1e9; for(const poly of f.g) for(const ring of poly) for(const [lo,la] of ring){ if(lo<w)w=lo; if(lo>e)e=lo; if(la<s)s=la; if(la>n)n=la; }
      const mx=Math.max((e-w)*0.03,0.04), my=Math.max((n-s)*0.03,0.04); pv.push(["p:"+f.p.name,f.p.name,[w-mx,e+mx,s-my,n+my]]); }
    pv.sort((a,b)=>a[1].localeCompare(b[1],"fa")); R.push(...pv); }catch(e){ console.warn("nv regions",e); }
  return NV.regs=R;
}
const nvRegBox=id=>(nvRegions().find(r=>r[0]===id)||nvRegions()[1])[2];
function nvFill(sel, opts, want){ const s=$(sel); const keep=want!=null?want:s.value; s.innerHTML=opts.map(o=>`<option value="${o[0]}"${o[2]?" disabled":""}>${o[1]}</option>`).join(""); if(opts.some(o=>o[0]===keep&&!o[2])) s.value=keep; else { const f=opts.find(o=>!o[2]); if(f) s.value=f[0]; } return s.value; }
function nvAsideHTML(){
  return `<section class="card" id="nvMenus"><h3>نقشه‌های مدل</h3>
    <div id="nvWx" class="wx"></div>

    <button class="btn sm" type="button" id="onReload">↻ به‌روزرسانی فهرست</button></section>`;
}
function nvViewerHTML(){
  return `<article class="card wide nvCard"><header><h3 id="nvTitle">—</h3><div class="sub" id="nvSub"></div></header>
   <div class="nvTop"><label class="nvTl">مرزها <select id="nvBm"><option value="prov">مرز کشور و استان</option><option value="ctry">فقط مرز کشور</option><option value="cnty">کشور، استان و شهرستان</option><option value="none">بدون مرز</option></select></label>
    <span class="lfBt">${typeof mcFsBtn==="function"?mcFsBtn():""}</span><details class="ovd nvLayDd"><summary>لایه‌ها (جاده، رود، دریاچه، شهر)</summary><div class="ovp">
     <label><input type="checkbox" data-nvl="road"> جاده‌ها</label><label><input type="checkbox" data-nvl="riv"> رودخانه‌ها</label><label><input type="checkbox" data-nvl="lake"> دریاچه‌ها و دریاها</label><label><input type="checkbox" data-nvl="vill"> روستاها و شهرهای کوچک</label><label><input type="checkbox" data-nvl="city"> نام شهرهای اصلی</label></div></details></div>
   <div class="nvStage" id="nvStage"><canvas id="nvCv"></canvas><button type="button" class="mcSave" id="nvSv" title="ذخیره PNG" aria-label="ذخیره PNG">⬇ PNG</button><div class="ztools nvZm"><button type="button" id="nvZi" title="بزرگ‌نمایی">+</button><button type="button" id="nvZo" title="کوچک‌نمایی">−</button><button type="button" id="nvZr" title="بازگشت به منطقهٔ انتخابی (Full extent)">⤢</button></div><button type="button" class="nvFsB" id="nvFsBtn" data-tip="تمام‌صفحه: نقشه با ابزارهای تحلیل و ذخیره" aria-label="تمام‌صفحه"><svg viewBox="0 0 24 24"><rect x="4.5" y="4.5" width="15" height="15" rx="2"/></svg></button><div class="nvBusy" id="nvBusy" hidden><span class="spn"></span> در حال بارگذاری نقشه…</div></div>
   <div class="nvUnder"><button type="button" class="nvI" id="nvInfoBtn" title="توضیح نقشه و پارامتر" aria-label="توضیح نقشه">i</button></div>
   <div class="nvTools">
    <button class="btn sm" id="nvPrev" title="فریم قبل">◀</button><button class="btn sm" id="nvPlay">▶ پخش</button><button class="btn sm" id="nvNext" title="فریم بعد">▶</button>
    <input type="range" id="nvSl" min="0" max="0" value="0"><span class="nvGap"></span>
    <select id="nvPw" title="رزولوشن خروجی PNG (عرض پیکسل؛ لایه‌های برداری و نوشته‌ها در هر اندازه شفاف می‌مانند)"><option value="1800">PNG ۱۸۰۰</option><option value="1200">PNG ۱۲۰۰</option><option value="2400">PNG ۲۴۰۰</option><option value="3000">PNG ۳۰۰۰</option><option value="4000">PNG ۴۰۰۰</option><option value="6000">PNG ۶۰۰۰</option><option value="custom">PNG دلخواه…</option></select><input type="number" id="nvPwC" min="600" max="8000" step="100" value="2500" hidden title="عرض دلخواه (۶۰۰ تا ۸۰۰۰ پیکسل)" style="width:90px"><button class="btn sm" id="nvPng">دانلود PNG</button><select id="nvGf" title="فریم شروع GIF"></select><select id="nvGt" title="فریم پایان GIF"></select><select id="nvGw" title="عرض GIF (پیکسل)"><option value="1200">GIF ۱۲۰۰</option><option value="1800" selected>GIF ۱۸۰۰</option><option value="2400">GIF ۲۴۰۰</option><option value="3000">GIF ۳۰۰۰</option></select><button class="btn sm" id="nvGif">دانلود GIF</button><button class="btn sm" id="nvAn" title="ارسال همین نقشه به صفحهٔ تحلیل">تحلیل</button></div>
   <canvas id="nvLg" class="nvLg"></canvas><div class="nvOv" id="nvOv"></div>
   <div class="wxBar" id="nvBar"></div>
   <div class="hint nvHint" id="nvHint"></div>
   <div class="nvXfer" id="nvXfer"></div><div class="nvXfer mcBox" id="mcBox"></div>
    <details class="nvLegacy"><summary>منوهای کلاسیک و گزینه‌های نمایش</summary>
    <label>نوع مدل (بازهٔ زمانی) <select id="nvTc"></select></label>
    <label>مدل <select id="nvM"></select></label>
    <label>اجرای مدل (Run) <select id="nvRun"></select></label>
    <label>منطقه (زوم) <select id="nvReg"></select></label>
    <label>دستهٔ پارامتر <select id="nvCat"></select></label>
    <label>زیردستهٔ پارامتر <select id="nvP"></select></label>
    <label>فریم زمانی <select id="nvFr"></select></label>
    <label class="chk" id="nvAltL"><input type="checkbox" id="nvAlt"> اصلاح ارتفاعی (DEM ایران؛ فرمول مخصوص هر پارامتر)</label>
    <label class="chk"><input type="checkbox" id="nvBrd"> مرزها (کشورها، استان‌ها)</label>
    <label class="chk"><input type="checkbox" id="nvCnty"> مرز شهرستان‌ها (در زوم ایران و استان‌ها)</label>
    <label class="chk"><input type="checkbox" id="nvCity"> نام شهرها</label>
    <label class="chk"><input type="checkbox" id="nvVill"> روستاها و مراکز جمعیتی (با زوم)</label>
    <label class="chk"><input type="checkbox" id="nvRiv"> رودخانه‌های مهم</label>
    <label class="chk"><input type="checkbox" id="nvRoad"> جاده‌های اصلی</label>
    <label class="chk"><input type="checkbox" id="nvLake"> دریاچه‌ها</label>
    <div class="hint" id="nvInfo"></div>
    <div class="hint" id="nvRunInfo"></div></details></article>`;
}
function nvInit(){
  const stage=$("nvStage"); if(!stage) return;
  NV.regs=null; NV.built=true;
  const tcOpts=NV_TC.map(([k,f])=>[k, f+(nvModelsOf(k).length?"":" — به‌زودی")]);
  $("nvTc").innerHTML=tcOpts.map(o=>`<option value="${o[0]}">${o[1]}</option>`).join(""); $("nvTc").value=NV.s.tc;
  $("nvReg").innerHTML=nvRegions().map((r,i)=>(i===2?`<optgroup label="استان‌ها">`:"")+`<option value="${r[0]}">${r[1]}</option>`).join("")+`</optgroup>`; $("nvReg").value=NV.s.reg; if($("nvReg").value!==NV.s.reg) $("nvReg").value="iran";
  for(const [id,k] of [["nvAlt","alt"],["nvBrd","brd"],["nvCnty","cnty"],["nvCity","city"],["nvVill","vill"],["nvRiv","riv"],["nvRoad","road"],["nvLake","lake"]]){ $(id).checked=!!NV.s[k]; $(id).onchange=()=>{ NV.s[k]=$(id).checked; nvSave(); if(k==="alt") nvFillFr(); else nvDraw(); }; }
  $("nvTc").onchange=()=>{ NV.s.tc=$("nvTc").value; nvFillModels(); };
  $("nvM").onchange=()=>{ NV.s.m=$("nvM").value; nvFillRun(); };
  $("nvRun").onchange=()=>{ NV_RS[NV.s.m]=$("nvRun").value; nvFillCat(); try{ nvWx(); }catch(e){} };
  $("nvReg").onchange=()=>{ NV.s.reg=$("nvReg").value; nvSave(); nvFitReg(); nvDraw(); try{ nvWx(); }catch(e){} };
  $("nvCat").onchange=()=>{ NV.s.cat=$("nvCat").value; nvFillSub(); };
  $("nvP").onchange=()=>{ NV.s.p=$("nvP").value; nvFillFr(); };
  $("nvFr").onchange=()=>{ NV.s.fr=$("nvFr").value; $("nvSl").value=$("nvFr").selectedIndex; nvSave(); nvResolve(); nvFrSync(); };
  $("nvSl").oninput=()=>{ $("nvFr").selectedIndex=+$("nvSl").value; $("nvFr").onchange(); };
  const go=d=>{ const s=$("nvFr"); if(!s.options.length) return; s.selectedIndex=(s.selectedIndex+d+s.options.length)%s.options.length; $("nvSl").value=s.selectedIndex; s.onchange(); };
  $("nvPrev").onclick=()=>go(-1); $("nvNext").onclick=()=>go(1);
  $("nvPlay").onclick=()=>{ if(NV.anim){ clearInterval(NV.anim); NV.anim=null; $("nvPlay").textContent="▶ پخش"; } else { NV.anim=setInterval(()=>{ if(!NV.busy) go(1); },(typeof NVF!=="undefined"&&NVF&&NVF.spd)||750); $("nvPlay").textContent="⏸ توقف"; } };
  if($("nvSv")) $("nvSv").onclick=()=>nvExport(); $("nvZi").onclick=()=>nvZoom(1.5); $("nvZo").onclick=()=>nvZoom(1/1.5); $("nvZr").onclick=()=>{ nvFitReg(); nvDraw(); };
  $("nvPng").onclick=()=>nvExport(); $("nvGif").onclick=()=>nvGif().catch(e=>{ onStatus("⚠ "+e.message,0); alert("ساخت GIF انجام نشد: "+e.message); }); $("nvAn").onclick=()=>nvToAnalysis().catch(e=>{ onStatus("⚠ "+e.message,0); alert("تحلیل انجام نشد: "+e.message); });
  nvTopBind();
  { const pw=$("nvPw"), pc=$("nvPwC"); if(pw){ try{ pw.value=NV.s.pw||"1800"; if(pw.value!==(NV.s.pw||"1800")) pw.value="1800"; pc.value=NV.s.pwc||2500; }catch(e){} pc.hidden=pw.value!=="custom";
    pw.onchange=()=>{ NV.s.pw=pw.value; pc.hidden=pw.value!=="custom"; nvSave(); }; pc.onchange=()=>{ NV.s.pwc=pc.value; nvSave(); }; } }
  nvBindStage(stage); nvWxBind();
  new ResizeObserver(()=>{ nvResize(); nvDraw(); }).observe(stage);
  nvResize(); nvFillModels();
}

/* ===== نوار بالای نقشه: مرزها + لایه‌ها؛ دکمهٔ i؛ ابزار فونت ===== */
const NV_LAYMAP={road:"road",riv:"riv",lake:"lake",vill:"vill",city:"city"};
function nvBmGet(){ return !NV.s.brd?"none":NV.s.cnty?"cnty":NV.s.bc?"ctry":"prov"; }
function nvTopSync(){ const b=$("nvBm"); if(b) b.value=nvBmGet(); document.querySelectorAll("[data-nvl]").forEach(c=>{ c.checked=!!NV.s[NV_LAYMAP[c.dataset.nvl]]; }); }
function nvTopBind(){
  const b=$("nvBm"); if(!b) return; nvTopSync();
  b.onchange=()=>{ const m=b.value; NV.s.brd=m!=="none"; NV.s.cnty=m==="cnty"; NV.s.bc=m==="ctry"; if($("nvBrd")) $("nvBrd").checked=NV.s.brd; if($("nvCnty")) $("nvCnty").checked=NV.s.cnty; nvSave(); nvDraw(); try{ nvWx(); }catch(e){} };
  document.querySelectorAll("[data-nvl]").forEach(c=>{ c.onchange=()=>{ const k=NV_LAYMAP[c.dataset.nvl]; NV.s[k]=c.checked; const id={road:"nvRoad",riv:"nvRiv",lake:"nvLake",vill:"nvVill",city:"nvCity"}[k]; if($(id)) $(id).checked=c.checked; if(c.checked&&k!=="city"&&!GEO.tried) geoLoad(); nvSave(); nvDraw(); }; });
  const i=$("nvInfoBtn"); if(i) i.onclick=nvInfoOpen;
}
const NV_PINFO={
 cvp:["پتانسیل همرفت","ترکیب وزنی شاخص‌های ناپایداری: Lifted Index (وزن بیشتر؛ در راستی‌آزمایی بهترین)، CAPE، KO، Total Totals، Showalter، K، SWEAT، Galvez-Davison، لپس‌ریت ۷۰۰–۵۰۰، رطوبت ترازهای میانی و آب قابل بارش. CIN از آن کم می‌کند و بارش همرفتی مدل اضافه می‌شود. روی دریاها از ۱ اردیبهشت تا ۵ آبان وزن CAPE/CIN ≈۵٪ است."],
 cvi:["شدت همرفت و توفان تندری","CAPE × برش باد ۰–۶ کیلومتر، CAPE، برش‌های باد، تندباد مدل و پتانسیل تندباد پایین‌رو (لپس‌ریت ۸۵۰–۵۰۰ و اختلاف نقطهٔ شبنم ۷۰۰). فقط جایی که پتانسیل همرفت دست‌کم «ضعیف» باشد."],
 hail:["پتانسیل تگرگ","SHIP (SPC)، عمق ناحیهٔ رشد تگرگ (−۱۰ تا −۳۰°C)، ارتفاع تراز صفر درجه، CAPE، لپس‌ریت ۷۰۰–۵۰۰ و برش باد ۰–۶ کیلومتر؛ فقط جایی که همرفت ممکن باشد."],
 ltg:["پتانسیل آذرخش","CAPE × بارش (روش Romps)، Lifted Index، عمق ناحیهٔ مخلوط‌فاز، آب قابل بارش و Total Totals."],
 flood:["پتانسیل سیل‌خیزی","بارش ۱، ۳، ۶ و ۲۴ ساعته × شیب زمین (DEM) × رطوبت خاک؛ شیب تند و خاک مرطوب سیل‌خیزی را بالا می‌برند."],
 wrainl:["هشدار بارش (باران)","بارش ۶ و ۲۴ ساعته با شدت‌های سبک تا سنگین: زرد ≥۵ میلی‌متر در ۶ ساعت یا ≥۱۰ در ۲۴ ساعت، نارنجی ≥۱۲ یا ≥۲۵، قرمز ≥۲۵ یا ≥۵۰ (فقط جایی که دما بالای ۱ درجه است؛ برف در هشدار برف می‌آید)."],
 wrain:["هشدار بارش سنگین","آستانه‌های بارش ۱ تا ۲۴ ساعته (زرد، نارنجی، قرمز)."],
 wsnow:["هشدار بارش برف","بارش برف ۶ و ۲۴ ساعته (آب معادل) با آستانه‌های سه‌سطحی."],
 wice:["هشدار باران یخ‌زده","نوع بارش مدل (باران یخ‌زده/ یخ‌گلوله) همراه با دمای نزدیک صفر."],
 wwind:["هشدار باد و تندباد","تندباد ۱۰ متری مدل (و باد ۱۰ متری) با آستانه‌های سه‌سطحی."],
 wdust:["هشدار خیزش گردوغبار","پتانسیل خیزش: باد شدید سطحی، دمای بالا، رطوبت و بارش کم؛ فقط پتانسیل است نه مشاهده."],
 wfog:["هشدار مه و دید افقی","دید افقی مدل، رطوبت نسبی و باد کم نزدیک سطح."],
 wfrost:["هشدار یخبندان هوا","دمای ۲ متری (با اصلاح ارتفاعی) زیر صفر."],
 wgfrost:["هشدار یخبندان سطح زمین","دمای سطح زمین/ دمای ۲ متری نزدیک صفر در شب‌های آرام."],
 wcold:["هشدار سوزباد (Wind chill)","دمای ۲ متری و سرعت باد ۱۰ متری با فرمول استاندارد Wind chill."],
 wheat:["هشدار گرما","دمای ۲ متری بالا با آستانه‌های سه‌سطحی."],
 whum:["هشدار شرجی","گرمای مرطوب: ترکیب دما و نقطهٔ شبنم (شاخص گرمایی)."],
 wtstm:["هشدار توفان تندری","ترکیب پتانسیل و شدت همرفت."],
 whail:["هشدار تگرگ","از نقشهٔ پتانسیل تگرگ."],
 wltg:["هشدار آذرخش","از نقشهٔ پتانسیل آذرخش."],
 wflood:["هشدار سیل","از نقشهٔ سیل‌خیزی و بارش‌های کوتاه‌مدت."],
 wlog:["هشدار آبگرفتگی","بارش شدید کوتاه‌مدت (۱ و ۳ ساعته) روی زمین کم‌شیب."],
 warn:["هشدار جوی ترکیبی","بیشینهٔ سطح هشدار در همهٔ هشدارهای بالا برای هر نقطه."]
};
function nvInfoOpen(){
  const par=nvPar(NV.s.p)||{}, id=String(NV.s.p||""), base=id.replace(/(6|24|acc)$/,""), d=NV_PINFO[base];
  const win=/6$/.test(id)?"بیشینهٔ ۶ ساعته (پایان ۰۳، ۰۹، ۱۵، ۲۱ UTC)":/24$/.test(id)?"بیشینهٔ ۲۴ ساعته (تا ۲۱ UTC)":/acc$/.test(id)?"بیشینهٔ تجمعی از ابتدای اجرا":"";
  let dlg=$("nvInfoDlg"); if(!dlg){ dlg=document.createElement("dialog"); dlg.id="nvInfoDlg"; dlg.className="nvDlg"; document.body.appendChild(dlg); }
  const esc=t=>String(t).replace(/[&<>]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]));
  const body=d?`<p><b>${esc(d[0])}</b>${win?` — ${win}`:""}</p><p>${esc(d[1])}</p><p class="hint">نقشهٔ ثانویه است: از ترکیب چند پارامتر و نقشهٔ دیگر ساخته شده و مقدار عددی خام نشان نمی‌دهد.</p>`
    :`<p><b>${esc(par.fa||id||"—")}</b>${par.unit?` (${esc(par.unit)})`:""}</p><p>خروجی مستقیم مدل عددی روی شبکهٔ مدل؛ دسته‌بندی رنگی گسسته.</p>`;
  dlg.innerHTML=`<div class="nvDlgB"><button type="button" class="nvDlgX" aria-label="بستن">×</button>${body}<p class="hint">${esc(($("nvInfo")||{}).textContent||"")} ${esc(($("nvRunInfo")||{}).textContent||"")}</p></div>`;
  dlg.querySelector(".nvDlgX").onclick=()=>dlg.close(); dlg.onclick=e=>{ if(e.target===dlg) dlg.close(); };
  try{ dlg.showModal(); }catch(e){ dlg.setAttribute("open",""); }
}

/* ===== انتقال نقشهٔ بارش/دما به صفحهٔ «اصلاح با ارتفاع» ===== */
const NVX={ms:new Set(), p:"", v:""};
function nvXItems(){ return (ON.man&&ON.man.items||[]).filter(i=>i.r==="iran"&&!/L$/.test(i.p)); }
function nvXParams(){ const have=new Set(nvXItems().map(i=>i.p)); return ((ON.man&&ON.man.params)||[]).filter(p=>have.has(p.id)&&!/snow|^sn|^s\d/i.test(p.id)&&["precip","temp"].includes(nvKind(p))&&!(p.alt&&false)); }
function nvXRender(){
  const box=$("nvXfer"); if(!box||!ON.man||!ON.man.items) return;
  const ps=nvXParams(); if(!ps.length){ box.innerHTML=""; return; }
  if(!ps.some(p=>p.id===NVX.p)) NVX.p=(ps.find(p=>p.id===NV.s.p)||ps.find(p=>nvKind(p)==="precip")||ps[0]).id;
  const its=nvXItems().filter(i=>i.p===NVX.p), ms=[...new Set(its.map(i=>i.m))];
  if(!NVX.ms.size) ms.slice(0,1).forEach(m=>NVX.ms.add(m)); [...NVX.ms].forEach(m=>{ if(!ms.includes(m)) NVX.ms.delete(m); });
  const vs=[...new Set(its.filter(i=>NVX.ms.has(i.m)).map(i=>i.v))].sort(); if(!vs.includes(NVX.v)) NVX.v=vs[0]||"";
  box.innerHTML=`<div class="nvXh">اصلاح با ارتفاع (DEM): ارسال نقشه به صفحهٔ «اصلاح با ارتفاع»</div>
   <div class="wxRow">${ms.map(m=>`<label class="nvXm"><input type="checkbox" data-xm="${m}"${NVX.ms.has(m)?" checked":""}> ${nvLab(m,ON.man.models[m])}</label>`).join("")||'<span class="hint">مدلی برای این پارامتر نیست</span>'}</div>
   <div class="wxRow"><select id="nvXp">${ps.map(p=>`<option value="${p.id}"${p.id===NVX.p?" selected":""}>${p.fa}</option>`).join("")}</select>
   <select id="nvXv">${vs.map(v=>`<option value="${v}"${v===NVX.v?" selected":""}>${onFmtValid(v)}</option>`).join("")||'<option value="">—</option>'}</select></div>
   <button type="button" class="btn sm" id="nvXgo">انتقال نقشه به صفحهٔ اصلاح با ارتفاع</button>
   <div class="hint">نقشهٔ مدل‌های انتخابی (ایران) به صفحهٔ اصلاح با ارتفاع می‌رود؛ اصلاح دما یا بارش با همان استانداردها و گزینه‌های آن صفحه ادامه پیدا می‌کند.</div>`;
  if(!box.__b){ box.__b=1;
    box.addEventListener("change",e=>{ const t=e.target; if(t.dataset&&t.dataset.xm){ t.checked?NVX.ms.add(t.dataset.xm):NVX.ms.delete(t.dataset.xm); return nvXRender(); } if(t.id==="nvXp"){ NVX.p=t.value; return nvXRender(); } if(t.id==="nvXv"){ NVX.v=t.value; } });
    box.addEventListener("click",async e=>{ if(!e.target.closest("#nvXgo")) return;
      try{ const pick=nvXItems().filter(i=>i.p===NVX.p&&i.v===NVX.v&&NVX.ms.has(i.m)&&(!nvRunPrev(i.m)||!nvRunIsPrev(i.m))); if(!pick.length) return alert("برای این انتخاب نقشه‌ای نیست");
        const files=await onFiles(pick); files.forEach(f=>{ f.mtGeo=NWP_GEO.iran.slice(); }); onStatus("ارسال به صفحهٔ اصلاح با ارتفاع…",0.6); await openDS(); await dsAdd(files); onStatus("آماده",1); }
      catch(err){ onStatus("⚠ "+err.message,0); alert("انتقال انجام نشد: "+err.message); } }); }
}
function nvRefreshMenus(){ if(!NV.built||!$("nvTc")) return; const cur=$("nvTc").value;
  $("nvTc").innerHTML=NV_TC.map(([k,f])=>`<option value="${k}">${f+(nvModelsOf(k).length?"":" — به‌زودی")}</option>`).join(""); $("nvTc").value=cur; nvFillModels(); try{ nvWx(); }catch(e){} }
function nvFillModels(){
  if(!store.get("nv.def2",0)){ store.set("nv.def2",1); NV.s.m="ecmwf"; NV.s.p="pacc"; NV.s.cat="pr"; NV.s.fr=""; nvSave(); }
  const ms=nvModelsOf(NV.s.tc), planned=(NV_PLANNED[NV.s.tc]||[]).filter(t=>{ const f=t.toLowerCase().split(/[\s(]/)[0]; return !ms.some(([k,o])=>(nvLab(k,o)+" "+k+" "+(o.name||"")+" "+(o.fa||"")).toLowerCase().includes(f)); });
  const opts=ms.map(([k,o])=>[k,`${nvLabU(k,o,ms.map(q=>q[0]))}${o.info&&o.info.res?" — "+o.info.res:""}`]).concat(planned.map((t,i)=>["~"+i,t+" (به‌زودی)",true]));
  if(!opts.length) opts.push(["","— مدلی موجود نیست —",true]);
  NV.s.m=nvFill("nvM",opts,NV.s.m); nvFillRun();
}
function nvFillRun(){
  const o=ON.man&&ON.man.models&&ON.man.models[NV.s.m];
  const run=o?o.run:"", pv=nvRunPrev(NV.s.m), opts=run?[[run,onFmtRun(run)+(o.status==="complete"?"":" (در حال ساخت)")]]:[["","—",true]];
  if(pv) opts.push([pv.run,onFmtRun(pv.run)+" (اجرای قبلی)"]);
  nvFill("nvRun",opts,nvRunSel(NV.s.m)); nvFillCat();
}
// پارامتر هم‌ارز در مدل‌های مختلف (مثلاً تجمعی: pacc در مدل‌های روزانه، ptot در CFS/ECMWF گروهی)؛ با عوض‌کردن مدل، پارامتر انتخابی به‌جای افتادن روی ۲۴ ساعته به همتای خودش می‌رود
const NV_PEQ=[["pacc","ptot","pt","tot"]];
function nvEqParam(m){ if(!m||!NV.s.p) return; const ps=nvParamsOf(m); if(ps.some(p=>p.id===NV.s.p)) return;
  for(const g of NV_PEQ){ if(!g.includes(NV.s.p)) continue; const q=ps.find(p=>g.includes(p.id)); if(q){ NV.s.p=q.id; NV.s.cat=q.cat; return; } } }
function nvFillCat(){
  nvEqParam(NV.s.m);
  const m=NV.s.m, cats=((ON.man&&ON.man.cats)||[]).slice().sort((a,b)=>a.o-b.o), ps=m?nvParamsOf(m):[];
  const opts=cats.filter(c=>ps.some(p=>p.cat===c.id)).map(c=>[c.id,c.fa]); if(!opts.length) opts.push(["","— پارامتری موجود نیست —",true]);
  NV.s.cat=nvFill("nvCat",opts,NV.s.cat); nvFillSub();
}
function nvFillSub(){
  const ps=NV.s.m?nvParamsOf(NV.s.m).filter(p=>p.cat===NV.s.cat).sort((a,b)=>a.o-b.o):[];
  NV.s.p=nvFill("nvP",ps.length?ps.map(p=>[p.id,p.fa]):[["","—",true]],NV.s.p); nvFillFr();
}
function nvPid(){ const p=nvPar(NV.s.p); return p && p.alt && !NV.s.alt ? p.alt : NV.s.p; }
const NV_MONTH=new Intl.DateTimeFormat("fa-IR-u-ca-persian",{year:"numeric",month:"long",timeZone:"UTC"});
const NV_GM=new Intl.DateTimeFormat("fa-IR-u-ca-gregory",{year:"numeric",month:"long",timeZone:"UTC"}), NV_PM=new Intl.DateTimeFormat("fa-IR-u-ca-persian",{month:"long",timeZone:"UTC"}), NV_PY=new Intl.DateTimeFormat("fa-IR-u-ca-persian",{year:"numeric",timeZone:"UTC"});
function nvSpan(){ const t=((ON.man&&ON.man.models[NV.s.m]||{}).info||{}).tclass; return t==="seasonal"?3:1; }
const NV_PD=new Intl.DateTimeFormat("fa-IR-u-ca-persian",{day:"numeric",timeZone:"UTC"});
/* اصلاح تاریخ ماه پیش‌بینی (مدل‌های ماهانه/فصلی): اگر ماه اعتبار با ماه اجرا نمی‌خواند (مثلاً سال ۲۰۸۹ به‌خاطر واحد محور target)،
   ماه‌ها به‌ترتیب از ماه اجرا شمرده می‌شوند. نام فایل‌ها (v اصلی) دست‌نخورده می‌ماند و فقط برچسب نمایشی اصلاح می‌شود. */
const NV_VFIX={};
function nvFixMonths(){ const M=(ON.man&&ON.man.models)||{}; for(const k in NV_VFIX) delete NV_VFIX[k];
  for(const [k,o] of Object.entries(M)){ const tc=(o.info&&o.info.tclass)||"daily"; if(tc!=="monthly"&&tc!=="seasonal") continue;
    const run=o.run||""; if(run.length<8) continue; const idx=v=>+v.slice(0,4)*12+ +v.slice(4,6)-1, rm=idx(run);
    const vs=[...new Set((ON.man.items||[]).filter(i=>i.m===k).map(i=>String(i.v)))].sort(); if(!vs.length) continue;
    if(vs.every(v=>{const d=idx(v)-rm; return d>=-1&&d<=14})) continue;
    vs.forEach((v,j)=>{ const t=rm+j; NV_VFIX[k+"|"+v]=Math.floor(t/12)+String(t%12+1).padStart(2,"0")+"0100"; }); } }
function nvMonthLab(v,n){ n=n||nvSpan(); const d=onDate(NV_VFIX[NV.s.m+"|"+v]||v), e=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+n,0)); /* اولین و آخرین روز بازه، طبق تقویم دقیق همان ماه و سال */
  const y1=NV_PY.format(d), y2=NV_PY.format(e), g=n>1?`${NV_GM.format(d)} تا ${NV_GM.format(e)}`:NV_GM.format(d);
  return `${g} (${NV_PD.format(d)} ${NV_PM.format(d)}${y1!==y2?" "+y1:""} تا ${NV_PD.format(e)} ${NV_PM.format(e)} ${y2})`; }
function nvFrLab(i){ const tc=(ON.man.models[NV.s.m].info||{}).tclass||"daily";
  if(tc==="monthly"||tc==="seasonal") return nvMonthLab(i.v);
  return `${i.s>=0?FA(i.s)+" ساعت — ":""}${persianDT(onDate(i.v),210)}`; }
// همگام‌سازی دکمه‌های ساعت پیش‌بینی (رنگ آبی) و لیست‌های آینه‌ای با فریم انتخاب‌شده، بدون بازسازی کل پنل
function nvFrSync(){ try{ const box=$("nvWx"); if(!box) return;
  box.querySelectorAll("button[data-fr]").forEach(b=>{ b.classList.toggle("on", b.dataset.fr===NV.s.fr); });
  box.querySelectorAll("select[data-mirror]").forEach(m=>{ const src=$(m.dataset.mirror); if(src&&m.value!==src.value) m.value=src.value; });
  const on=box.querySelector("button[data-fr].on"); if(on&&on.scrollIntoView&&on.parentElement&&on.parentElement.scrollHeight>on.parentElement.clientHeight+2) on.scrollIntoView({block:"nearest"}); }catch(e){} try{ NVF.sync(); }catch(e){} }
function nvFillFr(){
  const p=nvPar(NV.s.p), hasAlt=!!(p&&p.alt);
  $("nvAlt").disabled=!hasAlt; $("nvAltL").title=hasAlt?"":"برای این پارامتر اصلاح ارتفاعی تعریف نشده است (فقط دما)";
  const it=(NV.s.m&&NV.s.p?nvMeItems(NV.s.m).filter(i=>i.p===nvPid()):[]).sort((a,b)=>a.s-b.s);
  NV.items=it; const run=ON.man&&ON.man.models&&ON.man.models[NV.s.m];
  $("nvFr").innerHTML=it.map(i=>`<option value="${i.v}">${nvFrLab(i)}</option>`).join("")||`<option value="">—</option>`;
  const want=NV.s.fr; if(it.some(i=>i.v===want)) $("nvFr").value=want; else { const f=it.find(i=>i.s>=3)||it[0]; if(f) $("nvFr").value=f.v; }
  NV.s.fr=$("nvFr").value; $("nvSl").max=Math.max(0,it.length-1); $("nvSl").value=$("nvFr").selectedIndex; nvSave();
  const info=run&&run.info||{}; $("nvInfo").textContent=[info.res&&("رزولوشن مدل: "+info.res), info.cyc&&("اجراها: "+info.cyc+"Z"), info.prov&&("منبع: "+info.prov+" · Open-Meteo (CC BY 4.0)")].filter(Boolean).join(" · ");
  $("nvRunInfo").innerHTML=ON.man&&ON.man.models?Object.entries(ON.man.models).map(([k,o])=>`${nvLab(k,o)}: ${onFmtRun(o.run)} · ${o.status==="complete"?"کامل":"در حال ساخت"} · ${FA(o.done||0)} نقشه`).join("<br>"):"";
  nvGifFill(); nvResolve(); try{ nvWx(); }catch(e){ console.warn(e); }
}
const onDate=v=>new Date(Date.UTC(+v.slice(0,4),+v.slice(4,6)-1,+v.slice(6,8),+v.slice(8,10)));

/* ---------- بارگذاری کاشی ---------- */
function nvRunQ(){ try{ const r=nvRunSel(NV.s.m); return r?"?r="+encodeURIComponent(r):""; }catch(e){ return ""; } }   // با عوض‌شدن اجرای مدل، نشانی تصویر هم عوض می‌شود تا کش قدیمی استفاده نشود
function nvImg(url){
  if(NV.cache.has(url)) return NV.cache.get(url);
  const p=new Promise(res=>{ const im=new Image(); im.onload=()=>res(im); im.onerror=()=>res(null); im.src=url; });
  NV.cache.set(url,p); if(NV.cache.size>60){ const k=NV.cache.keys().next().value; NV.cache.delete(k); } return p;
}
async function nvResolve(){
  const tok=++NV.tok, it=NV.items||[], cur=it.find(i=>i.v===NV.s.fr);
  if(!cur){ NV.entry=null; $("nvTitle").textContent=ON.man&&ON.man.items&&ON.man.items.length?"نقشه‌ای برای این انتخاب نیست":"—"; $("nvSub").textContent=""; nvDraw(); return; }
  NV.busy=true; $("nvBusy").hidden=false;
  const P0=nvPar(nvPid())||nvPar(NV.s.p), url0=ON.base+cur.f, url=url0+nvRunQ(), lurl=P0&&P0.ln?url0.replace(/\/([a-zA-Z0-9]+)_(\d{10}\.webp)$/,"/$1L_$2")+nvRunQ():null;
  const [img,lay]=await Promise.all([nvImg(url), lurl?nvImg(lurl):null]);
  if(tok!==NV.tok) return;
  NV.busy=false; $("nvBusy").hidden=true;
  NV.entry={item:cur, img, lay, par:P0, sc:P0&&nvScale(P0.sc), idx:null};
  nvTitle(); if(!img) $("nvSub").textContent="⚠ تصویر نقشه از هاست بارگذاری نشد"; nvLegend(); nvDraw(); try{ NVF.sync(); }catch(e){}
  const k=it.findIndex(i=>i.v===cur.v), nx=it[k+1]; if(nx&&P0) nvImg(ON.base+nx.f+nvRunQ());       // فریم بعدی از پیش گرفته می‌شود
}
function nvIsLong(){ const t=((ON.man.models[NV.s.m]||{}).info||{}).tclass||"daily"; return t==="monthly"||t==="seasonal"; }
function nvTitle(){
  const e=NV.entry; if(!e) return; const M=ON.man.models[NV.s.m], reg=nvRegions().find(r=>r[0]===NV.s.reg), mu=e.par&&(e.par.mu||e.par.unit)||"";
  $("nvTitle").textContent=`${e.par?e.par.fa:""}${nvIsLong()?" — "+nvMonthLab(e.item.v):""}`;
  $("nvSub").textContent=`${M?nvLab(NV.s.m,M):""} · ${onFmtRun(nvRunSel(NV.s.m))} · ${nvIsLong()?"ماه پیش‌بینی: "+nvMonthLab(e.item.v):"اعتبار: "+onFmtValid(e.item.v)+" · "+FA(e.item.s)+" ساعت پس از شروع اجرا"} · ${reg?reg[1]:""}${mu?` · واحد: ${mu}`:""}`;
  const ov=$("nvOv"); if(ov){ const lng=nvIsLong(); ov.innerHTML=`<b>${e.par?e.par.fa:""}</b><span>${M?nvLab(NV.s.m,M):""} · ${lng?"ماه پیش‌بینی: "+nvMonthLab(e.item.v):"اعتبار: "+onFmtValid(e.item.v)}</span><span>${onFmtRun(M.run)}${reg?" · "+reg[1]:""}</span>`; }
  { let cp=$("nvCap"); if(!cp&&$("nvSub")){ cp=document.createElement("div"); cp.id="nvCap"; cp.className="nvSub"; cp.style.fontWeight="600"; $("nvSub").insertAdjacentElement("afterend",cp); } if(cp){ const t=nvMmCap(e.item&&e.item.w,e.item&&e.item.p); cp.textContent=t; cp.style.display=t?"":"none"; } }
  $("nvHint").textContent="با کشیدن جابه‌جا کنید، با چرخ ماوس یا دو انگشت بزرگ‌نمایی کنید. فقط تصویر نقشه نمایش داده می‌شود؛ داده‌های عددی مدل در دسترس نیست.";
}

/* ---------- کادر و دوربین ---------- */
/* ضریب بزرگ‌نمایی صفحه (در «نسخه دسکتاپ» موبایل، کل صفحه با zoom بزرگ می‌شود؛ متن canvas هم باید همان‌قدر بزرگ شود) */
function nvZ(){ try{ const z=parseFloat(getComputedStyle(document.documentElement).zoom); return z>0?z:1; }catch(e){ return 1; } }
/* نمای خروجی یکسان در همهٔ دستگاه‌ها: مقیاس خط/برچسب مثل صفحهٔ ۱۰۰۰ پیکسلی، نسبت تصویر افقی، و دست‌کم همان محدودهٔ دیده‌شده */
function nvExpView(){ const v=NV.view, L0=NV.cw/v.k, H0=NV.ch/v.k, cx=v.x0+L0/2, cy=v.y0-H0/2; let L=L0, H=H0;
  const R=Math.max(0.62,Math.min(0.78,H0/L0)); if(H/L>R) L=H/R; else H=L*R;
  return {R, L, H, x0:cx-L/2, y0:cy+H/2, ref:Math.max(NV.cw/(NV.z||1),1000)}; }
function nvResize(){ const st=$("nvStage"), cv=$("nvCv"); if(!st||!cv) return; const r=st.getBoundingClientRect(); if(!r.width) return;
  NV.d=Math.min(2,window.devicePixelRatio||1); NV.z=nvZ(); NV.cw=r.width; NV.ch=r.height; cv.width=Math.round(r.width*NV.d); cv.height=Math.round(r.height*NV.d);
  if(!NV.view) nvFitReg(); else nvClamp(); }
function nvFitBox(box){ const [w,e,s,n]=box, k=Math.min(NV.cw/(e-w), NV.ch/(n-s)); NV.view={k, x0:(w+e)/2-NV.cw/2/k, y0:(s+n)/2+NV.ch/2/k}; nvClamp(); }
function nvFitReg(){ if(NV.cw) nvFitBox(nvRegBox(NV.s.reg)); }
function nvClamp(){ const v=NV.view; if(!v) return; const kmin=Math.max(NV.cw/(NV_BOX[1]-NV_BOX[0]), NV.ch/(NV_BOX[3]-NV_BOX[2])); v.k=Math.max(kmin,Math.min(2400,v.k));
  const vw=NV.cw/v.k, vh=NV.ch/v.k; v.x0=Math.max(NV_BOX[0],Math.min(NV_BOX[1]-vw,v.x0)); v.y0=Math.max(NV_BOX[2]+vh,Math.min(NV_BOX[3],v.y0)); }
function nvZoom(f,cx,cy){ const v=NV.view; if(!v) return; cx=cx==null?NV.cw/2:cx; cy=cy==null?NV.ch/2:cy;
  const lon=v.x0+cx/v.k, lat=v.y0-cy/v.k; v.k*=f; nvClamp(); v.x0=lon-cx/v.k; v.y0=lat+cy/v.k; nvClamp(); nvDraw(true); nvSharpLater(); }
function nvBindStage(st){
  const pts=new Map(); let last=null;
  const pos=e=>{ const r=st.getBoundingClientRect(); return [e.clientX-r.left, e.clientY-r.top]; };
  st.addEventListener("pointerdown",e=>{ if(e.target.closest&&e.target.closest(".ztools,.mcSave,.nvFsB,.fsUi")) return; st.setPointerCapture(e.pointerId); pts.set(e.pointerId,pos(e)); last=null; st.classList.add("drag"); });
  st.addEventListener("pointermove",e=>{ if(!pts.has(e.pointerId)) return; const p=pos(e), o=pts.get(e.pointerId); pts.set(e.pointerId,p); const v=NV.view; if(!v) return;
    if(pts.size===1){ v.x0-= (p[0]-o[0])/v.k; v.y0+= (p[1]-o[1])/v.k; nvClamp(); nvDraw(true); nvSharpLater(); }
    else if(pts.size===2){ const [a,b]=[...pts.values()], dd=Math.hypot(a[0]-b[0],a[1]-b[1]), c=[(a[0]+b[0])/2,(a[1]+b[1])/2]; if(last){ nvZoom(dd/last.d,c[0],c[1]); v.x0-=(c[0]-last.c[0])/v.k; v.y0+=(c[1]-last.c[1])/v.k; nvClamp(); } last={d:dd,c}; } });
  const up=e=>{ pts.delete(e.pointerId); last=null; if(!pts.size) st.classList.remove("drag"); };
  st.addEventListener("pointerup",up); st.addEventListener("pointercancel",up);
  st.addEventListener("wheel",e=>{ e.preventDefault(); const [x,y]=pos(e); nvZoom(e.deltaY<0?1.25:0.8,x,y); },{passive:false});
  st.addEventListener("dblclick",e=>{ const [x,y]=pos(e); nvZoom(2,x,y); });
}

/* ---------- لایه‌های برداری (مرزها) ---------- */
function nvPaths(){
  if(NV.paths) return NV.paths; const P={ctry:new Path2D(),coast:new Path2D(),prov:new Path2D(),cnty:new Path2D(),ostan:new Path2D()};
  try{ const B=borderLines(); for(const [k,L] of [["ctry",B.ctry],["coast",B.coast],["prov",B.prov]]) for(const pts of (L||[])){ for(let i=0;i<pts.length;i+=2){ if(i) P[k].lineTo(pts[i],pts[i+1]); else P[k].moveTo(pts[i],pts[i+1]); } } }catch(e){ console.warn("nv borders",e); }
  try{ const LY=window.CQC_LAYERS||LAYERS;
    for(const [k,arr] of [["cnty",LY.county],["ostan",LY.ostan]]) for(const f of (arr||[])) for(const poly of f.g) for(const ring of poly){ ring.forEach((q,i)=>i?P[k].lineTo(q[0],q[1]):P[k].moveTo(q[0],q[1])); if(k==="ostan") P.hasO=true; } }catch(e){ console.warn("nv layers",e); }
  try{ nvDedupe(P); }catch(e){ console.warn("nv dedupe",e); }
  return NV.paths=P;
}
function nvCities(){ if(NV.cities) return NV.cities; try{ NV.cities=SEATS.map(q=>({n:q[0],la:q[1],lo:q[2],cap:q[4]===1})); }catch(e){ NV.cities=[]; } return NV.cities; }

/* ---------- شمارهٔ کلاس برای بزرگ‌نمایی بدون رنگ واسطه ---------- */
function nvIndex(e){
  if(e.idx!==undefined && e.idx!==null) return e.idx; if(!e.img||!e.sc||e.sc.lab){ return e.idx=false; }
  try{ const c=document.createElement("canvas"); c.width=NV_TW; c.height=NV_TH; const x=c.getContext("2d",{willReadFrequently:true}); x.drawImage(e.img,0,0); const d=x.getImageData(0,0,NV_TW,NV_TH).data;
    const map=new Map(); e.sc.c.forEach((h,i)=>map.set((parseInt(h.slice(1,3),16)<<16)|(parseInt(h.slice(3,5),16)<<8)|parseInt(h.slice(5,7),16), i));
    const I=new Int16Array(NV_TW*NV_TH); let miss=0;
    for(let p=0,q=0;p<I.length;p++,q+=4){ const k=(d[q]<<16)|(d[q+1]<<8)|d[q+2]; const v=map.get(k); if(v===undefined){ I[p]=-1; miss++; } else I[p]=v; }
    e.idx = miss>I.length*0.6 ? false : I;                // اگر رنگ‌ها با مقیاس نمی‌خواند، درون‌یابی نمی‌شود
  }catch(err){ e.idx=false; } return e.idx; }
function nvPal32(sc){ if(sc.__p32) return sc.__p32; const a=new Uint32Array(sc.c.length); sc.c.forEach((h,i)=>{ a[i]=(255<<24)|(parseInt(h.slice(5,7),16)<<16)|(parseInt(h.slice(3,5),16)<<8)|parseInt(h.slice(1,3),16); }); return sc.__p32=a; }
function nvPaintTile(x, W, H, k, x0, y0, e, fast){
  const dx=(NV_BOX[0]-x0)*k, dy=(y0-NV_BOX[3])*k, dw=(NV_BOX[1]-NV_BOX[0])*k, dh=(NV_BOX[3]-NV_BOX[2])*k, f=k/NV_PXD;
  x.save(); x.fillStyle="#fff"; x.fillRect(0,0,W,H); x.imageSmoothingEnabled=false;
  const cbOn=nvCbCur(e.par,e)!=="def"&&nvCbIds(e.par).includes(nvCbCur(e.par,e)), I=((cbOn&&e.sc&&!e.sc.lab)||(!fast && f>1.25))?nvIndex(e):null;
  if(I && !e.sc.lab){
    const ax=Math.max(0,Math.floor(dx)), ay=Math.max(0,Math.floor(dy)), bx=Math.min(W,Math.ceil(dx+dw)), by=Math.min(H,Math.ceil(dy+dh)), w=bx-ax, h=by-ay;
    if(w>0&&h>0){ const out=new ImageData(w,h), o32=new Uint32Array(out.data.buffer), pal=nvPal32(nvEffScale(e)), n=pal.length, W0=NV_TW, H0=NV_TH, WHITE=0xFFFFFFFF;
      for(let py=0;py<h;py++){ const v=(ay+py+0.5-dy)/f-0.5, j0=Math.max(0,Math.min(H0-1,Math.floor(v))), j1=Math.min(H0-1,j0+1), fy=Math.max(0,Math.min(1,v-j0)), r0=j0*W0, r1=j1*W0;
        for(let px=0;px<w;px++){ const u=(ax+px+0.5-dx)/f-0.5, i0=Math.max(0,Math.min(W0-1,Math.floor(u))), i1=Math.min(W0-1,i0+1), fx=Math.max(0,Math.min(1,u-i0));
          const a=I[r0+i0], b=I[r0+i1], c=I[r1+i0], d=I[r1+i1]; let val;
          if(a===b&&b===c&&c===d) val=a;
          else if(a<0||b<0||c<0||d<0){ const q=I[(fy>0.5?r1:r0)+(fx>0.5?i1:i0)]; val=q; }
          else val=Math.round((a*(1-fx)+b*fx)*(1-fy)+(c*(1-fx)+d*fx)*fy);
          o32[py*w+px]= val>=0&&val<n ? pal[val] : WHITE; } }
      x.putImageData(out,ax,ay); }
  } else if(e.img) x.drawImage(e.img,0,0,NV_TW,NV_TH,dx,dy,dw,dh);
  if(e.lay){ x.imageSmoothingEnabled=true; x.imageSmoothingQuality="high"; x.drawImage(e.lay,0,0,NV_TW,NV_TH,dx,dy,dw,dh); }
  x.restore();
}
function nvPaintVec(x, W, H, k, x0, y0, S, scale){
  const P=nvPaths(), kc=k/scale, w=px=>px*scale*(+S.lw||1)/k, ts=scale*(+S.fs||1);                       // kc: پیکسل CSS در هر درجه
  x.save(); x.setTransform(k,0,0,-k,-x0*k,y0*k); x.lineJoin="round"; x.lineCap="round";
  if(!GEO.tried) geoLoad(); try{ geoLines(x,S,kc,w); }catch(e){ console.warn("geo",e); }
  if(S.cnty && kc>=26){ x.strokeStyle="rgba(60,60,60,.40)"; x.lineWidth=w(0.7); x.stroke(P.cnty2||P.cnty); }
  if(S.brd&&!S.bc){ x.strokeStyle="rgba(40,40,40,.80)"; x.lineWidth=w(kc>=26?1.3:0.9); x.stroke(P.hasO?(P.ostanIn||P.ostan):P.prov); }
  if(S.brd){ x.strokeStyle="#111"; x.lineWidth=w(1.2); x.stroke(P.coast2||P.coast); x.lineWidth=w(1.7); { let gb=false; try{ gb=geoBorders(x,kc,w); }catch(e){} if(!gb) x.stroke(P.ctry2||P.ctry); } if(P.outer){ x.lineWidth=w(1.7); x.stroke(P.outer); } }
  if(S.reg && S.reg.indexOf("p:")===0){ try{ const f=(window.CQC_LAYERS||LAYERS).ostan.find(q=>"p:"+q.p.name===S.reg); if(f){ x.strokeStyle="#c1121f"; x.lineWidth=w(2.6); const pp=new Path2D(); for(const poly of f.g) for(const ring of poly) ring.forEach((q,i)=>i?pp.lineTo(q[0],q[1]):pp.moveTo(q[0],q[1])); x.stroke(pp); } }catch(e){} }
  x.restore();
  if(S.brd && kc>=11 && kc<=160){   // نام دریاها
    x.save(); x.textAlign="center"; x.textBaseline="middle"; x.direction="rtl"; x.font=`700 ${(kc<40?13:15)*ts}px ${FT.body}`; x.lineWidth=3*scale; x.lineJoin="round";
    for(const [n,lo,la] of [["خلیج فارس",51.6,27.2],["دریای کاسپین",51.0,40.2],["دریای عمان",58.6,24.9]]){ const X=(lo-x0)*k, Y=(y0-la)*k; if(X<0||Y<0||X>W||Y>H) continue;
      x.strokeStyle="rgba(255,255,255,.9)"; x.strokeText(n,X,Y); x.fillStyle="#1d4f80"; x.fillText(n,X,Y); }
    x.restore(); }
  let geoDone=false; try{ geoDone=geoLabels(x,W,H,k,x0,y0,S,ts,kc); }catch(e){ console.warn("geoL",e); }
  if(!geoDone && S.city && kc>=24){
    x.save(); x.textAlign="center"; x.textBaseline="bottom"; x.direction=(typeof LANG!=="undefined"&&LANG==="en")?"ltr":"rtl"; const fs=(kc>=70?12:11)*ts; let n=0;
    for(const c of nvCities()){ if(kc<70 && !c.cap) continue; const X=(c.lo-x0)*k, Y=(y0-c.la)*k; if(X<-20||Y<-20||X>W+20||Y>H+20) continue; if(++n>140) break;
      x.fillStyle="#111"; x.beginPath(); x.arc(X,Y,2.2*scale,0,6.2832); x.fill(); const cn=geoLabel(c.n); x.font=`600 ${fs}px ${FT.body}`; x.lineWidth=3*scale; x.strokeStyle="rgba(255,255,255,.85)"; x.strokeText(cn,X,Y-3*scale); x.fillStyle="#111"; x.fillText(cn,X,Y-3*scale); }
    x.restore(); }
}
function nvDraw(fast){
  const cv=$("nvCv"); if(!cv||!NV.view||!cv.width) return; const x=cv.getContext("2d"), v=NV.view, k=v.k*NV.d;
  const e=NV.entry; if(e&&e.img) nvPaintTile(x,cv.width,cv.height,k,v.x0,v.y0,e,!!fast); else { x.fillStyle="#fff"; x.fillRect(0,0,cv.width,cv.height); }
  nvPaintVec(x,cv.width,cv.height,k,v.x0,v.y0,Object.assign({},NV.s),NV.d*(NV.z||1));
  if(typeof NVF!=="undefined"&&NVF&&NVF.on) NVF.redraw();
}
function nvSharpLater(){ clearTimeout(NV.sharp); NV.sharp=setTimeout(()=>nvDraw(false),140); }

/* ---------- نوار رنگ ---------- */
function nvLegendDraw(c, W, sc, unit, q){
  const x=c.getContext("2d"), n=sc.c.length, H=c.height, s=q||Math.max(1,W/760), bar=Math.round(26*s), top=Math.round(6*s);
  x.fillStyle="#fff"; x.fillRect(0,0,W,H); const bx0=Math.round(8*s), bw=W-bx0*2;
  for(let j=0;j<n;j++){ const a=Math.round(bx0+bw*j/n), b=Math.round(bx0+bw*(j+1)/n); x.fillStyle=sc.c[j]; x.fillRect(a,top,b-a,bar); }
  x.strokeStyle="#000"; x.lineWidth=Math.max(1,s); x.strokeRect(bx0,top,bw,bar);
  x.fillStyle="#111"; x.font=`600 ${Math.round(15*s)}px sans-serif`; x.textAlign="center"; x.textBaseline="top"; x.direction="ltr"; let lastR=-1e9;
  const fmt=v=>Math.abs(v-Math.round(v))<1e-9?String(Math.round(v)):(+v.toFixed(2)).toString();
  for(let j=0;j<n;j++){ let lab=null, cx;
    if(sc.lab){ lab=sc.lab[j]; cx=bx0+bw*(j+0.5)/n; x.font=`600 ${Math.round(11*s)}px sans-serif`; }
    else if(j>=1 && sc.e[j]!=null){ lab=fmt(sc.e[j]); cx=bx0+bw*j/n; }
    if(lab==null) continue; const w=x.measureText(lab).width; if(cx-w/2<lastR+3*s) continue; x.fillText(lab,cx,top+bar+3*s); lastR=cx+w/2; if(sc.lab) x.font=`600 ${Math.round(15*s)}px sans-serif`; }
  if(unit){ x.textAlign="right"; x.font=`700 ${Math.round(15*s)}px sans-serif`; x.fillStyle="#222"; x.fillText(unit,W-bx0,top+bar+Math.round(24*s)); }
}
function nvLegend(){ const c=$("nvLg"), e=NV.entry; if(!c) return; const w=Math.max(300,Math.round($("nvStage").getBoundingClientRect().width*(NV.d||1))); c.width=w; c.height=Math.round((NV.d||1)*70); c.style.height=(c.height/(NV.d||1))+"px";
  if(e&&e.sc) nvLegendDraw(c,w,nvEffScale(e),e.par&&(e.par.mu||e.par.unit),(NV.d||1)*(NV.z||1)); else c.getContext("2d").clearRect(0,0,w,c.height); }

/* ---------- خروجی PNG و ارسال به تحلیل ---------- */
/* پرچم کشور سازندهٔ مدل (رسم برداری ساده؛ کنار لوگوی MetStat در نوار پایین) */
const NV_FLAG={ecmwf:"eu",ecmwf9:"eu",ecmwfs:"eu",ecmwfseas:"eu",ecmwfseass:"eu",gfs:"us",gfs25:"us",nmme:"us",nmmes:"us",nasa:"us",nasas:"us",cfsvtwo:"us",cfsvtwos:"us",icon:"de",ukmo:"gb",gem:"ca",gemnemo:"ca",cancm:"ca",arpege:"fr",access:"au"};
function nvFlagCode(m){ m=String(m||""); return NV_FLAG[m]||NV_FLAG[m.replace(/s$/,"")]||null; }
function nvFlag(x,code,X,Y,w,h){
  if(!code) return false; x.save(); x.beginPath(); x.rect(X,Y,w,h); x.clip();
  const R=(c,a,b,cw,ch)=>{ x.fillStyle=c; x.fillRect(X+a*w,Y+b*h,cw*w,ch*h); };
  const star=(cx,cy,r,c,n)=>{ n=n||5; x.fillStyle=c; x.beginPath(); for(let i=0;i<n*2;i++){ const a=-Math.PI/2+i*Math.PI/n, rr=i%2?r*0.42:r; x[i?"lineTo":"moveTo"](cx+rr*Math.cos(a),cy+rr*Math.sin(a)); } x.closePath(); x.fill(); };
  const jack=(a,b,cw,ch)=>{ x.save(); x.beginPath(); x.rect(X+a*w,Y+b*h,cw*w,ch*h); x.clip(); R("#012169",a,b,cw,ch); const x0=X+a*w,y0=Y+b*h,W2=cw*w,H2=ch*h;
    x.lineCap="butt"; x.strokeStyle="#fff"; x.lineWidth=H2*0.2; x.beginPath(); x.moveTo(x0,y0); x.lineTo(x0+W2,y0+H2); x.moveTo(x0+W2,y0); x.lineTo(x0,y0+H2); x.stroke();
    x.strokeStyle="#C8102E"; x.lineWidth=H2*0.07; x.stroke();
    x.fillStyle="#fff"; x.fillRect(x0+W2*0.4,y0,W2*0.2,H2); x.fillRect(x0,y0+H2*0.38,W2,H2*0.24); x.fillStyle="#C8102E"; x.fillRect(x0+W2*0.44,y0,W2*0.12,H2); x.fillRect(x0,y0+H2*0.43,W2,H2*0.14); x.restore(); };
  if(code==="us"){ for(let i=0;i<13;i++) R(i%2?"#fff":"#B22234",0,i/13,1,1/13+0.003); R("#3C3B6E",0,0,0.4,7/13);
    for(let r=0;r<4;r++) for(let c=0;c<5;c++){ x.fillStyle="#fff"; x.beginPath(); x.arc(X+(0.04+c*0.075)*w,Y+(0.06+r*0.1)*h+0.0,h*0.028,0,6.2832); x.fill(); } }
  else if(code==="de"){ R("#000",0,0,1,1/3); R("#DD0000",0,1/3,1,1/3+0.003); R("#FFCE00",0,2/3,1,1/3); }
  else if(code==="fr"){ R("#0055A4",0,0,1/3,1); R("#fff",1/3,0,1/3+0.003,1); R("#EF4135",2/3,0,1/3,1); }
  else if(code==="gb"){ jack(0,0,1,1); }
  else if(code==="ca"){ R("#D80621",0,0,0.25,1); R("#fff",0.25,0,0.5,1); R("#D80621",0.75,0,0.25,1);
    const cx=X+w/2, cy=Y+h*0.52, u=h*0.0105, P=[[0,-46],[6,-30],[17,-34],[13,-12],[26,-18],[24,-6],[34,-2],[18,16],[20,22],[3,20],[3,40],[-3,40],[-3,20],[-20,22],[-18,16],[-34,-2],[-24,-6],[-26,-18],[-13,-12],[-17,-34],[-6,-30]];
    x.fillStyle="#D80621"; x.beginPath(); P.forEach((q,i)=>x[i?"lineTo":"moveTo"](cx+q[0]*u,cy+q[1]*u)); x.closePath(); x.fill(); }
  else if(code==="au"){ R("#012169",0,0,1,1); jack(0,0,0.5,0.5); star(X+w*0.25,Y+h*0.76,h*0.17,"#fff",7); star(X+w*0.75,Y+h*0.22,h*0.07,"#fff"); star(X+w*0.62,Y+h*0.45,h*0.07,"#fff"); star(X+w*0.86,Y+h*0.4,h*0.07,"#fff"); star(X+w*0.75,Y+h*0.82,h*0.07,"#fff"); }
  else if(code==="eu"){ R("#003399",0,0,1,1); for(let i=0;i<12;i++){ const a=i*Math.PI/6; star(X+w/2+Math.cos(a)*h*0.33,Y+h/2+Math.sin(a)*h*0.33,h*0.065,"#FFCC00"); } }
  x.restore(); x.strokeStyle="rgba(0,0,0,.55)"; x.lineWidth=Math.max(1.5,h*0.02); x.strokeRect(X,Y,w,h); return true; }
function nvCanvas(e0,W0){
  const e=e0||NV.entry; if(!e||!e.img){ return null; } const W=W0||1800, XV=nvExpView(), mapH=Math.round(W*XV.R), hd=210, lg=Math.round(W/760*108), ft=150, c=document.createElement("canvas"); c.width=W; c.height=hd+mapH+lg+ft;
  const x=c.getContext("2d"); x.fillStyle="#fff"; x.fillRect(0,0,c.width,c.height);
  const sub=document.createElement("canvas"); sub.width=W; sub.height=mapH; const k=W/XV.L;
  nvPaintTile(sub.getContext("2d"),W,mapH,k,XV.x0,XV.y0,e,false); nvPaintVec(sub.getContext("2d"),W,mapH,k,XV.x0,XV.y0,Object.assign({},NV.s),W/XV.ref);
  try{ if(typeof NVF!=="undefined"&&NVF&&NVF.on) nvfPaintExport(sub.getContext("2d"),W,mapH,k,XV.x0,XV.y0,W/XV.ref); }catch(e){ console.warn("nvf export",e); }
  x.drawImage(sub,0,hd); x.strokeStyle="#000"; x.lineWidth=2; x.strokeRect(1,hd,W-2,mapH);
  const M=ON.man.models[NV.s.m], reg=nvRegions().find(r=>r[0]===NV.s.reg);
  txt(x, e.par.fa, W-28, 92, `78px ${FT.titr}`, {maxW:W-56});
  txt(x, `${M.name||M.fa} · ${onFmtRun(nvRunSel(NV.s.m))} · ${nvIsLong()?"ماه پیش‌بینی: "+nvMonthLab(e.item.v):"اعتبار: "+onFmtValid(e.item.v)+" · "+FA(e.item.s)+" ساعت"} · ${reg?reg[1]:""}`, W-28, 172, `46px ${FT.body}`, {color:"#111", maxW:W-56});
  const l=document.createElement("canvas"); l.width=W; l.height=lg; nvLegendDraw(l,W,nvEffScale(e),e.par.mu||e.par.unit,W/760*1.5); x.drawImage(l,0,hd+mapH);
  const fy=hd+mapH+lg, flg=nvFlagCode(NV.s.m), fh=ft-34, fw=Math.round(fh*1.5); let bx=20;
  if(flg && nvFlag(x,flg,20,fy+17,fw,fh)) bx=20+fw+26;
  txt(x, `داده: ${(M.info&&M.info.prov)||M.name} · Open-Meteo.com (CC BY 4.0)`, W-28, fy+62, `40px ${FT.body}`, {color:"#222"});
  txt(x, `MetStat — wtafkik.ir`, W-28, fy+118, `bold 44px ${FT.body}`, {color:"#0a3d8f", dir:"ltr"});
  try{ drawBrand(x,{brand:$("brand")?$("brand").value.trim():"",handle:$("handle")?$("handle").value.trim():"",logoImg:state.logoImg},bx,fy+8,Math.round(W*0.4),ft-16,{side:true,align:"left",fs:36}); }catch(err){}
  return c;
}
function nvPngW(){ const sel=$("nvPw"); if(!sel) return 1800; let w=sel.value==="custom"?+($("nvPwC")||{}).value||2500:+sel.value||1800; w=Math.max(600,Math.min(8000,Math.round(w)));
  const hFor=x=>Math.round(x*nvExpView().R)+210+Math.round(x/760*108)+150; while(w>900 && w*hFor(w)>120e6) w-=200;       // سقف حافظهٔ canvas مرورگر
  return w; }
function nvExport(){ const c=nvCanvas(null,nvPngW()), e=NV.entry; if(!c) return; c.toBlob(b=>onSave(b,`metstat_${NV.s.m}_${nvPid()}_${e.item.v}_${NV.s.reg.replace(/[^a-z]/g,"")||"reg"}.png`)); }
async function nvToAnalysis(){
  const e=NV.entry; if(!e) return; const P0=nvPar(NV.s.p);
  const it=nvItemsSrc(NV.s.m).filter(i=>i.r==="iran"&&i.m===NV.s.m&&i.p===(P0&&P0.id)&&i.v===e.item.v);
  let files;
  if(it.length) files=await onFiles(it);
  else { const c=nvCanvas(); if(!c) throw new Error("نقشه هنوز بارگذاری نشده است");          // ماهانه/فصلی: نسخهٔ ۷۶۰ ایران نداریم → همین نقشهٔ نمایش‌داده‌شده (با تیتر و لجند) ارسال می‌شود
    const b=await new Promise(r=>c.toBlob(r,"image/png")); files=[new File([b],`metstat_${NV.s.m}_${nvPid()}_${e.item.v}.png`,{type:"image/png"})]; } onStatus("ارسال به صفحهٔ تحلیل…",0.6); await switchMode("wu"); try{ CLEAR.main(); }catch(err){} await addFiles(files);
}
function nvLeave(){ try{ if(NVF.on) nvfExit(); }catch(e){} if(NV.anim){ clearInterval(NV.anim); NV.anim=null; } try{ nvCompClear(); }catch(e){} }

/* ===================== نقشه‌های ترکیبی خودکار (همرفت، هشدار) ===================== */
const NC_PROD=[{id:"conv",fa:"همرفت: احتمال وقوع و شدت بالقوهٔ توفان تندری، تگرگ و ...",op:"conv"},{id:"warn",fa:"هشدارهای جوی خودکار (بارش، باد، دما، برف، رعدوبرق و ...)",op:"warn"}];
const NCP={tok:0,res:null};
function nvCompHTML(){
  return `<section class="card" id="ncBox"><h3>نقشه‌های ترکیبی خودکار</h3>
    <label>محصول <select id="ncP">${NC_PROD.map(p=>`<option value="${p.id}">${p.fa}</option>`).join("")}</select></label>
    <label>مدل <select id="ncM"></select></label>
    <label>زمان معتبر <select id="ncV"></select></label>
    <div class="hint" id="ncPs"></div><div class="hint" id="ncDg"></div>
    <p class="hint">با هر تغییر منو، نقشه همان لحظه از ترکیب پارامترهای موجود با همان منطق و رنگ صفحه‌های همرفت و هشدار ساخته و در کادر زیر همین بخش نشان داده می‌شود. با بستن صفحه یا تازه‌سازی، این نقشه‌ها پاک می‌شوند.</p></section>`;
}
function ncOp(){ return ON_OPS.find(o=>o.id===$("ncP").value); }
function ncInit(){
  if(!$("ncP")) return;
  $("ncP").onchange=()=>ncFillM(true); $("ncM").onchange=()=>ncFillV(true); $("ncV").onchange=()=>ncFillInfo(true); ncFillM(false);
}
function ncFillM(u){
  const op=ncOp(), its=(ON.man?ON.man.items:[]).filter(i=>i.r==="iran"&&op.ps.includes(i.p)), ms=[...new Set(its.map(i=>i.m))].filter(m=>new Set(its.filter(i=>i.m===m).map(i=>i.p)).size>=op.min);
  nvFill("ncM",ms.length?ms.map(m=>[m,onModelFa(m)]):[["","— مدلی با پارامتر کافی نیست —",true]]);
  try{ const all=[...new Set((ON.man?ON.man.items:[]).filter(i=>i.r==="iran").map(i=>i.m))], miss=all.filter(m=>!ms.includes(m)).map(m=>`${onModelFa(m)} (${FA(new Set(its.filter(i=>i.m===m).map(i=>i.p)).size)} از ${FA(op.min)} پارامتر)`);
    const dg=$("ncDg"); if(dg) dg.textContent=miss.length?"مدل‌های بدون پارامتر کافی در فهرست هاست برای این محصول: "+miss.join("، "):""; }catch(e){}
  ncFillV(u);
}
function ncFillV(u){
  const op=ncOp(), m=$("ncM").value, vs=[...new Set((ON.man?ON.man.items:[]).filter(i=>i.r==="iran"&&i.m===m&&op.ps.includes(i.p)&&!/^(p24|pacc|snow24|snowacc)$/.test(i.p)).map(i=>i.v))].sort();
  $("ncV").innerHTML=vs.map(v=>`<option value="${v}">${onFmtValid(v)}</option>`).join("")||`<option value="">—</option>`; ncFillInfo(u);
}
function ncPick(op,m,v){ const it=(ON.man?ON.man.items:[]).filter(i=>i.r==="iran"&&i.m===m&&op.ps.includes(i.p)), out=[];
  for(const p of op.ps){ const c=it.filter(i=>i.p===p); if(!c.length) continue; let x=c.find(i=>i.v===v); if(!x&&/^(p24|snow24)$/.test(p)) x=c.filter(i=>i.v>=v).sort((a,b)=>a.v.localeCompare(b.v))[0]; if(x) out.push(x); } return out; }
function ncFillInfo(u){ const op=ncOp(), fs=ncPick(op,$("ncM").value,$("ncV").value); $("ncPs").textContent="پارامترهای موجود: "+(fs.map(i=>onPar(i.p).fa).join("، ")||"—")+(anActive()?` — بازهٔ زمانی فعال است: همهٔ زمان‌های بازه (${FA(onRangeSets(op,$("ncM").value,"iran",ncPick).vs.length)} زمان) ترکیب می‌شوند و «زمان معتبر» نادیده گرفته می‌شود`:"");
  try{ anRangeRefresh(); }catch(e){} clearTimeout(NCP.t); if(u) NCP.t=setTimeout(()=>nvCompBuild().catch(e=>{ console.error(e); ncMsg("⚠ "+e.message); }),500); }
function ncMsg(t){ const b=$("onComp"); if(!b) return; b.hidden=!t; if(t) b.innerHTML=`<article class="card wide"><div class="hint">${t}</div></article>`; }
function nvCompClear(){ NCP.tok++; NCP.res=null; const b=$("onComp"); if(b){ b.innerHTML=""; b.hidden=true; } try{ CLEAR.cv(); }catch(e){} try{ CLEAR.wn(); }catch(e){} }
const ncWait=(fn,ms)=>new Promise((ok,bad)=>{ const t0=Date.now(); const t=setInterval(()=>{ const r=fn(); if(r){ clearInterval(t); ok(r); } else if(Date.now()-t0>ms){ clearInterval(t); bad(new Error("ساخت نقشهٔ ترکیبی زمان زیادی برد")); } },300); });
async function nvCompBuild(){
  const op=ncOp(), m=$("ncM").value, v=$("ncV").value, manIdx=anManualFiles("idx"), manCmp=anManualFiles("cmp");
  if(!op||((!m||!v)&&!manIdx.length)){ ncMsg(""); return; }
  const ranged=anActive(); let vs=[v], items=[];
  if(m&&v){ if(ranged){ const rs=onRangeSets(op,m,"iran",ncPick); vs=rs.vs; items=rs.items; if(!vs.length&&!manIdx.length){ ncMsg("در بازهٔ انتخاب‌شده برای این مدل نقشه‌ای در هاست نیست؛ بازه را باز کنید."); return; } } else items=ncPick(op,m,v); } else vs=[];
  const tok=++NCP.tok; if(items.length+manIdx.length<op.min){ ncMsg("پارامتر کافی برای این ترکیب نیست"+(manIdx.length?"":"؛ می‌توانید نقشهٔ دستی هم اضافه کنید")); return; }
  ncMsg(`<span class="spn"></span> در حال ساخت نقشهٔ ترکیبی…`);
  const files=[...(items.length?await onFiles(items):[]), ...manIdx]; if(tok!==NCP.tok) return;
  const isCv=op.kind==="conv", box=$(isCv?"cvCards":"wnCards");
  try{ CLEAR[isCv?"cv":"wn"](); }catch(e){}
  if(isCv){ await cvAdd(files);
    const cmp=m?onCmpItems(m, vs):[], cf=[...(cmp.length?await onFiles(cmp):[]), ...manCmp];
    if(cf.length){ await cvAdd(cf,"cmp"); } try{ cvThrPanel(); }catch(e){} }
  else await wnAdd(files);
  if(tok!==NCP.tok) return;
  const st=isCv?cv:wn;
  const got=await ncWait(()=>{ if(tok!==NCP.tok) return true; if(!st.res||st.busy) return null; const cs=[...box.querySelectorAll("article.card")].filter(c=>c.querySelector("img")); return cs.length&&cs.every(c=>{ const i=c.querySelector("img"); return i.complete&&i.naturalWidth; })?cs:null; },150000);
  if(tok!==NCP.tok||got===true) return;
  const out=$("onComp"); out.hidden=false; out.innerHTML=`<article class="card wide ncOut"><header><h3>${op.fa}</h3><div class="sub">${m?onModelFa(m):"نقشه‌های دستی"}${manIdx.length+manCmp.length?` (+${FA(manIdx.length+manCmp.length)} دستی)`:""} · ${!vs.length?"":ranged?`بازه: ${onFmtValid(vs[0])}${vs.length>1?" تا "+onFmtValid(vs[vs.length-1])+` (${FA(vs.length)} زمان)`:""}`:onFmtValid(v)}</div></header><div class="ncTabs" id="ncTabs"></div><div id="ncFrame"></div></article>`;
  const tabs=$("ncTabs"), frame=$("ncFrame"), cards=got.map(c=>{ const h=c.querySelector("h3"), im=c.querySelector("img"); return {t:h?h.textContent:"نقشه", sub:(c.querySelector(".sub")||{}).textContent||"", src:im.src, w:im.naturalWidth}; });
  NCP.res=cards; const show=k=>{ const c=cards[k]; [...tabs.children].forEach((b,i)=>b.classList.toggle("on",i===k)); frame.innerHTML=`<div class="sub">${c.sub}</div><img alt="" style="width:100%;height:auto;display:block;cursor:zoom-in">`; const im=frame.querySelector("img"); im.src=c.src; im.onclick=()=>{ const d=$("zoom"); d.querySelector("img").src=im.src; d.showModal(); }; try{ mfPngBtn(frame,()=>mfSaveImg(im,"metstat_combined.png")); }catch(e){} };
  cards.forEach((c,k)=>{ const b=document.createElement("button"); b.className="btn sm"; b.type="button"; b.textContent=c.t; b.onclick=()=>show(k); tabs.append(b); }); show(0);
  onStatus("",1); try{ CLEAR[isCv?"cv":"wn"](); }catch(e){}        // نتیجه در کادر همین صفحه است؛ حافظهٔ صفحهٔ اصلی آزاد می‌شود
}


/* ===================== نمودار شاخص‌های اقلیمی (ENSO، QBO، NAO، DMI ...) ===================== */
const NI={idx:null,tok:0};
function nvIdxHTML(){
  return `<section class="card" id="niBox"><h3>شاخص‌های اقلیمی (ENSO، QBO، NAO، IOD و ...)</h3>
    <label>گروه <select id="niG"></select></label>
    <label>شاخص <select id="niI"></select></label>
    <label>دورهٔ نمودار <select id="niP"></select></label>
    <div class="hint" id="niInfo">در حال دریافت فهرست شاخص‌ها…</div>
    <p class="hint">فقط تصویر نمودار نشان داده می‌شود؛ داده‌های عددی منتشر نمی‌شود. به‌روزرسانی خودکار با برنامهٔ indices.py در GitHub Actions انجام می‌شود.</p></section>`;
}
async function niInit(){
  if(!$("niG")) return; const info=$("niInfo");
  try{ const r=await fetch(ON.base+"data/idx/index.json?"+Date.now(),{cache:"no-store"}); if(!r.ok) throw 0; NI.idx=await r.json(); }catch(e){ NI.idx=null; }
  const it=NI.idx&&NI.idx.items||{}, ids=Object.keys(it);
  if(!ids.length){ nvFill("niG",[["","—",true]]); nvFill("niI",[["","—",true]]); nvFill("niP",[["","—",true]]); info.textContent="هنوز نمودار شاخصی روی هاست نیست (workflow «metstat-indices» را اجرا کنید)."; return; }
  const gs=[...new Set(ids.map(i=>it[i].grp))]; nvFill("niG",gs.map(g=>[g,g]));
  $("niG").onchange=()=>niFillI(); $("niI").onchange=()=>niFillP(); $("niP").onchange=()=>niShow(); niFillI();
}
function niFillI(){ const it=NI.idx.items; nvFill("niI",Object.keys(it).filter(i=>it[i].grp===$("niG").value).map(i=>[i,it[i].fa])); niFillP(); }
function niFillP(){ const e=NI.idx.items[$("niI").value]||{per:{}}; nvFill("niP",Object.entries(e.per).map(([k,v])=>[k,v])); niShow(); }
function niShow(){
  const id=$("niI").value, per=$("niP").value, e=NI.idx.items[id], box=$("onIdx"); if(!e||!per){ if(box) box.hidden=true; return; }
  $("niInfo").textContent=`${e.en} · منبع: ${e.src} · آخرین ماه داده: ${e.last} · به‌روزرسانی: ${e.upd}`+(NI.idx.updated?` · آخرین اجرا: ${NI.idx.updated.slice(0,16).replace("T"," ")} UTC`:"");
  box.hidden=false; box.innerHTML=`<article class="card wide"><header><h3>${e.fa}</h3><div class="sub">${e.grp} · ${e.per[per]}</div></header><img alt="${e.en}" style="width:100%;height:auto;display:block;cursor:zoom-in"></article>`;
  const im=box.querySelector("img"); im.src=ON.base+`data/idx/${id}_${per}.png?`+(NI.idx.updated||""); im.onclick=()=>{ const d=$("zoom"); d.querySelector("img").src=im.src; d.showModal(); };
}


/* =====================================================================
   رابط سبک weather.us برای تحلیل آنلاین: بخش‌های جمع‌شونده («تغییر نقشه / پارامتر / مدل و ران / تاریخ»)،
   دکمه‌های چیپ برای مدل، ران، ساعت پیش‌بینی و نوار مدل‌ها زیر نقشه. منوهای قدیمی (select) حالت‌نگه‌دار
   باقی می‌مانند و همهٔ منطق قبلی دست‌نخورده است؛ چیپ‌ها فقط مقدار select را عوض و رویداد را صدا می‌زنند.
   ===================================================================== */
const NVW={open:{reg:false,lay:true,par:false,mod:false,cb:false,time:!(window.matchMedia&&matchMedia("(max-width:700px)").matches)}, ptab:"used", ivl:0};
const NV_SEC_GROUPS=[["احتمال همرفت",["cvp","cvi","hail","ltg"]],["پتانسیل سیل",["flood"]],["هشدارهای بارش",["wrainl","wrain","wsnow","wice"]],["هشدارهای دما، شرجی و سوزباد",["wfrost","wgfrost","wcold","wheat","whum"]],["هشدارهای باد",["wwind"]],["هشدار سیل و آبگرفتگی",["wflood","wlog"]],["هشدار رعدوبرق و تگرگ",["wtstm","whail","wltg"]],["هشدار گردوخاک، دید افقی و مه",["wdust","wfog"]],["هشدار ترکیبی",["warn"]]];
const NVW_USED=["cvp6","hail6","flood24","warn24","ltg6","p24","p6","p3","p1","pt","t2m","t2","tmax","tmin","z500","w10","gust","mslp","snow","tot","sigw","cape"];
const wxFA=n=>{ try{ return FA(n); }catch(e){ return String(n); } };
NVW.cg={};   // آکاردئون گروه‌های پارامتر: برای هر زبانه فقط یک گروه باز است؛ پیش‌فرض گروهِ پارامتر فعلی
function wxGrp(tab,key,title,L){ const cur=L.some(p=>NV.s.p===p.id), st=NVW.cg[tab], open=st===undefined?cur:st===key;
  return `<button type="button" class="wxCat wxCatB${open?" on":""}" data-cg="${tab}|${key}" aria-expanded="${open}"><span>${title}</span><svg class="wxCh" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg></button>${open?`<div class="wxRow">${L.map(p=>wxChip(p.fa,NV.s.p===p.id,`data-p="${p.id}" data-c="${p.cat}"`)).join("")}</div>`:""}`; }
function wxChip(label,on,attr,dis){ return `<button type="button" class="wxChip${on?" on":""}"${dis?" disabled":""} ${attr}>${label}</button>`; }
function wxSec(key,title,body){ const o=NVW.open[key]; return `<div class="wxSec"><button type="button" class="wxHd${o?" on":""}" data-tg="${key}">${o?"▾ پنهان کردن":"▸ تغییر"} ${title}</button>${o?`<div class="wxBody">${body}</div>`:""}</div>`; }
function wxMirror(id){ const s=$(id); return `<select class="wxSel" data-mirror="${id}">${s.innerHTML}</select>`; }
function wxModelChips(){ const ms=nvModelsOf(NV.s.tc); return ms.map(([k,o])=>wxChip(nvLabU(k,o,ms.map(q=>q[0])),k===NV.s.m,`data-m="${k}"`)).join("")||'<span class="hint">مدلی موجود نیست</span>'; }
function nvWx(){
  const box=$("nvWx"); if(!box||!ON.man) return;
  const tools=`<div class="wxTools"><button type="button" class="wxTb" data-act="reload" title="به‌روزرسانی فهرست">↻</button><button type="button" class="wxTb" data-act="home" title="بازگشت به منطقهٔ انتخابی">📍</button><button type="button" class="wxTb" data-act="zoom" title="بزرگ‌نمایی">🔍</button><button type="button" class="wxTb${NV.s.city?" on":""}" data-act="city" title="نام شهرها">${NV.s.city?"شهر":"<s>شهر</s>"}</button><button type="button" class="wxTb info" data-act="info" title="اطلاعات مدل">ℹ</button></div><div class="hint wxInfo" id="wxInfo" hidden></div>`;
  // منطقه
  const regs=nvRegions(); const quick=regs.slice(0,2);
  const lay=`<div class="hint">هر لایه را روشن/خاموش کنید؛ روی همهٔ نقشه‌ها اعمال می‌شود.</div><div class="wxRow">${[["brd","مرزها"],["cnty","مرز شهرستان‌ها"],["riv","رودها"],["road","جاده‌ها"],["lake","دریاچه‌ها"],["vill","روستاها و شهرها"]].map(([k,t])=>wxChip(t,!!NV.s[k],`data-tgl="${k}"`)).join("")}</div>`;
  const reg=`<div class="wxRow">${quick.map(r=>wxChip(r[1],NV.s.reg===r[0],`data-reg="${r[0]}"`)).join("")}</div><label class="wxLb">استان‌ها${wxMirror("nvReg")}</label>`;
  // پارامتر
  let par="";
  const cats=((ON.man.cats)||[]).slice().sort((a,b)=>a.o-b.o), ps=NV.s.m?nvParamsOf(NV.s.m):[];
  const tabs=[["used","پرکاربرد"],["all","همه"],["sec","نقشه‌های ثانویه"],["info","اطلاعات مدل"]].map(([k,t])=>wxChip(t,NVW.ptab===k,`data-ptab="${k}"`)).join("");
  if(NVW.ptab==="info") par=`<div class="hint">${$("nvInfo").textContent||"—"}</div>`;
  else if(NVW.ptab==="sec"){ const sp=ps.filter(p=>p.cat==="sc"), base=id=>id.replace(/(6|24|acc)$/,""), used=new Set();
    const html=NV_SEC_GROUPS.map(([t,ids])=>{ const L=sp.filter(p=>ids.includes(base(p.id))).sort((a,b)=>a.o-b.o); L.forEach(p=>used.add(p.id)); return L.length?wxGrp("sec",t,t,L):""; }).join("");
    const rest=sp.filter(p=>!used.has(p.id)); par=(html+(rest.length?wxGrp("sec","سایر","سایر",rest):""))||'<div class="hint">برای این مدل نقشهٔ ثانویه‌ای نیست (فقط ECMWF، GFS، ICON، UKMO و ARPEGE شاخص‌های همرفتی دارند).</div>';
    par='<div class="hint">این نقشه‌ها از ترکیب چند شاخص و نقشهٔ دیگر ساخته می‌شوند؛ پنجره: ۶ ساعته، ۲۴ ساعته یا تجمعی.</div>'+par; }
  else if(NVW.ptab==="all") par=cats.filter(c=>c.id!=="sc"&&ps.some(p=>p.cat===c.id)).map(c=>wxGrp("all",c.id,c.fa,ps.filter(p=>p.cat===c.id).sort((x,y)=>x.o-y.o))).join("");
  else { let u=ps.filter(p=>NVW_USED.includes(p.id)); if(!u.length) u=ps.slice(0,14); par=`<div class="hint">پارامترهایی که بیشتر استفاده می‌شوند؛ بقیه در زبانهٔ «همه».</div><div class="wxRow">${u.map(p=>wxChip(p.fa,NV.s.p===p.id,`data-p="${p.id}" data-c="${p.cat}"`)).join("")}</div>`; }
  par=`<div class="wxRow tabs">${tabs}</div>`+par;
  // مدل و ران
  const tcs=NV_TC.map(([k,t])=>wxChip(t.split(" ")[0],NV.s.tc===k,`data-tc="${k}"`,!nvModelsOf(k).length)).join("");
  const run=ON.man.models&&ON.man.models[NV.s.m];
  const mod=`<div class="wxRow tabs">${tcs}</div><div class="wxCat">مدل</div><div class="wxRow">${wxModelChips()}</div><div class="wxCat">اجرای مدل (Run)</div><div class="wxRow">${run?[[run.run,onFmtRun(run.run)+(run.status==="complete"?"":" (در حال ساخت)")],...(nvRunPrev(NV.s.m)?[[nvRunPrev(NV.s.m).run,onFmtRun(nvRunPrev(NV.s.m).run)+" (قبلی)"]]:[])].map(([r,t])=>wxChip(t,nvRunSel(NV.s.m)===r,`data-run="${r}"`)).join(""):"—"}</div>`;
  // زمان
  const it=NV.items||[], sv=it.map(i=>i.s).filter(x=>x>=0);
  const ivs=[0,1,3,6,12,24].filter(n=>n===0||sv.some(x=>x%n===0&&x>0)).map(n=>wxChip(n?`${wxFA(n)} ساعته`:"همه",NVW.ivl===n,`data-ivl="${n}"`)).join("");
  const fl=it.filter(i=>!NVW.ivl||i.s<0||i.s%NVW.ivl===0);
  const LONG=nvIsLong(), frs=fl.map(i=>wxChip(LONG?nvMonthLab(i.v):i.s>=0?"+"+wxFA(String(i.s).padStart(3,"0")):nvFrLab(i),i.v===NV.s.fr,`data-fr="${i.v}"`)).join("");
  const time=`${LONG?"":`<div class="wxCat">بازهٔ نمایش ساعت‌ها</div><div class="wxIvl">${ivs}</div>`}<div class="wxCat">${LONG?(nvSpan()>1?"بازهٔ ۳ ماهه":"ماه پیش‌بینی"):"ساعت پیش‌بینی"}</div><div class="wxRow fr wxGrid${LONG?" long":""}">${frs}</div><div class="wxCat">${LONG?"انتخاب ماه":"تاریخ و ساعت"}</div><div class="wxNav"><button type="button" class="wxArr" data-act="prev" aria-label="قبلی">◀</button>${wxMirror("nvFr")}<button type="button" class="wxArr" data-act="next" aria-label="بعدی">▶</button></div>`;
  box.innerHTML=wxSec("reg","منطقه جغرافیایی",reg)+wxSec("mod","مدل و ران",mod)+wxSec("par","پارامتر",par)+wxSec("cb","رنگ‌بندی (Colorbar)",nvCbBody())+wxSec("time",nvIsLong()?"ماه پیش‌بینی":"تاریخ و ساعت پیش‌بینی",time);
  box.querySelectorAll("select[data-mirror]").forEach(m=>{ m.value=$(m.dataset.mirror).value; });
  const bar=$("nvBar"); if(bar) bar.innerHTML=wxModelChips(); try{ nvTopSync(); }catch(e){} try{ nvXRender(); }catch(e){ console.warn("nvX",e); } try{ mcRender(); }catch(e){ console.warn("mc",e); } try{ NVF.sync(); }catch(e){}
}
function wxSet(id,v){ const s=$(id); if(!s) return; s.value=v; if(s.onchange) s.onchange(); }
function nvWxBind(){
  const box=$("nvWx"); if(!box||box.__bound) return; box.__bound=1;
  const bar=$("nvBar");
  const pickModel=k=>{ NV.s.m=k; $("nvM").value=k; nvFillRun(); };
  const click=e=>{ const b=e.target.closest("button"); if(!b||b.disabled) return; const d=b.dataset;
    if(d.tg){ NVW.open[d.tg]=!NVW.open[d.tg]; return nvWx(); }
    if(d.cg){ const [t,k]=d.cg.split("|"), was=b.getAttribute("aria-expanded")==="true"; NVW.cg[t]=was?"":k; return nvWx(); }
    if(d.reg){ wxSet("nvReg",d.reg); return; }
    if(d.tgl){ NV.s[d.tgl]=!NV.s[d.tgl]; const cb=$({brd:"nvBrd",cnty:"nvCnty",riv:"nvRiv",road:"nvRoad",lake:"nvLake",vill:"nvVill"}[d.tgl]); if(cb) cb.checked=!!NV.s[d.tgl]; nvSave(); nvDraw(); return nvWx(); }
    if(d.ptab){ NVW.ptab=d.ptab; return nvWx(); }
    if(d.run){ NV_RS[NV.s.m]=d.run; nvFillRun(); return nvWx(); }
    if(d.cb){ NV.s.cb=d.cb; nvSave(); nvLegend(); nvDraw(); return nvWx(); }
    if(d.p){ NV.s.cat=d.c; NV.s.p=d.p; nvFillCat(); return; }
    if(d.tc){ NV.s.tc=d.tc; $("nvTc").value=d.tc; nvFillModels(); return; }
    if(d.m){ pickModel(d.m); return; }
    if(d.ivl!==undefined){ NVW.ivl=+d.ivl; return nvWx(); }
    if(d.fr){ wxSet("nvFr",d.fr); return; }
    if(d.act==="prev") return $("nvPrev").click(); if(d.act==="next") return $("nvNext").click();
    if(d.act==="reload") return $("onReload").click(); if(d.act==="home") return $("nvZr").click(); if(d.act==="zoom") return nvZoom(1.5);
    if(d.act==="city"){ NV.s.city=!NV.s.city; $("nvCity").checked=NV.s.city; nvSave(); nvDraw(); return nvWx(); }
    if(d.act==="info"){ const i=$("wxInfo"); i.hidden=!i.hidden; i.textContent=$("nvInfo").textContent+" — "+($("nvRunInfo").textContent||""); } };
  box.addEventListener("click",click);
  box.addEventListener("change",e=>{ const m=e.target.dataset&&e.target.dataset.mirror; if(m) wxSet(m,e.target.value); });
  if(bar) bar.addEventListener("click",e=>{ const b=e.target.closest("button[data-m]"); if(b) pickModel(b.dataset.m); });
}


/* ===================== منوی رنگ‌بندی (Colorbar) — مرحلهٔ ۱-الف =====================
   کاشی‌های مدل «گسسته» هستند (هر پیکسل = شمارهٔ کلاس). برای تغییر رنگ‌بندی، شمارهٔ کلاس هر پیکسل (nvIndex) با پالت دیگری
   با همان تعداد کلاس رنگ می‌شود؛ مرز کلاس‌ها و عددهای نوار رنگ تغییر نمی‌کند. فهرست رنگ‌بندی‌ها بر حسب نوع پارامتر عوض می‌شود. */
const NV_CB_DEF="پیش‌فرض (رنگ‌بندی اصلی نقشه)";
/* رنگ‌بندی‌ها دقیقاً همان کتابخانهٔ رنگ‌بندی‌های ابزار نقشه‌اند (MT_PAL_LIB در 29_map_tools.js): weather.us، WeatherBELL، weathermodels، NOAA، tropicaltidbits، Windy و ... — هیچ رنگ‌بندی ساختگی‌ای اینجا نیست.
   رنگ هر کلاس نقشه از روی «مقدارش» در رنگ‌بندی انتخابی برداشته می‌شود (همان روش ابزار نقشه). */
function nvKind(par){ const id=String(par&&par.id||""); const f=String(par&&par.fa||"");
  if(/^(t2|tmax|tmin|tanom|tsoil|t8|t5|td|dew|thw|ts)/i.test(id)||/دما|یخبندان/.test(f)) return "temp";
  if(/^(p\d|pacc|pt|tot|pr)/i.test(id)||/بارش|احتمال بارش/.test(f)) return "precip";
  if(/snow|^sn/i.test(id)||/برف/.test(f)) return "snow";
  if(/^(w\d|w10|gust)/i.test(id)||/باد|تندباد/.test(f)) return "wind";
  return "other"; }
function nvLibKey(par){ const id=String(par&&par.id||"").toLowerCase(), k=nvKind(par);
  if(k==="precip") return "precip"; if(k==="snow") return "snow";
  if(k==="temp") return /anom/.test(id)?"tanom":/^(td|dew)/.test(id)?"td":/tmax/.test(id)?"tmax":/tmin/.test(id)?"tmin":/soil/.test(id)?"tsoil":"temp";
  if(k==="wind") return /gust/.test(id)?"gust":"wind";
  if(/rh|humid/.test(id)) return "rh"; if(/cape/.test(id)) return "cape"; if(/cloud|tcc/.test(id)) return "cloud"; return null; }
function nvLibList(par){ const k=nvLibKey(par); try{ return (k&&MT_PAL_LIB[k])||[]; }catch(err){ return []; } }
function nvCbCur(par,e){ const c=NV.s.cb; if(c) return c; return (nvKind(par)==='precip'&&!(e&&e.sc&&e.sc.lab))?'radar_mm':'def'; }
const nvCbIds=par=>["def",...nvLibList(par).map(x=>x[1])];
function nvHex(h){ return [parseInt(h.slice(1,3),16),parseInt(h.slice(3,5),16),parseInt(h.slice(5,7),16)]; }
function nvRgbHex(c){ return "#"+c.map(v=>Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,"0")).join(""); }
function nvIsWhite(h){ try{ const v=nvHex(h); return v[0]>242&&v[1]>242&&v[2]>242; }catch(err){ return false; } }
function nvGrad(stops,n){ const S=stops.map(nvHex), out=[]; for(let i=0;i<n;i++){ const t=n<2?0:i/(n-1)*(S.length-1), a=Math.min(S.length-2,Math.floor(t)), f=t-a, A=S[a], B=S[a+1];
    out.push("#"+[0,1,2].map(k=>Math.round(A[k]+(B[k]-A[k])*f).toString(16).padStart(2,"0")).join("")); } return out; }
const NV_RM={p1:[1,50],p3:[0,100],p6:[0,100],p24:[0,250]};   // [شروع، حداکثر] میلی‌متر برای رنگ‌بندی «رادار → بارش»
function nvEffScale(e){
  const sc=e&&e.sc; if(!sc) return sc; const id=nvCbCur(e&&e.par,e); if(!id||id==="def"||sc.lab||!nvCbIds(e.par).includes(id)) return sc;
  const ck=id+((id==="radar_mm"&&NV_RM[String((e.par&&e.par.id)||"")])?":"+e.par.id:""); sc.__cb=sc.__cb||{}; if(sc.__cb[ck]) return sc.__cb[ck];
  const n=sc.c.length, E=sc.e||[], kind=nvKind(e.par), keep0=(kind==="precip"||kind==="snow")&&nvIsWhite(sc.c[0]); let g=null;
  try{
    if(id==="windy"){ g=nvGrad((kind==="precip"||kind==="snow")?MT_WINDY.precip:MT_WINDY.temp,n); }
    else{
      const VB={WB:[WB_PAL, PROFILES.wb.edges.slice(0, WB_PAL.length)], WBS:[WB_SNOW_PAL, WB_SNOW_EDGES.slice(0, WB_SNOW_PAL.length)]}[id];
      const lp=VB?VB[0]:(MT_PALS[id]||[]).map(hexRGB), le=VB?VB[1]:MT_PAL_EDGES[id];
      if(lp.length>=2){
        const rep=k=>{ const a=E[k], b=E[k+1]; if(Number.isFinite(a)&&Number.isFinite(b)) return (a+b)/2; if(Number.isFinite(b)) return b-1e-6; return a; };
        const reps=sc.c.map((_,k)=>rep(k)), fin=reps.filter(Number.isFinite); g=sc.c.slice();
        const RM=(id==="radar_mm"&&kind==="precip")?NV_RM[String((e.par&&e.par.id)||"")]:null;   // بارش ۱/۳/۶/۲۴ ساعته: رنگ‌ها یکنواخت بین بازهٔ تعیین‌شده؛ بالاتر از حداکثر = رنگ آخر
        const P24=RM&&id==="radar_mm"&&String((e.par&&e.par.id)||"")==="p24"&&lp.length>=3;   // ۲۴ ساعته: هر طبقه رنگ جدا، پخش‌شده روی کل رنگ‌های رادار تا ۳۰۰ میلی‌متر
        if(P24){ const cls=[]; for(let k=0;k<n;k++) if(!Number.isFinite(E[k+1])||E[k+1]>0.1+1e-9) cls.push(k);
          const K=cls.length, m=lp.length-1;
          cls.forEach((k,r)=>{ const t=K<2?1:1+r*(m-1)/(K-1), a=Math.min(m-1,Math.floor(t)), f=t-a, A=lp[a], B=lp[a+1]; g[k]=nvRgbHex([0,1,2].map(q=>A[q]+(B[q]-A[q])*f)); }); }
        else if(RM&&lp.length>=3){ const m=lp.length-1; for(let k=0;k<n;k++){ const v=reps[k]; if(!Number.isFinite(v)) continue;
            const j=v<0.1?0:Math.max(1,Math.min(m,1+Math.floor((v-RM[0])/(RM[1]-RM[0])*m))); g[k]=nvRgbHex(lp[j]); } }
        else if(le&&le.length===lp.length){ for(let k=0;k<n;k++){ const v=reps[k]; if(!Number.isFinite(v)) continue; let j=0; for(let q=0;q<le.length;q++) if(le[q]<=v+1e-9) j=q; g[k]=nvRgbHex(lp[j]); } }
        else if(fin.length){ const lo=Math.min(...fin), hi=Math.max(...fin); for(let k=0;k<n;k++){ const v=reps[k], f=Number.isFinite(v)&&hi>lo?(v-lo)/(hi-lo):0; g[k]=nvRgbHex(lp[Math.max(0,Math.min(lp.length-1,Math.round(f*(lp.length-1))))]); } }
        else g=null; } }
  }catch(err){ console.warn("nv colorbar",err); g=null; }
  if(!g) return sc;
  if(keep0) g[0]=sc.c[0];
  if(kind==="precip"&&id==="radar_mm") for(let k=0;k<n;k++) if(Number.isFinite(E[k+1])&&E[k+1]<=0.1+1e-9) g[k]="#ffffff";   // بارش ۰ = سفید                       // کلاس «بدون بارش» رنگ اصلی را نگه می‌دارد
  return sc.__cb[ck]=Object.assign({},sc,{c:g,__p32:null}); }
function nvCbBody(){
  const e=NV.entry, par=e&&e.par||nvPar(NV.s.p), ids=nvCbIds(par), cur=ids.includes(nvCbCur(par,e))?nvCbCur(par,e):"def";
  const long=!!(e&&e.sc&&e.sc.lab), lib=nvLibList(par);
  if(long) return '<div class="hint">رنگ نقشه‌های ماهانه/فصلی ثابت است و عوض نمی‌شود.</div>';
  if(!lib.length) return '<div class="hint">برای این پارامتر رنگ‌بندی دیگری در کتابخانه نیست.</div>';
  return `<div class="hint">رنگ‌بندی‌ها همان رنگ‌بندی‌هایی‌اند که در ابزار نقشه دارید (weather.us، WeatherBELL، NOAA و ...). رنگ هر کلاس از روی مقدارش در رنگ‌بندی انتخابی گرفته می‌شود.</div><div class="wxRow">${ids.map(k=>wxChip(k==="def"?NV_CB_DEF:(lib.find(x=>x[1]===k)||[k])[0],k===cur,`data-cb="${k}"`)).join("")}</div>`; }


/* ===================== GIF متحرک با بازهٔ زمانی فریم‌ها — مرحلهٔ ۱-ب ===================== */
function nvGifFill(){
  const f=$("nvGf"), t=$("nvGt"); if(!f||!t) return; const it=NV.items||[], opts=it.map((i,k)=>`<option value="${k}">${nvFrLab(i)}</option>`).join("")||'<option value="0">—</option>';
  f.innerHTML=opts; t.innerHTML=opts; f.value="0"; t.value=String(Math.max(0,it.length-1)); }
async function nvGif(){
  const it=NV.items||[], e0=NV.entry; if(!it.length||!e0||!e0.img) throw new Error("نقشه هنوز بارگذاری نشده است");
  let a=+$("nvGf").value, b=+$("nvGt").value; if(a>b) [a,b]=[b,a]; const list=it.slice(a,b+1);
  if(list.length<2) throw new Error("برای GIF دست‌کم دو فریم انتخاب کنید (فریم شروع و پایان را متفاوت بگذارید)");
  const w0=+$("nvGw").value||1800, hFor=x=>Math.round(x*nvExpView().R)+130+Math.round(x/760*88)+84; let w=w0;
  while(w>900 && w*hFor(w)*4*list.length>500e6) w-=300;                               // سقف حافظهٔ مرورگر
  const par=e0.par, P0=nvPar(nvPid())||nvPar(NV.s.p), fr=[], de=[]; let W=0,Hh=0;
  for(let k=0;k<list.length;k++){ const cur=list[k]; onStatus(`ساخت GIF: فریم ${FA(k+1)} از ${FA(list.length)}…`,0.05+0.85*k/list.length);
    const url0=ON.base+cur.f, url=url0+nvRunQ(), lurl=P0&&P0.ln?url0.replace(/\/([a-zA-Z0-9]+)_(\d{10}\.webp)$/,"/$1L_$2")+nvRunQ():null;
    const [img,lay]=await Promise.all([nvImg(url), lurl?nvImg(lurl):null]); if(!img) continue;
    const c=nvCanvas({item:cur,img,lay,par:P0||par,sc:P0&&nvScale(P0.sc),idx:null},w); if(!c) continue; W=c.width; Hh=c.height;
    fr.push(c.getContext("2d").getImageData(0,0,W,Hh).data); de.push(k===list.length-1?(NV.gifHold||160):(NV.gifDelay||70)); await tick(); }
  if(fr.length<2) throw new Error("تصویر فریم‌ها بارگذاری نشد");
  onStatus("فشرده‌سازی GIF…",0.93); await tick();
  const g=gifEncode(fr,W,Hh,de); onSave(g,`metstat_${NV.s.m}_${nvPid()}_${list[0].v}-${list[list.length-1].v}_${NV.s.reg.replace(/[^a-z]/g,"")||"reg"}.gif`); onStatus("",1);
  if(w0!==w) alert(`برای جلوگیری از پر شدن حافظهٔ مرورگر، عرض GIF به ${w} پیکسل کاهش یافت.`);
}


/* ===================== رفع مرز دوتایی — مرحلهٔ ۱-ب =====================
   خط ساحل/مرز کشورها (داده‌های قدیمی) و مرز استان‌ها (شیپ‌فایل) در محدودهٔ ایران کمی جابه‌جا بودند و دو خط دیده می‌شد.
   حالا: نقطه‌های خط قدیمی که نزدیک مرز شیپ‌فایل ایران‌اند حذف می‌شوند، و خود مرز بیرونی ایران از شیپ‌فایل (ضخیم) کشیده می‌شود.
   بیرون از ایران (کشورهای همسایه، دریاها) خط قدیمی دست‌نخورده می‌ماند. فقط یک‌بار هنگام ساخت مسیرها محاسبه می‌شود. */
function nvSegGrid(){ return {m:new Map(),S:[]}; }
function nvSegAdd(g,x1,y1,x2,y2){ const id=g.S.length/4; g.S.push(x1,y1,x2,y2);
  const c0=Math.floor(Math.min(x1,x2)/0.1), c1=Math.floor(Math.max(x1,x2)/0.1), r0=Math.floor(Math.min(y1,y2)/0.1), r1=Math.floor(Math.max(y1,y2)/0.1);
  for(let a=c0;a<=c1;a++) for(let b=r0;b<=r1;b++){ const k=(a+3000)*8000+(b+3000); let l=g.m.get(k); if(!l) g.m.set(k,l=[]); l.push(id); } }
function nvSegNear(g,x,y,d){ const a=Math.floor(x/0.1), b=Math.floor(y/0.1), S=g.S;
  for(let i=-1;i<=1;i++) for(let j=-1;j<=1;j++){ const l=g.m.get((a+i+3000)*8000+(b+j+3000)); if(!l) continue;
    for(const id of l){ const x1=S[4*id], y1=S[4*id+1], dx=S[4*id+2]-x1, dy=S[4*id+3]-y1, L2=dx*dx+dy*dy; let t=L2?((x-x1)*dx+(y-y1)*dy)/L2:0; t=t<0?0:t>1?1:t;
      const ex=x1+t*dx-x, ey=y1+t*dy-y; if(ex*ex+ey*ey<=d*d) return true; } }
  return false; }
function nvDedupe(P){
  if(!P.hasO) return; const B=borderLines(), LY=window.CQC_LAYERS||LAYERS, GO=nvSegGrid(), GC=nvSegGrid(), oseg=[];
  for(const f of (LY.ostan||[])) for(const poly of f.g) for(const ring of poly) for(let i=1;i<ring.length;i++){ nvSegAdd(GO,ring[i-1][0],ring[i-1][1],ring[i][0],ring[i][1]); oseg.push(ring[i-1][0],ring[i-1][1],ring[i][0],ring[i][1]); }
  for(const L of [B.ctry,B.coast]) for(const pts of (L||[])) for(let i=2;i<pts.length;i+=2) nvSegAdd(GC,pts[i-2],pts[i-1],pts[i],pts[i+1]);
  const D=0.06, strip=L=>{ const out=new Path2D(); for(const pts of (L||[])){ let open=false;
      for(let i=0;i<pts.length;i+=2){ const near=nvSegNear(GO,pts[i],pts[i+1],D); if(near){ open=false; continue; } if(open) out.lineTo(pts[i],pts[i+1]); else { out.moveTo(pts[i],pts[i+1]); open=true; } } } return out; };
  P.ctry2=strip(B.ctry); P.coast2=strip(B.coast); P.GO=GO;
  const outer=new Path2D(), inner=new Path2D();
  for(let i=0;i<oseg.length;i+=4){ const mx=(oseg[i]+oseg[i+2])/2, my=(oseg[i+1]+oseg[i+3])/2, isOut=nvSegNear(GC,mx,my,0.08)||nvSegNear(GC,oseg[i],oseg[i+1],0.08)&&nvSegNear(GC,oseg[i+2],oseg[i+3],0.08), T=isOut?outer:inner;
    T.moveTo(oseg[i],oseg[i+1]); T.lineTo(oseg[i+2],oseg[i+3]); }
  P.outer=outer; P.ostanIn=inner;
  // خط شهرستان‌ها از شیپ‌فایل دیگری است و کمی با خط استان/ساحل جابه‌جاست → دو خط می‌شد. تکه‌هایی که کنار خط استان‌اند حذف می‌شوند (با ریز‌کردن پاره‌خط‌ها تا فاصله‌گیری دقیق باشد).
  const DC=0.04, STEP=0.01, cn=new Path2D();
  for(const f of (LY.county||[])) for(const poly of f.g) for(const ring of poly){ let open=false;
    for(let i=1;i<ring.length;i++){ const ax=ring[i-1][0], ay=ring[i-1][1], bx=ring[i][0], by=ring[i][1], n=Math.max(1,Math.ceil(Math.hypot(bx-ax,by-ay)/STEP));
      for(let s=0;s<n;s++){ const x1=ax+(bx-ax)*s/n, y1=ay+(by-ay)*s/n, x2=ax+(bx-ax)*(s+1)/n, y2=ay+(by-ay)*(s+1)/n;
        if(nvSegNear(GO,(x1+x2)/2,(y1+y2)/2,DC)){ open=false; continue; }
        if(!open){ cn.moveTo(x1,y1); open=true; } cn.lineTo(x2,y2); } } }
  P.cnty2=cn;
}
